// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "ReframeCore",
    platforms: [.iOS(.v16), .macOS(.v13)],
    products: [
        .library(name: "ReframeCore", targets: ["ReframeCore"])
    ],
    targets: [
        .target(name: "ReframeCore"),
        .testTarget(name: "ReframeCoreTests", dependencies: ["ReframeCore"])
    ]
)
