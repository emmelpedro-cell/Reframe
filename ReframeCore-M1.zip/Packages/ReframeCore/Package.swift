// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "ReframeCore",
    platforms: [.iOS(.v16), .macOS(.v13)],
    products: [
        .library(name: "ReframeCore", targets: ["ReframeCore"]),
        .library(name: "TrackingKit", targets: ["TrackingKit"]),
        .executable(name: "reframe", targets: ["ReframeCLI"])
    ],
    targets: [
        .target(name: "ReframeCore"),
        // M2: tudo que conhece Vision/AVFoundation fica aqui, nunca no ReframeCore.
        .target(name: "TrackingKit", dependencies: ["ReframeCore"]),
        .executableTarget(name: "ReframeCLI", dependencies: ["TrackingKit", "ReframeCore"]),
        .testTarget(name: "ReframeCoreTests", dependencies: ["ReframeCore"]),
        .testTarget(
            name: "TrackingKitTests",
            dependencies: ["TrackingKit", "ReframeCore"],
            resources: [.copy("Fixtures")]
        )
    ]
)
