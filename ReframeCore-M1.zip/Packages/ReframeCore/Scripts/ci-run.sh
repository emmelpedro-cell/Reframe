#!/bin/bash
# Roda track + render. Chamado pelo workflow, na raiz do repositório.
#
# Variáveis de ambiente (todas opcionais):
#   ASPECT   proporção da saída: 9:16 (padrão), 4:5 ou 1:1
#   PRESET   estilo do recorte: suave (padrão), padrao, oneeuro, rapido
#   TAG      se preenchida: baixa os vídeos do Release com essa tag, processa SÓ eles
#            e envia os verticais de volta para o mesmo Release.
#            Se vazia: processa os vídeos que estão no repositório.
set +e
ROOT="$PWD"
BIN="$ROOT/Packages/ReframeCore/.build/release/reframe"
ASPECT="${ASPECT:-9:16}"
PRESET="${PRESET:-suave}"
TAG="${TAG:-}"
SUFFIX="vertical-$PRESET"
[ "$ASPECT" != "9:16" ] && SUFFIX="$SUFFIX-${ASPECT/:/x}"

mkdir -p out
shopt -s nullglob nocaseglob

FILES=()
if [ -n "$TAG" ]; then
  echo "== Release '$TAG'"
  if ! gh release view "$TAG" >/dev/null 2>&1; then
    gh release create "$TAG" --title "Videos" --notes "Suba aqui os videos. Os verticais aparecem aqui depois do workflow." >/dev/null 2>&1
    echo "release criado (vazio): suba um video nele e rode de novo"
  fi
  mkdir -p release_videos
  gh release download "$TAG" --dir release_videos --skip-existing \
    -p '*.mov' -p '*.mp4' -p '*.m4v' 2>&1
  for f in release_videos/*.mov release_videos/*.mp4 release_videos/*.m4v; do
    case "$f" in *vertical-*|*.debug.mp4) continue;; esac
    FILES+=("$f")
  done
else
  for f in *.mov *.mp4 *.m4v videos/*.mov videos/*.mp4 videos/*.m4v; do
    case "$f" in *vertical-*|*.vertical.mp4|*.debug.mp4) continue;; esac
    FILES+=("$f")
  done
fi
echo "videos a processar: ${#FILES[@]}  (estilo: $PRESET, formato: $ASPECT)"

for f in "${FILES[@]}"; do
  n=$(basename "$f"); n="${n%.*}"
  echo "== $f"
  {
    "$BIN" track "$f" --output "out/$n.json" --debug-video "out/$n.debug.mp4" --crop --cpu-only
    echo "-- render"
    "$BIN" render "$f" --tracking "out/$n.json" --output "out/$n.$SUFFIX.mp4" \
      --aspect "$ASPECT" --preset "$PRESET"
  } 2>&1 | tee "out/$n.log"
  if [ -n "$TAG" ] && [ -f "out/$n.$SUFFIX.mp4" ]; then
    gh release upload "$TAG" "out/$n.$SUFFIX.mp4" --clobber 2>&1
  fi
done
ls -l out
exit 0
