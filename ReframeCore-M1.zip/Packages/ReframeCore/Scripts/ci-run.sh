#!/bin/bash
# Roda track + render em todos os videos do repo. Chamado pelo workflow.
# Uso (na raiz do repo): bash Packages/ReframeCore/Scripts/ci-run.sh
set +e
ROOT="$PWD"
BIN="$ROOT/Packages/ReframeCore/.build/release/reframe"
mkdir -p out
shopt -s nullglob nocaseglob
for f in *.mov *.mp4 *.m4v videos/*.mov videos/*.mp4 videos/*.m4v; do
  n=$(basename "$f"); n="${n%.*}"
  echo "== $f"
  {
    "$BIN" track "$f" --output "out/$n.json" --debug-video "out/$n.debug.mp4" --crop --cpu-only
    echo "-- render"
    "$BIN" render "$f" --tracking "out/$n.json" --output "out/$n.vertical.mp4"
  } 2>&1 | tee "out/$n.log"
done
ls -l out
exit 0
