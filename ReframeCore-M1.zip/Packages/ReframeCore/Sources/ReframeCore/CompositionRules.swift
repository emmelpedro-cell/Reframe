import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Linha do tempo de caixas do sujeito, interpolada linearmente em X.
/// Uso interno. Coordenadas normalizadas (origem topo-esquerdo, +X direita).
struct BoxTimeline {
    struct Observation {
        let time: Double
        let minX: Double
        let maxX: Double
    }

    let observations: [Observation]
    let maxInterpolationGap: Double

    init(points: [TrackingPoint], minConfidence: Float, maxInterpolationGap: Double) {
        var collected: [Observation] = []
        collected.reserveCapacity(points.count)
        for point in points {
            guard point.confidence >= minConfidence else { continue }
            let minX = Double(point.boundingBox.minX)
            let maxX = Double(point.boundingBox.maxX)
            guard point.time.isFinite, minX.isFinite, maxX.isFinite else { continue }
            collected.append(Observation(time: point.time, minX: minX, maxX: maxX))
        }
        collected.sort { $0.time < $1.time }
        self.observations = collected
        self.maxInterpolationGap = maxInterpolationGap
    }

    var firstTime: Double? { observations.first?.time }
    var lastTime: Double? { observations.last?.time }

    /// Extensão horizontal do sujeito em `time`.
    /// • antes da primeira / depois da última observação: mantém a mais próxima;
    /// • entre duas observações próximas: interpola;
    /// • entre duas observações separadas por mais que `maxInterpolationGap`
    ///   (sujeito perdido): mantém a anterior até a próxima chegar.
    func span(at time: Double) -> (minX: Double, maxX: Double)? {
        guard let first = observations.first, let last = observations.last else { return nil }
        if time <= first.time { return (first.minX, first.maxX) }
        if time >= last.time { return (last.minX, last.maxX) }

        var low = 0
        var high = observations.count - 1
        while high - low > 1 {
            let mid = (low + high) / 2
            if observations[mid].time <= time { low = mid } else { high = mid }
        }
        let a = observations[low]
        let b = observations[low + 1]
        if b.time - a.time > maxInterpolationGap { return (a.minX, a.maxX) }
        let alpha = (time - a.time) / (b.time - a.time)
        return (a.minX + (b.minX - a.minX) * alpha, a.maxX + (b.maxX - a.maxX) * alpha)
    }
}

/// Resultado das regras de composição para um instante.
/// Tudo em coordenadas normalizadas do source; são CENTROS de crop.
public struct Composition: Equatable, Sendable {
    /// Centro do sujeito (alvo ideal, sem restrições).
    public let center: Double
    /// Menor centro de crop que ainda mantém o sujeito + margem dentro da janela.
    public let lowerBound: Double
    /// Maior centro de crop que ainda mantém o sujeito + margem dentro da janela.
    public let upperBound: Double

    /// Alvo de composição: o centro do sujeito, limitado a `lowerBound...upperBound`.
    public var goal: Double { min(max(center, lowerBound), upperBound) }
}

/// Regras de composição horizontal: box → box expandido → alvo e limites do crop.
public struct CompositionRules: Sendable {
    public let geometry: CropGeometry
    public let settings: ReframeSettings

    public init(geometry: CropGeometry, settings: ReframeSettings) {
        self.geometry = geometry
        self.settings = settings
    }

    /// Composição para um sujeito que ocupa `minX...maxX` (normalizado).
    ///
    /// 1. Expande o box pela margem (relativa ao crop). Se a margem não couber,
    ///    ela encolhe; se o próprio box já for maior que o crop, vira 0.
    /// 2. Calcula quais centros de crop mantêm o box expandido dentro da janela
    ///    (e a janela dentro do frame).
    /// 3. Se isso for impossível (box maior que o crop), abandona a restrição
    ///    de margem e fica só com o limite físico: o alvo passa a ser o centro
    ///    do sujeito e quem decide se o crop anda é a dead zone (composição estável).
    public func composition(minX: Double, maxX: Double) -> Composition {
        let cropWidth = geometry.cropWidth
        let center = (minX + maxX) / 2
        let width = max(0, maxX - minX)
        let wantedMargin = max(0, settings.horizontalMargin) * cropWidth
        let margin = min(wantedMargin, max(0, (cropWidth - width) / 2))

        let expandedLeft = max(0, minX - margin)
        let expandedRight = min(1, maxX + margin)

        var lower = max(expandedRight - cropWidth / 2, geometry.minCenterX)
        var upper = min(expandedLeft + cropWidth / 2, geometry.maxCenterX)
        if lower > upper {
            lower = geometry.minCenterX
            upper = geometry.maxCenterX
        }
        return Composition(center: center, lowerBound: lower, upperBound: upper)
    }

    /// Composição quando não existe nenhuma observação válida: crop no centro.
    public func fallbackComposition() -> Composition {
        let center = geometry.clampCenter(0.5)
        return Composition(center: center, lowerBound: geometry.minCenterX, upperBound: geometry.maxCenterX)
    }
}
