import Foundation

/// Reframe Engine: transforma a trajetória do sujeito na trajetória da
/// "câmera vertical virtual" (janela de crop dentro do vídeo de origem).
///
/// Coordenadas: normalizadas do source, origem no topo-esquerdo, +X direita
/// (ver `TrackingPoint`). O engine não conhece pixels nem resoluções.
///
/// Pipeline por amostra de saída:
///
///     TrackingPoint → expandir box → alvo de composição
///       → look-ahead → dead zone → critically damped spring
///       → limite de velocidade → clamp físico → CropPoint
///
/// Determinístico: mesma entrada e mesmos parâmetros dão sempre a mesma saída.
public struct ReframeEngine: Sendable {
    public let geometry: CropGeometry
    public let settings: ReframeSettings

    public init(geometry: CropGeometry, settings: ReframeSettings = ReframeSettings()) {
        self.geometry = geometry
        self.settings = settings
    }

    public init(sourceAspect: Double, outputAspect: Double, settings: ReframeSettings = ReframeSettings()) {
        self.init(
            geometry: CropGeometry(sourceAspect: sourceAspect, outputAspect: outputAspect),
            settings: settings
        )
    }

    public func trajectory(for track: SubjectTrack, fps: Double, timeRange: ClosedRange<Double>? = nil) -> [CropPoint] {
        return trajectory(points: track.points, fps: fps, timeRange: timeRange)
    }

    /// Gera um `CropPoint` por amostra de saída, a `fps` amostras por segundo.
    ///
    /// - Parameters:
    ///   - points: observações do sujeito (qualquer ordem; baixa confiança = perdido).
    ///   - fps: taxa de amostragem da saída. O spring usa o `deltaTime` real entre amostras.
    ///   - timeRange: intervalo a cobrir (ex.: duração do vídeo). Se `nil`, vai da
    ///     primeira à última observação válida.
    public func trajectory(points: [TrackingPoint], fps: Double, timeRange: ClosedRange<Double>? = nil) -> [CropPoint] {
        guard fps.isFinite, fps > 0 else { return [] }

        let timeline = BoxTimeline(
            points: points,
            minConfidence: settings.minConfidence,
            maxInterpolationGap: settings.maxInterpolationGap
        )
        let rules = CompositionRules(geometry: geometry, settings: settings)

        let startTime: Double
        let endTime: Double
        if let range = timeRange {
            startTime = range.lowerBound
            endTime = range.upperBound
        } else if let first = timeline.firstTime, let last = timeline.lastTime {
            startTime = first
            endTime = last
        } else {
            return []
        }
        guard startTime.isFinite, endTime.isFinite, endTime >= startTime else { return [] }

        let stepCount = Int(((endTime - startTime) * fps + 1e-9).rounded(.down))

        func composition(at time: Double) -> Composition {
            if let span = timeline.span(at: time) {
                return rules.composition(minX: span.minX, maxX: span.maxX)
            }
            return rules.fallbackComposition()
        }

        let spring = CriticallyDampedSpring(smoothingTime: settings.smoothingTime)
        let halfDeadZone = max(0, settings.deadZoneWidth) * geometry.cropWidth / 2
        let releaseDistance = settings.releaseFraction * halfDeadZone

        // O crop começa já enquadrando o sujeito em t0 (sem look-ahead).
        var state = CriticallyDampedSpring.State(position: composition(at: startTime).goal, velocity: 0)
        var following = false
        var previousTime = startTime

        var output: [CropPoint] = []
        output.reserveCapacity(stepCount + 1)
        output.append(CropPoint(time: startTime, centerX: CGFloat(state.position)))

        if stepCount >= 1 {
            for index in 1...stepCount {
                let time = startTime + Double(index) / fps
                let deltaTime = time - previousTime

                // 1) alvo de composição no FUTURO conhecido (look-ahead determinístico)
                let target = composition(at: time + settings.lookAhead)
                let goal = target.goal
                let current = state.position

                // 2) dead zone (relativa à largura do crop) com histerese
                if !following && abs(goal - current) > halfDeadZone {
                    following = true
                }
                var desired: Double
                if following {
                    desired = goal
                    if abs(goal - current) <= releaseDistance && abs(state.velocity) <= settings.releaseSpeed {
                        following = false
                        desired = min(max(current, target.lowerBound), target.upperBound)
                    }
                } else {
                    // parado, mas a margem de segurança nunca pode ser violada
                    desired = min(max(current, target.lowerBound), target.upperBound)
                }

                // 3) spring com deltaTime real
                var next = spring.update(current: state, target: desired, deltaTime: deltaTime)

                // 4) limite de velocidade
                let maxStep = max(0, settings.maxSpeed) * deltaTime
                var delta = next.position - current
                if abs(delta) > maxStep {
                    delta = delta < 0 ? -maxStep : maxStep
                    next = CriticallyDampedSpring.State(position: current + delta, velocity: delta / deltaTime)
                }

                // 5) clamp físico (sempre por último)
                let clamped = geometry.clampCenter(next.position)
                if clamped != next.position {
                    next = CriticallyDampedSpring.State(position: clamped, velocity: 0)
                }

                state = next
                previousTime = time
                output.append(CropPoint(time: time, centerX: CGFloat(state.position)))
            }
        }
        return output
    }
}
