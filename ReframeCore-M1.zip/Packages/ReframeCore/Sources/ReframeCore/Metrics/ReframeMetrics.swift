import Foundation

/// Métricas objetivas de uma trajetória de crop, para comparar algoritmos
/// (spring × One Euro) e ajustar parâmetros com dados.
///
/// Unidades: posições em fração da largura do source; velocidade em
/// larguras/s; aceleração em larguras/s²; jerk em larguras/s³.
public struct ReframeMetrics: Equatable, Sendable {
    /// Média de |centro do sujeito − centro do crop|.
    public var meanSubjectError: Double
    /// O mesmo erro, em larguras de crop (independe da proporção de saída).
    public var meanSubjectErrorInCropWidths: Double
    /// Fração das amostras em que o box do sujeito está inteiro dentro do crop (0...1).
    public var insideCropRatio: Double
    public var maxSpeed: Double
    public var maxAcceleration: Double
    public var jerkRMS: Double
    /// Número de inversões de direção do crop (ignora velocidades desprezíveis).
    public var directionChanges: Int
    /// Atraso aparente (s) entre sujeito e crop: o deslocamento no tempo que
    /// melhor alinha a curva do crop à do sujeito.
    public var apparentLag: Double

    public static let zero = ReframeMetrics(
        meanSubjectError: 0, meanSubjectErrorInCropWidths: 0, insideCropRatio: 0,
        maxSpeed: 0, maxAcceleration: 0, jerkRMS: 0, directionChanges: 0, apparentLag: 0
    )

    public static func evaluate(
        crop: [CropPoint],
        subject: [TrackingPoint],
        geometry: CropGeometry,
        settings: ReframeSettings = ReframeSettings()
    ) -> ReframeMetrics {
        let count = crop.count
        guard count >= 2 else { return .zero }
        let timeline = BoxTimeline(
            points: subject,
            minConfidence: settings.minConfidence,
            maxInterpolationGap: settings.maxInterpolationGap
        )
        guard !timeline.observations.isEmpty else { return .zero }

        let cropWidth = geometry.cropWidth
        let positions = crop.map { Double($0.centerX) }
        var subjectCenters: [Double] = []
        subjectCenters.reserveCapacity(count)
        var insideCount = 0
        for (index, point) in crop.enumerated() {
            guard let span = timeline.span(at: point.time) else { return .zero }
            subjectCenters.append((span.minX + span.maxX) / 2)
            let left = positions[index] - cropWidth / 2
            let right = positions[index] + cropWidth / 2
            if span.minX >= left - 1e-9 && span.maxX <= right + 1e-9 {
                insideCount += 1
            }
        }

        let dt = (crop[count - 1].time - crop[0].time) / Double(count - 1)
        guard dt > 0 else { return .zero }

        let velocity = differences(positions, dt: dt)
        let acceleration = differences(velocity, dt: dt)
        let jerk = differences(acceleration, dt: dt)

        var errorSum = 0.0
        for index in 0..<count {
            errorSum += abs(subjectCenters[index] - positions[index])
        }
        let meanError = errorSum / Double(count)

        var changes = 0
        var lastSign = 0
        for v in velocity where abs(v) > 1e-3 {
            let sign = v > 0 ? 1 : -1
            if lastSign != 0 && sign != lastSign { changes += 1 }
            lastSign = sign
        }

        var jerkRMS = 0.0
        if !jerk.isEmpty {
            var sumSquares = 0.0
            for j in jerk { sumSquares += j * j }
            jerkRMS = (sumSquares / Double(jerk.count)).squareRoot()
        }

        // Atraso aparente: desloca a curva do sujeito k amostras para trás
        // e escolhe o k com menor erro quadrático médio (empate → menor k).
        let maxLagSamples = min(Int(2.0 / dt), count / 2)
        var bestLag = 0
        var bestError = Double.infinity
        if maxLagSamples >= 0 {
            for lag in 0...maxLagSamples {
                var sum = 0.0
                for index in lag..<count {
                    let diff = positions[index] - subjectCenters[index - lag]
                    sum += diff * diff
                }
                let mse = sum / Double(count - lag)
                if mse < bestError - 1e-12 {
                    bestError = mse
                    bestLag = lag
                }
            }
        }

        return ReframeMetrics(
            meanSubjectError: meanError,
            meanSubjectErrorInCropWidths: cropWidth > 0 ? meanError / cropWidth : 0,
            insideCropRatio: Double(insideCount) / Double(count),
            maxSpeed: velocity.map { abs($0) }.max() ?? 0,
            maxAcceleration: acceleration.map { abs($0) }.max() ?? 0,
            jerkRMS: jerkRMS,
            directionChanges: changes,
            apparentLag: Double(bestLag) * dt
        )
    }

    private static func differences(_ values: [Double], dt: Double) -> [Double] {
        guard values.count >= 2 else { return [] }
        var result: [Double] = []
        result.reserveCapacity(values.count - 1)
        for index in 0..<(values.count - 1) {
            result.append((values[index + 1] - values[index]) / dt)
        }
        return result
    }
}
