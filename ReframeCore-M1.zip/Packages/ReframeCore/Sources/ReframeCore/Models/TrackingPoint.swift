import Foundation

// MARK: - Convenções do ReframeCore
//
// Todo o ReframeCore trabalha em COORDENADAS NORMALIZADAS DO FRAME DE ORIGEM:
//
//   • x = 0...1  (0 = borda esquerda, 1 = borda direita)
//   • y = 0...1  (0 = topo,           1 = base)
//   • origem no TOPO-ESQUERDO, +X para a direita, +Y para baixo.
//
// O Vision usa origem no canto INFERIOR-esquerdo (y invertido) e os pixels de
// vídeo podem exigir `preferredTransform`. Essas conversões acontecem FORA daqui
// (TrackingKit na entrada, RenderKit na saída). O ReframeCore nunca vê pixels
// e não sabe qual é a resolução do vídeo (4K, 1080p...): só proporções.
//
// Proporção (aspect) = largura / altura. 16:9 → 16/9, 9:16 → 9/16.

/// Uma observação do sujeito em um instante do vídeo.
///
/// `boundingBox` está em coordenadas normalizadas do frame de origem
/// (origem no topo-esquerdo, +X direita, +Y baixo).
public struct TrackingPoint: Codable, Equatable, Sendable {
    /// Tempo em segundos desde o início do vídeo.
    public let time: Double
    /// Caixa do sujeito, normalizada (0...1), origem no topo-esquerdo.
    public let boundingBox: CGRect
    /// Confiança 0...1. Pontos abaixo de `ReframeSettings.minConfidence`
    /// são tratados como "sujeito perdido" (ignorados pelo engine).
    public let confidence: Float

    public init(time: Double, boundingBox: CGRect, confidence: Float = 1) {
        self.time = time
        self.boundingBox = boundingBox
        self.confidence = confidence
    }
}

/// Trajetória de um único sujeito. O `id` permite, no futuro, acompanhar
/// uma pessoa específica (`track(subjectID:)`).
public struct SubjectTrack: Codable, Equatable, Sendable {
    public let id: UUID
    public var points: [TrackingPoint]

    public init(id: UUID = UUID(), points: [TrackingPoint]) {
        self.id = id
        self.points = points
    }
}
