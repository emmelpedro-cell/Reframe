import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Geometria da janela de crop, derivada APENAS de proporções.
///
/// A janela ocupa a altura inteira do source. Com `aspect = largura / altura`:
///
///     cropWidth (normalizada) = outputAspect / sourceAspect
///
/// Exemplos (independem de resolução):
///   • 16:9 → 9:16 : (9/16) / (16/9) = 81/256 ≈ 0,3164
///   • 16:9 → 1:1  : 1 / (16/9)      = 0,5625
///   • 16:9 → 4:5  : 0,8 / (16/9)    = 0,45
///
/// Se `outputAspect >= sourceAspect` a janela cobriria mais que o frame; nesse
/// caso `cropWidth` é limitado a 1 (e `centerX` fica fixo em 0,5). Cortar
/// também na vertical é assunto de versões futuras.
public struct CropGeometry: Equatable, Sendable {
    /// largura / altura do vídeo de origem (ex.: 16/9).
    public let sourceAspect: Double
    /// largura / altura do vídeo de saída (ex.: 9/16).
    public let outputAspect: Double
    /// Largura da janela, normalizada (fração da largura do source), 0...1.
    public let cropWidth: Double

    public init(sourceAspect: Double, outputAspect: Double) {
        precondition(sourceAspect.isFinite && sourceAspect > 0, "sourceAspect deve ser finito e > 0")
        precondition(outputAspect.isFinite && outputAspect > 0, "outputAspect deve ser finito e > 0")
        self.sourceAspect = sourceAspect
        self.outputAspect = outputAspect
        self.cropWidth = min(1.0, outputAspect / sourceAspect)
    }

    /// Menor `centerX` possível (janela encostada na borda esquerda).
    public var minCenterX: Double { cropWidth / 2 }
    /// Maior `centerX` possível (janela encostada na borda direita).
    public var maxCenterX: Double { 1 - cropWidth / 2 }

    /// Limita um centro ao intervalo fisicamente válido.
    public func clampCenter(_ x: Double) -> Double {
        return min(max(x, minCenterX), maxCenterX)
    }
}
