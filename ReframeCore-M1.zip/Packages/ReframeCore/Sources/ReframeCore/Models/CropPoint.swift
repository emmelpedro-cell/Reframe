import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Posição da janela de crop (a "câmera vertical virtual") em um instante.
///
/// `centerX` é o CENTRO da janela em coordenadas normalizadas do frame de
/// origem (0...1, origem no topo-esquerdo, +X direita). O engine garante que
/// `centerX` está sempre em `CropGeometry.minCenterX ... maxCenterX`, ou seja,
/// a janela inteira fica dentro do frame.
///
/// Nesta versão a janela ocupa a altura inteira do frame (escala fixa), então
/// não há `centerY` nem escala. Eles entram em versões futuras.
public struct CropPoint: Codable, Equatable, Sendable {
    public let time: Double
    public let centerX: CGFloat

    public init(time: Double, centerX: CGFloat) {
        self.time = time
        self.centerX = centerX
    }
}
