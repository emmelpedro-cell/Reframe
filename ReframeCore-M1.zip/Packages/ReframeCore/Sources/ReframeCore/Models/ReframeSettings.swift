import Foundation

/// Parâmetros do Reframe Engine.
///
/// Distâncias são normalizadas. As marcadas como "relativa ao crop" são frações
/// da largura da janela (`CropGeometry.cropWidth`), para que o comportamento
/// seja o mesmo em 9:16, 4:5, 1:1 etc.
public struct ReframeSettings: Equatable, Sendable {
    /// Margem de segurança em cada lado do box do sujeito (relativa ao crop).
    public var horizontalMargin: Double
    /// Largura total da dead zone (relativa ao crop). Enquanto o centro do
    /// sujeito estiver a menos de metade disso do centro do crop, o crop não anda.
    /// 0 desliga a dead zone.
    public var deadZoneWidth: Double
    /// Quantos segundos à frente o engine "olha" na trajetória conhecida (offline).
    /// 0 desliga a antecipação.
    public var lookAhead: Double
    /// Tempo de suavização do spring, em segundos (≈ tempo para chegar ao alvo).
    /// 0 = resposta imediata (sem suavização).
    public var smoothingTime: Double
    /// Velocidade máxima do crop, em larguras-do-source por segundo.
    /// `.infinity` desliga o limite.
    public var maxSpeed: Double
    /// Pontos com confiança abaixo disso são tratados como "sujeito perdido".
    public var minConfidence: Float
    /// Entre duas observações válidas separadas por mais que isso (s), o engine
    /// NÃO interpola: mantém o último enquadramento até o sujeito reaparecer.
    public var maxInterpolationGap: Double
    /// Histerese da dead zone: o crop volta a ficar parado quando o erro cai
    /// abaixo de `releaseFraction × (meia dead zone)`...
    public var releaseFraction: Double
    /// ...e a velocidade cai abaixo disto (larguras-do-source por segundo).
    public var releaseSpeed: Double

    public init(
        horizontalMargin: Double = 0.10,
        deadZoneWidth: Double = 0.30,
        lookAhead: Double = 0.40,
        smoothingTime: Double = 0.45,
        maxSpeed: Double = 0.35,
        minConfidence: Float = 0.30,
        maxInterpolationGap: Double = 0.50,
        releaseFraction: Double = 0.35,
        releaseSpeed: Double = 0.02
    ) {
        self.horizontalMargin = horizontalMargin
        self.deadZoneWidth = deadZoneWidth
        self.lookAhead = lookAhead
        self.smoothingTime = smoothingTime
        self.maxSpeed = maxSpeed
        self.minConfidence = minConfidence
        self.maxInterpolationGap = maxInterpolationGap
        self.releaseFraction = releaseFraction
        self.releaseSpeed = releaseSpeed
    }
}
