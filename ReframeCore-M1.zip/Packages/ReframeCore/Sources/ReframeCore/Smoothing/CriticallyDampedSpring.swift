import Foundation

/// Spring criticamente amortecido (sem overshoot), resolvido de forma ANALÍTICA.
///
/// Para um alvo constante durante o passo, a solução exata é
///
///     e(t) = (e0 + (v0 + ω·e0)·t) · exp(−ω·t),   e = posição − alvo,   ω = 2 / smoothingTime
///
/// Como é a solução exata (e não integração numérica), o resultado depende só
/// do tempo decorrido, não de como ele é fatiado: um passo de 0,1 s dá o mesmo
/// que dez passos de 0,01 s (com alvo constante). Por isso 30 fps e 60 fps
/// produzem trajetórias equivalentes. Funciona com `deltaTime` real, sem
/// assumir 1/30.
public struct CriticallyDampedSpring: Equatable, Sendable {
    public struct State: Equatable, Sendable {
        public var position: Double
        public var velocity: Double

        public init(position: Double, velocity: Double = 0) {
            self.position = position
            self.velocity = velocity
        }
    }

    /// Aproximadamente o tempo (s) para alcançar o alvo. 0 = imediato.
    public var smoothingTime: Double

    public init(smoothingTime: Double) {
        self.smoothingTime = smoothingTime
    }

    /// Avança o spring `deltaTime` segundos em direção a `target`.
    public func update(current: State, target: Double, deltaTime: Double) -> State {
        if smoothingTime <= 0 {
            return State(position: target, velocity: 0)
        }
        if deltaTime <= 0 {
            return current
        }
        let omega = 2.0 / smoothingTime
        let initialError = current.position - target
        let b = current.velocity + omega * initialError
        let decay = exp(-omega * deltaTime)
        let error = (initialError + b * deltaTime) * decay
        let velocity = (b - omega * (initialError + b * deltaTime)) * decay
        return State(position: target + error, velocity: velocity)
    }
}
