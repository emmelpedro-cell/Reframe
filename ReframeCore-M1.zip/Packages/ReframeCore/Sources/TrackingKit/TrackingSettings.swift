import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Todos os parâmetros do TrackingKit em UM lugar (nada de número mágico
/// espalhado). Os valores padrão são pontos de partida documentados, NÃO
/// foram ajustados contra nenhum vídeo.
public struct TrackingSettings: Codable, Equatable, Sendable {

    // MARK: Análise / detecção

    /// Largura (px) usada para decodificar o vídeo para o Vision. A altura
    /// segue o aspect ratio. O vídeo original continua sendo a fonte do render.
    public var analysisWidth: Int = 960
    /// Intervalo (s) entre detecções periódicas. Entre elas, só tracking.
    public var redetectInterval: Double = 0.5
    /// Detecções abaixo disso são ignoradas.
    public var minDetectionConfidence: Float = 0.30
    /// Resultados do tracker abaixo disso contam como "tracker perdeu".
    public var minTrackingConfidence: Float = 0.30

    // MARK: Associação / continuidade

    /// IoU mínimo para uma detecção ser considerada a MESMA pessoa que o tracker segue.
    public var reassociationIoU: Double = 0.30
    /// Se o resultado do tracker tem IoU menor que isto com o último box aceito,
    /// ele "pulou": é tratado como perda (evita saltos).
    public var minContinuityIoU: Double = 0.10

    // MARK: Perda e recuperação

    /// Tempo máximo (s) que o tracker do Vision pode seguir um alvo SEM que nenhuma
    /// detecção concorde com ele. Passado isso, o tracker é considerado "à deriva"
    /// (ex.: grudou na parede quando a pessoa saiu do quadro): seu resultado é
    /// descartado e o último box CONFIRMADO por detecção volta a valer.
    public var confirmationTimeout: Double = 0.8

    /// Por quanto tempo (s) o último box válido é mantido (estado `held`).
    public var holdDuration: Double = 1.0
    /// Janela (s) em que a identidade é preservada e a recuperação é tentada.
    /// Dentro dela NENHUMA outra pessoa é escolhida. Deve ser >= `holdDuration`.
    public var recoveryWindow: Double = 4.0
    /// Na recuperação, aceitar candidato com IoU >= isto com o último box...
    public var recoveryIoU: Double = 0.10
    /// ...ou com o centro a no máximo esta distância (normalizada) do último centro.
    public var recoveryMaxCenterDistance: Double = 0.25
    /// Razão mínima de área (menor/maior) entre candidato e último box na recuperação por distância.
    public var recoveryMinAreaRatio: Double = 0.4
    /// Fator aplicado à confiança durante `held`.
    public var heldConfidenceFactor: Float = 0.7

    // MARK: Seleção do sujeito

    /// Pesos do score (área, proximidade do centro, persistência).
    public var areaWeight: Double = 0.5
    public var centralityWeight: Double = 0.3
    public var persistenceWeight: Double = 0.2
    /// Área (fração do frame) a partir da qual o termo de área satura em 1.
    public var areaSaturation: Double = 0.15
    /// Quanto o desafiante precisa superar o sujeito atual em score...
    public var switchMargin: Double = 0.15
    /// ...e por quanto tempo (s) seguido, antes de a troca de alvo acontecer.
    public var switchDwell: Double = 2.0

    // MARK: Escolha manual do sujeito

    /// Ponto (coordenadas normalizadas de exibição, origem no topo-esquerdo) que o usuário
    /// tocou no primeiro quadro. Se existir, a PRIMEIRA escolha de sujeito é a pessoa mais
    /// próxima desse ponto, e o sujeito fica travado (não troca sozinho por outra pessoa).
    public var subjectHint: CGPoint? = nil
    /// Distância máxima (normalizada) entre o ponto tocado e a caixa de uma pessoa para valer.
    public var hintMaxDistance: Double = 0.10

    // MARK: Vision

    /// Força o Vision a rodar só na CPU. O padrão (false) deixa o sistema usar GPU/Neural Engine.
    /// Serve para ambientes sem GPU (ex.: máquinas virtuais de CI), onde o Vision falha com
    /// "Could not create inference context".
    public var visionCPUOnly: Bool = false

    public init() {}

    public static let `default` = TrackingSettings()
}
