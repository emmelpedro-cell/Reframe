import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Os seis números de `AVAssetTrack.preferredTransform` (mesma convenção do
/// `CGAffineTransform`): x' = a·x + c·y + tx ; y' = b·x + d·y + ty.
/// Atua em PIXELS com origem no topo-esquerdo e +Y para baixo.
public struct PreferredTransform: Equatable, Sendable {
    public var a: Double, b: Double, c: Double, d: Double, tx: Double, ty: Double

    public init(a: Double, b: Double, c: Double, d: Double, tx: Double, ty: Double) {
        self.a = a; self.b = b; self.c = c; self.d = d; self.tx = tx; self.ty = ty
    }

    public static let identity = PreferredTransform(a: 1, b: 0, c: 0, d: 1, tx: 0, ty: 0)

    /// Matrizes típicas gravadas pelo iPhone para um vídeo com pixels
    /// `naturalWidth × naturalHeight` (ex.: 1920×1080).
    ///
    /// iPhone em retrato (home embaixo): rotação de 90° horário.
    public static func rotated90Clockwise(naturalHeight h: Double) -> PreferredTransform {
        PreferredTransform(a: 0, b: 1, c: -1, d: 0, tx: h, ty: 0)
    }
    /// Rotação de 180° (landscape com o telefone "de cabeça para baixo").
    public static func rotated180(naturalWidth w: Double, naturalHeight h: Double) -> PreferredTransform {
        PreferredTransform(a: -1, b: 0, c: 0, d: -1, tx: w, ty: h)
    }
    /// Rotação de 90° anti-horário.
    public static func rotated90CounterClockwise(naturalWidth w: Double) -> PreferredTransform {
        PreferredTransform(a: 0, b: -1, c: 1, d: 0, tx: 0, ty: w)
    }

    public var determinant: Double { a * d - b * c }

    func apply(x: Double, y: Double) -> (x: Double, y: Double) {
        return (a * x + c * y + tx, b * x + d * y + ty)
    }

    func applyInverse(x: Double, y: Double) -> (x: Double, y: Double)? {
        let det = determinant
        guard det.isFinite, abs(det) > 1e-12 else { return nil }
        let px = x - tx, py = y - ty
        return ((d * px - c * py) / det, (-b * px + a * py) / det)
    }
}

/// Mapeia caixas entre o espaço CRU do buffer decodificado ("raw": pixels como
/// estão no arquivo, sem `preferredTransform`) e o espaço de EXIBIÇÃO
/// (a orientação que o usuário vê, que é a que o ReframeCore espera).
///
/// Ambos os espaços usam a convenção do ReframeCore: normalizado, origem no
/// topo-esquerdo, +Y para baixo.
///
/// Por que existe: o vídeo de um iPhone em retrato é FISICAMENTE landscape
/// (1920×1080) com um `preferredTransform` de 90°. O Vision enxerga os pixels
/// crus; se esquecermos o transform, as coordenadas ficam na orientação errada.
public struct DisplayMapping: Equatable, Sendable {
    public let naturalWidth: Double
    public let naturalHeight: Double
    public let transform: PreferredTransform
    /// Tamanho em pixels do vídeo como exibido (já com o transform).
    public let displayWidth: Double
    public let displayHeight: Double

    private let originX: Double
    private let originY: Double

    /// Retorna nil se as dimensões ou o transform forem inválidos.
    public init?(naturalWidth: Double, naturalHeight: Double, transform: PreferredTransform = .identity) {
        guard naturalWidth.isFinite, naturalHeight.isFinite, naturalWidth > 0, naturalHeight > 0,
              transform.determinant.isFinite, abs(transform.determinant) > 1e-12 else { return nil }
        self.naturalWidth = naturalWidth
        self.naturalHeight = naturalHeight
        self.transform = transform

        // Caixa delimitadora do retângulo cru depois do transform. Usamos o
        // canto mínimo (e não tx/ty) como origem, assim o resultado fica certo
        // mesmo que tx/ty venham com algum deslocamento.
        let corners = [(0.0, 0.0), (naturalWidth, 0.0), (0.0, naturalHeight), (naturalWidth, naturalHeight)]
            .map { transform.apply(x: $0.0, y: $0.1) }
        let minX = corners.map { $0.x }.min()!
        let maxX = corners.map { $0.x }.max()!
        let minY = corners.map { $0.y }.min()!
        let maxY = corners.map { $0.y }.max()!
        self.originX = minX
        self.originY = minY
        self.displayWidth = maxX - minX
        self.displayHeight = maxY - minY
    }

    /// largura / altura como exibido.
    public var displayAspect: Double { displayWidth / displayHeight }

    /// true se o transform troca largura e altura (rotação de 90°/270°).
    public var swapsAxes: Bool { abs(transform.a) < 1e-9 && abs(transform.d) < 1e-9 }

    /// Caixa crua (topo-esquerdo, normalizada no buffer cru) → caixa de exibição.
    public func rawToDisplay(_ raw: CGRect) -> CGRect {
        return mapRect(raw) { px, py in
            let p = self.transform.apply(x: px * self.naturalWidth, y: py * self.naturalHeight)
            return ((p.x - self.originX) / self.displayWidth, (p.y - self.originY) / self.displayHeight)
        }
    }

    /// Caixa de exibição → caixa crua. (Inversa de `rawToDisplay`.)
    public func displayToRaw(_ display: CGRect) -> CGRect {
        return mapRect(display) { px, py in
            let x = px * self.displayWidth + self.originX
            let y = py * self.displayHeight + self.originY
            guard let r = self.transform.applyInverse(x: x, y: y) else { return (px, py) }
            return (r.x / self.naturalWidth, r.y / self.naturalHeight)
        }
    }

    private func mapRect(_ rect: CGRect, _ f: (Double, Double) -> (Double, Double)) -> CGRect {
        let xs = [Double(rect.minX), Double(rect.maxX)]
        let ys = [Double(rect.minY), Double(rect.maxY)]
        var mapped: [(Double, Double)] = []
        for x in xs { for y in ys { mapped.append(f(x, y)) } }
        let minX = mapped.map { $0.0 }.min()!
        let maxX = mapped.map { $0.0 }.max()!
        let minY = mapped.map { $0.1 }.min()!
        let maxY = mapped.map { $0.1 }.max()!
        return CGRect(x: CGFloat(minX), y: CGFloat(minY), width: CGFloat(maxX - minX), height: CGFloat(maxY - minY))
    }
}
