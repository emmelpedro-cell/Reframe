import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// ÚNICO lugar que conhece a diferença entre a convenção do Vision e a do
/// ReframeCore.
///
///   • Vision:      normalizado, origem no canto INFERIOR-esquerdo, +Y para CIMA.
///   • ReframeCore: normalizado, origem no canto SUPERIOR-esquerdo, +Y para BAIXO.
///
/// A conversão é só a inversão do eixo Y (e é a sua própria inversa).
/// Esta parte é pura (sem importar Vision), então roda e é testada no Linux.
public enum VisionCoordinates {

    /// Vision (origem embaixo) → convenção do ReframeCore (origem no topo).
    public static func toTopLeft(_ visionRect: CGRect) -> CGRect {
        return CGRect(
            x: visionRect.origin.x,
            y: 1 - visionRect.origin.y - visionRect.height,
            width: visionRect.width,
            height: visionRect.height
        )
    }

    /// Convenção do ReframeCore (origem no topo) → Vision (origem embaixo).
    public static func toVision(_ topLeftRect: CGRect) -> CGRect {
        return CGRect(
            x: topLeftRect.origin.x,
            y: 1 - topLeftRect.origin.y - topLeftRect.height,
            width: topLeftRect.width,
            height: topLeftRect.height
        )
    }
}
