import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Operações puras sobre caixas normalizadas (origem topo-esquerdo, +Y baixo).
public enum BoxMath {

    public static func area(_ r: CGRect) -> Double {
        guard isValid(r) else { return 0 }
        return Double(r.width) * Double(r.height)
    }

    public static func center(_ r: CGRect) -> (x: Double, y: Double) {
        return (Double(r.midX), Double(r.midY))
    }

    public static func isValid(_ r: CGRect) -> Bool {
        return r.origin.x.isFinite && r.origin.y.isFinite
            && r.width.isFinite && r.height.isFinite
            && r.width > 0 && r.height > 0
    }

    /// Interseção sobre união, 0...1. Caixas inválidas dão 0.
    public static func iou(_ a: CGRect, _ b: CGRect) -> Double {
        guard isValid(a), isValid(b) else { return 0 }
        let ix = max(0, min(Double(a.maxX), Double(b.maxX)) - max(Double(a.minX), Double(b.minX)))
        let iy = max(0, min(Double(a.maxY), Double(b.maxY)) - max(Double(a.minY), Double(b.minY)))
        let inter = ix * iy
        let union = area(a) + area(b) - inter
        guard union > 0 else { return 0 }
        return inter / union
    }

    /// Distância euclidiana entre centros (em unidades normalizadas).
    public static func centerDistance(_ a: CGRect, _ b: CGRect) -> Double {
        let ca = center(a), cb = center(b)
        let dx = ca.x - cb.x, dy = ca.y - cb.y
        return (dx * dx + dy * dy).squareRoot()
    }

    /// menor área / maior área (0...1). Inválidas dão 0.
    public static func areaRatio(_ a: CGRect, _ b: CGRect) -> Double {
        let aa = area(a), ab = area(b)
        guard aa > 0, ab > 0 else { return 0 }
        return min(aa, ab) / max(aa, ab)
    }

    /// Recorta a caixa para dentro de 0...1. Devolve nil se não sobrar área.
    public static func clampedToUnit(_ r: CGRect) -> CGRect? {
        guard r.origin.x.isFinite, r.origin.y.isFinite, r.width.isFinite, r.height.isFinite else { return nil }
        let x0 = max(0, min(1, Double(r.minX)))
        let y0 = max(0, min(1, Double(r.minY)))
        let x1 = max(0, min(1, Double(r.maxX)))
        let y1 = max(0, min(1, Double(r.maxY)))
        guard x1 > x0, y1 > y0 else { return nil }
        return CGRect(x: CGFloat(x0), y: CGFloat(y0), width: CGFloat(x1 - x0), height: CGFloat(y1 - y0))
    }
}
