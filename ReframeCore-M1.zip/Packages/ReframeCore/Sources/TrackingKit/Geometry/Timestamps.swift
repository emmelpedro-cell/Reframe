import Foundation

/// Normaliza timestamps de frames: o primeiro vira 0 e a sequência fica
/// estritamente crescente. Frames com tempo inválido, repetido ou que voltam
/// no tempo são descartados (devolve nil). Sem estado global.
public struct TimestampNormalizer: Equatable, Sendable {
    private var origin: Double?
    private var last: Double?

    public init() {}

    public mutating func normalize(_ seconds: Double) -> Double? {
        guard seconds.isFinite else { return nil }
        if origin == nil { origin = seconds }
        let t = seconds - origin!
        if let l = last, t <= l { return nil }
        last = t
        return t
    }

    /// fps estimado pela mediana dos intervalos (robusta a jitter). nil se < 2 amostras.
    public static func estimatedFPS(times: [Double]) -> Double? {
        guard times.count >= 2 else { return nil }
        var deltas: [Double] = []
        for i in 1..<times.count {
            let d = times[i] - times[i - 1]
            if d.isFinite, d > 0 { deltas.append(d) }
        }
        guard !deltas.isEmpty else { return nil }
        deltas.sort()
        let mid = deltas.count / 2
        let median = deltas.count % 2 == 1 ? deltas[mid] : (deltas[mid - 1] + deltas[mid]) / 2
        return median > 0 ? 1 / median : nil
    }
}

/// Decide QUANDO rodar uma detecção. Só a regra de tempo; quem detecta é outro.
public struct RedetectionScheduler: Equatable, Sendable {
    public let interval: Double
    private var lastDetection: Double?

    public init(interval: Double) {
        self.interval = (interval.isFinite && interval > 0) ? interval : 0.5
    }

    /// true na primeira chamada, quando `force` é true (ex.: ainda sem sujeito
    /// ou sujeito perdido) ou quando passou `interval` desde a última detecção.
    public mutating func shouldDetect(at time: Double, force: Bool = false) -> Bool {
        let due: Bool
        if let last = lastDetection {
            due = time - last >= interval - 1e-9
        } else {
            due = true
        }
        if due || force {
            lastDetection = time
            return true
        }
        return false
    }
}
