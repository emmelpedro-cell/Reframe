import Foundation
#if canImport(AVFoundation) && canImport(Vision)
import AVFoundation
import CoreVideo
import CoreMedia
import CoreText
import ReframeCore
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Gera um MP4 de debug: o vídeo original (resolução de análise) com a caixa
/// rastreada, confiança, estado, ID do sujeito e, opcionalmente, a janela de
/// crop 9:16 calculada pelo ReframeEngine.
///
/// Os frames são desenhados no espaço CRU e o MP4 recebe o mesmo
/// preferredTransform do original; assim, ao tocar, tudo aparece na orientação
/// correta — e se a conversão de coordenadas estivesse errada, a caixa não
/// ficaria em cima da pessoa. Isso é o teste visual do preferredTransform.
public enum DebugVideoWriter {

    public static func write(reader: VideoFrameReader,
                             report: TrackingReport,
                             to outputURL: URL,
                             showCrop: Bool,
                             maxSeconds: Double? = nil) throws {
        let info = reader.info
        let mapping = info.mapping

        // Janela de crop (opcional): trajetória do engine M1 a partir do mesmo report.
        var cropPoints: [CropPoint] = []
        var cropWidth: Double = 0
        if showCrop, mapping.displayAspect > 9.0 / 16.0 {
            let engine = ReframeEngine(sourceAspect: mapping.displayAspect, outputAspect: 9.0 / 16.0)
            cropWidth = engine.geometry.cropWidth
            let fps = report.fps > 0 ? report.fps : 30
            cropPoints = engine.trajectory(for: report.toSubjectTrack(), fps: fps, timeRange: 0...max(report.duration, 0.001))
        }

        try? FileManager.default.removeItem(at: outputURL)
        let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: info.analysisWidth,
            AVVideoHeightKey: info.analysisHeight
        ])
        input.expectsMediaDataInRealTime = false
        let t = mapping.transform
        input.transform = CGAffineTransform(a: CGFloat(t.a), b: CGFloat(t.b), c: CGFloat(t.c),
                                            d: CGFloat(t.d), tx: CGFloat(t.tx), ty: CGFloat(t.ty))
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: info.analysisWidth,
            kCVPixelBufferHeightKey as String: info.analysisHeight
        ])
        guard writer.canAdd(input) else { throw TrackingError.cannotStartReading("writer sem suporte") }
        writer.add(input)
        guard writer.startWriting() else {
            throw TrackingError.readingFailed(writer.error.map { "\($0)" } ?? "writer não iniciou")
        }
        writer.startSession(atSourceTime: .zero)

        var normalizer = TimestampNormalizer()
        var pointIndex = 0
        let points = report.points

        try reader.forEachFrame(maxSeconds: maxSeconds) { pixels, pts in
            guard let time = normalizer.normalize(pts) else { return }

            while pointIndex + 1 < points.count, points[pointIndex + 1].time <= time + 1e-6 { pointIndex += 1 }
            let point = points.isEmpty ? nil : points[pointIndex]

            var cropCenter: Double?
            if !cropPoints.isEmpty {
                cropCenter = Double(nearestCrop(cropPoints, at: time).centerX)
            }
            DebugOverlay.draw(on: pixels, point: point, time: time, mapping: mapping,
                              cropCenterX: cropCenter, cropWidth: cropWidth)

            while !input.isReadyForMoreMediaData { Thread.sleep(forTimeInterval: 0.001) }
            let cmTime = CMTime(seconds: time, preferredTimescale: 600)
            if !adaptor.append(pixels, withPresentationTime: cmTime) {
                throw TrackingError.readingFailed(writer.error.map { "\($0)" } ?? "append falhou")
            }
        }

        input.markAsFinished()
        let done = DispatchSemaphore(value: 0)
        writer.finishWriting { done.signal() }
        done.wait()
        if writer.status != .completed {
            throw TrackingError.readingFailed(writer.error.map { "\($0)" } ?? "writer terminou com status \(writer.status.rawValue)")
        }
    }

    private static func nearestCrop(_ pts: [CropPoint], at time: Double) -> CropPoint {
        var lo = 0, hi = pts.count - 1
        while lo < hi {
            let mid = (lo + hi) / 2
            if pts[mid].time < time { lo = mid + 1 } else { hi = mid }
        }
        if lo > 0, abs(pts[lo - 1].time - time) <= abs(pts[lo].time - time) { return pts[lo - 1] }
        return pts[lo]
    }
}

enum DebugOverlay {
    static func draw(on pixelBuffer: CVPixelBuffer, point: TrackingReport.Point?, time: Double,
                     mapping: DisplayMapping, cropCenterX: Double?, cropWidth: Double) {
        CVPixelBufferLockBaseAddress(pixelBuffer, [])
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, []) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return }
        let w = CVPixelBufferGetWidth(pixelBuffer), h = CVPixelBufferGetHeight(pixelBuffer)
        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
        let bitmap = CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        guard let ctx = CGContext(data: base, width: w, height: h, bitsPerComponent: 8, bytesPerRow: bytesPerRow,
                                  space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: bitmap) else { return }

        let W = CGFloat(w), H = CGFloat(h)
        let line = max(2, W / 320)

        // Normalizado topo-esquerdo (espaço cru) → retângulo do contexto (origem embaixo).
        func rectInContext(_ raw: CGRect) -> CGRect {
            CGRect(x: raw.minX * W, y: (1 - raw.maxY) * H, width: raw.width * W, height: raw.height * H)
        }

        // Janela de crop 9:16 (azul-claro).
        if let cx = cropCenterX, cropWidth > 0 {
            let display = CGRect(x: CGFloat(cx - cropWidth / 2), y: 0, width: CGFloat(cropWidth), height: 1)
            ctx.setStrokeColor(CGColor(red: 0.2, green: 0.8, blue: 1, alpha: 1))
            ctx.setLineWidth(line)
            ctx.stroke(rectInContext(mapping.displayToRaw(display)))
        }

        var label = String(format: "t %.2fs", time)
        if let p = point {
            let color: CGColor
            switch p.state {
            case .tracking: color = CGColor(red: 0.1, green: 1, blue: 0.2, alpha: 1)
            case .held: color = CGColor(red: 1, green: 0.85, blue: 0.1, alpha: 1)
            case .lost: color = CGColor(red: 1, green: 0.2, blue: 0.2, alpha: 1)
            case .acquiring: color = CGColor(red: 0.7, green: 0.7, blue: 0.7, alpha: 1)
            }
            if let b = p.boundingBox {
                ctx.setStrokeColor(color)
                ctx.setLineWidth(line)
                ctx.stroke(rectInContext(mapping.displayToRaw(b.rect)))
            }
            let id = p.subjectID.map { "ID \($0)" } ?? "ID -"
            label += String(format: " | %@ | %@ | conf %.2f", id, p.state.rawValue, p.confidence)
        } else {
            label += " | sem dados"
        }

        // Rótulo com fundo escuro, desenhado na orientação de EXIBIÇÃO: o MP4 de debug leva o
        // mesmo preferredTransform do original, então o texto é pré-girado no espaço cru para
        // aparecer de pé no player.
        let fontSize = max(12, W / 48)
        let font = CTFontCreateWithName("Menlo-Bold" as CFString, fontSize, nil)
        let attrs: [NSAttributedString.Key: Any] = [
            NSAttributedString.Key(rawValue: kCTFontAttributeName as String): font,
            NSAttributedString.Key(rawValue: kCTForegroundColorAttributeName as String): CGColor(red: 1, green: 1, blue: 1, alpha: 1)
        ]
        let ctLine = CTLineCreateWithAttributedString(NSAttributedString(string: label, attributes: attrs))
        let bounds = CTLineGetBoundsWithOptions(ctLine, [])
        let boxW = bounds.width + fontSize
        let boxH = bounds.height + fontSize * 0.8

        // Canto superior-esquerdo da TELA, em coordenadas do buffer cru.
        let anchorRaw = mapping.displayToRaw(CGRect(x: 0, y: 0, width: 0, height: 0))
        let t = mapping.transform
        let angle = CGFloat(atan2(t.b, t.a))     // rotação (horária, em y-para-baixo) que o player aplica

        ctx.saveGState()
        ctx.translateBy(x: anchorRaw.origin.x * W, y: (1 - anchorRaw.origin.y) * H)
        ctx.rotate(by: angle)                    // eixos locais = eixos da tela (x → direita, y → cima)
        ctx.setFillColor(CGColor(red: 0, green: 0, blue: 0, alpha: 0.65))
        ctx.fill(CGRect(x: 0, y: -boxH, width: boxW, height: boxH))
        ctx.textPosition = CGPoint(x: fontSize / 2, y: -boxH + fontSize * 0.4)
        CTLineDraw(ctLine, ctx)
        ctx.restoreGState()
    }
}
#endif
