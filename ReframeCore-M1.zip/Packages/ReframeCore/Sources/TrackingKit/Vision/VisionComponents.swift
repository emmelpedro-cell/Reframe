import Foundation
#if canImport(AVFoundation) && canImport(Vision)
import Vision
import ImageIO
import CoreVideo
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Quem encontra pessoas num frame. As caixas saem no espaço CRU do buffer
/// (convenção do ReframeCore: normalizado, topo-esquerdo, +Y baixo).
/// Protocolo para permitir um detector falso nos testes de integração.
public protocol HumanDetecting {
    func detect(in pixelBuffer: CVPixelBuffer) throws -> [Observation]
}

/// Detecção periódica: VNDetectHumanRectanglesRequest (corpo inteiro).
public final class VisionHumanDetector: HumanDetecting {
    private let handler = VNSequenceRequestHandler()
    private let cpuOnly: Bool

    public init(cpuOnly: Bool = false) {
        self.cpuOnly = cpuOnly
    }

    public func detect(in pixelBuffer: CVPixelBuffer) throws -> [Observation] {
        let request = VNDetectHumanRectanglesRequest()
        request.upperBodyOnly = false
        if cpuOnly { request.usesCPUOnly = true }
        do {
            try handler.perform([request], on: pixelBuffer, orientation: .up)
        } catch {
            throw TrackingError.visionFailed("\(error)")
        }
        let results = request.results ?? []
        return results.map {
            Observation(box: VisionCoordinates.toTopLeft($0.boundingBox), confidence: $0.confidence)
        }
    }
}

/// Tracking entre detecções: VNTrackObjectRequest + VNSequenceRequestHandler.
public final class VisionObjectTracker {
    private var handler = VNSequenceRequestHandler()
    private var last: VNDetectedObjectObservation?
    private let cpuOnly: Bool

    public init(cpuOnly: Bool = false) {
        self.cpuOnly = cpuOnly
    }

    public var isActive: Bool { last != nil }

    /// Passa a seguir `rawBox` (topo-esquerdo, normalizado, espaço cru).
    public func seed(rawBox: CGRect) {
        handler = VNSequenceRequestHandler()
        last = VNDetectedObjectObservation(boundingBox: VisionCoordinates.toVision(rawBox))
    }

    public func reset() {
        last = nil
    }

    /// Acompanha o objeto no frame. nil se o Vision não devolveu resultado.
    public func track(_ pixelBuffer: CVPixelBuffer) throws -> Observation? {
        guard let observation = last else { return nil }
        let request = VNTrackObjectRequest(detectedObjectObservation: observation)
        request.trackingLevel = .accurate
        if cpuOnly { request.usesCPUOnly = true }
        try handler.perform([request], on: pixelBuffer, orientation: .up)
        guard let result = request.results?.first as? VNDetectedObjectObservation else {
            last = nil
            return nil
        }
        last = result
        return Observation(box: VisionCoordinates.toTopLeft(result.boundingBox), confidence: result.confidence)
    }
}
#endif
