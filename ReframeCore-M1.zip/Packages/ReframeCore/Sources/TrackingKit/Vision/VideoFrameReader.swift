import Foundation
#if canImport(AVFoundation) && canImport(Vision)
import AVFoundation
import CoreVideo
import CoreMedia
#if canImport(CoreGraphics)
import CoreGraphics
#endif

public enum TrackingError: Error, CustomStringConvertible {
    case noVideoTrack
    case invalidGeometry
    case cannotStartReading(String)
    case readingFailed(String)
    case visionFailed(String)

    public var description: String {
        switch self {
        case .noVideoTrack: return "o arquivo não tem trilha de vídeo"
        case .invalidGeometry: return "dimensões ou preferredTransform inválidos"
        case .cannotStartReading(let m): return "não foi possível ler o vídeo: \(m)"
        case .readingFailed(let m): return "falha durante a leitura do vídeo: \(m)"
        case .visionFailed(let m): return "falha no Vision: \(m)"
        }
    }
}

public struct VideoInfo: Sendable {
    /// Mapeamento cru ⇄ exibição (preferredTransform já incluído).
    public let mapping: DisplayMapping
    public let nominalFPS: Double
    public let duration: Double
    /// Tamanho (px) dos buffers decodificados para análise (espaço cru).
    public let analysisWidth: Int
    public let analysisHeight: Int
}

/// Lê um vídeo em resolução reduzida (≈ `analysisWidth`), em ordem de
/// apresentação. Os buffers saem CRUS, sem o preferredTransform: quem converte
/// para a orientação visual é o `DisplayMapping`. O arquivo original não é
/// modificado e continua sendo a fonte do futuro render.
public final class VideoFrameReader {
    public let url: URL
    public let info: VideoInfo
    private let asset: AVURLAsset
    private let track: AVAssetTrack

    private init(url: URL, asset: AVURLAsset, track: AVAssetTrack, info: VideoInfo) {
        self.url = url; self.asset = asset; self.track = track; self.info = info
    }

    public static func open(url: URL, analysisWidth: Int) async throws -> VideoFrameReader {
        let asset = AVURLAsset(url: url)
        let tracks = try await asset.loadTracks(withMediaType: .video)
        guard let track = tracks.first else { throw TrackingError.noVideoTrack }

        let natural = try await track.load(.naturalSize)
        let t = try await track.load(.preferredTransform)
        let fps = try await track.load(.nominalFrameRate)
        let duration = try await asset.load(.duration)

        let transform = PreferredTransform(a: Double(t.a), b: Double(t.b), c: Double(t.c),
                                           d: Double(t.d), tx: Double(t.tx), ty: Double(t.ty))
        guard let mapping = DisplayMapping(naturalWidth: Double(natural.width),
                                           naturalHeight: Double(natural.height),
                                           transform: transform) else {
            throw TrackingError.invalidGeometry
        }

        func even(_ v: Int) -> Int { max(2, v - (v % 2)) }
        let aw = even(min(max(analysisWidth, 2), Int(natural.width)))
        let ah = even(Int((Double(aw) * Double(natural.height) / Double(natural.width)).rounded()))

        let seconds = CMTimeGetSeconds(duration)
        let info = VideoInfo(mapping: mapping,
                             nominalFPS: fps.isFinite ? Double(fps) : 0,
                             duration: seconds.isFinite ? seconds : 0,
                             analysisWidth: aw, analysisHeight: ah)
        return VideoFrameReader(url: url, asset: asset, track: track, info: info)
    }

    /// Percorre os frames. `body` recebe o buffer cru e o PTS em segundos
    /// (ainda NÃO normalizado: use `TimestampNormalizer`).
    public func forEachFrame(maxSeconds: Double? = nil,
                             _ body: (CVPixelBuffer, Double) throws -> Void) throws {
        let reader: AVAssetReader
        do { reader = try AVAssetReader(asset: asset) }
        catch { throw TrackingError.cannotStartReading("\(error)") }

        let settings: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: info.analysisWidth,
            kCVPixelBufferHeightKey as String: info.analysisHeight
        ]
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: settings)
        output.alwaysCopiesSampleData = false
        guard reader.canAdd(output) else { throw TrackingError.cannotStartReading("saída não suportada") }
        reader.add(output)
        guard reader.startReading() else {
            throw TrackingError.cannotStartReading(reader.error.map { "\($0)" } ?? "desconhecido")
        }

        var firstPTS: Double?
        while true {
            var stop = false
            try autoreleasepool {
                guard let sample = output.copyNextSampleBuffer() else { stop = true; return }
                guard let pixels = CMSampleBufferGetImageBuffer(sample) else { return }
                let pts = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
                if firstPTS == nil, pts.isFinite { firstPTS = pts }
                if let limit = maxSeconds, let f = firstPTS, pts.isFinite, pts - f > limit { stop = true; return }
                try body(pixels, pts)
            }
            if stop { break }
        }
        if reader.status == .failed {
            throw TrackingError.readingFailed(reader.error.map { "\($0)" } ?? "desconhecido")
        }
        if reader.status == .reading { reader.cancelReading() }
    }
}
#endif
