import Foundation
#if canImport(AVFoundation) && canImport(Vision)
import AVFoundation
import Vision
import CoreVideo
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Primeiro quadro do vídeo (já em pé) e as pessoas detectadas nele, para o usuário tocar
/// em quem deve aparecer. As caixas estão em coordenadas normalizadas de exibição
/// (0...1, topo-esquerdo), as mesmas do tracking.
public struct PersonPreviewResult {
    public let image: CGImage
    public let people: [CGRect]
}

public enum PersonPreview {
    private struct StopReading: Error {}

    public static func firstFrame(url: URL, settings: TrackingSettings = .default) async throws -> PersonPreviewResult {
        // 1) Pessoas no primeiro quadro (mesmo caminho do tracking: mesmo mapeamento).
        let reader = try await VideoFrameReader.open(url: url, analysisWidth: settings.analysisWidth)
        let mapping = reader.info.mapping
        let detector = VisionHumanDetector(cpuOnly: settings.visionCPUOnly)
        var people: [CGRect] = []
        do {
            try reader.forEachFrame { pixels, _ in
                let found = try detector.detect(in: pixels)
                people = found
                    .filter { $0.confidence.isFinite && $0.confidence >= settings.minDetectionConfidence }
                    .compactMap { BoxMath.clampedToUnit(mapping.rawToDisplay($0.box)) }
                throw StopReading()
            }
        } catch is StopReading {}
        people.sort { $0.minX < $1.minX }

        // 2) Imagem do primeiro quadro, já girada para ficar em pé.
        let asset = AVURLAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 1280, height: 1280)
        generator.requestedTimeToleranceBefore = .positiveInfinity
        generator.requestedTimeToleranceAfter = .positiveInfinity
        let (image, _) = try await generator.image(at: .zero)
        return PersonPreviewResult(image: image, people: people)
    }
}
#endif
