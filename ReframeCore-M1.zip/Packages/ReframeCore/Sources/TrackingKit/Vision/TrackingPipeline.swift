import Foundation
#if canImport(AVFoundation) && canImport(Vision)
import AVFoundation
import Vision
import CoreVideo
#if canImport(CoreGraphics)
import CoreGraphics
#endif

public struct TrackingResult {
    public let report: TrackingReport
    public let frames: [TrackedFrame]
    public let info: VideoInfo
    /// Frames em que o VNTrackObjectRequest lançou erro (tratados como "tracker perdeu").
    public let trackerErrors: Int
    public let droppedTimestamps: Int
    /// Mensagem do último erro do VNTrackObjectRequest (nil se não houve erro).
    public let lastTrackerError: String?
}

/// Master.mov → decode reduzido → detecção periódica + tracking entre detecções
/// → SubjectTracker → TrackingReport / SubjectTrack.
public final class TrackingPipeline {
    public let settings: TrackingSettings
    private let detector: HumanDetecting

    /// `detector == nil` usa o `VisionHumanDetector` real (respeitando `settings.visionCPUOnly`).
    public init(settings: TrackingSettings = .default, detector: HumanDetecting? = nil) {
        self.settings = settings
        self.detector = detector ?? VisionHumanDetector(cpuOnly: settings.visionCPUOnly)
    }

    public func run(url: URL, maxSeconds: Double? = nil,
                    progress: ((Double) -> Void)? = nil) async throws -> TrackingResult {
        let reader = try await VideoFrameReader.open(url: url, analysisWidth: settings.analysisWidth)
        let info = reader.info
        let mapping = info.mapping

        var normalizer = TimestampNormalizer()
        var scheduler = RedetectionScheduler(interval: settings.redetectInterval)
        var tracker = SubjectTracker(settings: settings)
        let objectTracker = VisionObjectTracker(cpuOnly: settings.visionCPUOnly)

        var frames: [TrackedFrame] = []
        var trackerErrors = 0
        var lastTrackerError: String?
        var dropped = 0

        func toDisplay(_ o: Observation) -> Observation? {
            guard let box = BoxMath.clampedToUnit(mapping.rawToDisplay(o.box)) else { return nil }
            return Observation(box: box, confidence: o.confidence)
        }

        try reader.forEachFrame(maxSeconds: maxSeconds) { pixels, pts in
            guard let t = normalizer.normalize(pts) else { dropped += 1; return }

            var tracked: Observation?
            if objectTracker.isActive {
                do {
                    if let raw = try objectTracker.track(pixels) { tracked = toDisplay(raw) }
                } catch {
                    trackerErrors += 1
                    lastTrackerError = "\(error)"
                    objectTracker.reset()
                }
            }

            var detections: [Observation]?
            if scheduler.shouldDetect(at: t, force: tracker.needsDetection) {
                detections = try detector.detect(in: pixels).compactMap(toDisplay)
            }

            let frame = tracker.update(time: t, tracked: tracked, detections: detections)
            frames.append(frame)

            // Depois de uma detecção, re-ancora o tracker do Vision no box aceito.
            if detections != nil, frame.state == .tracking, let box = frame.box {
                objectTracker.seed(rawBox: mapping.displayToRaw(box))
            }
            if info.duration > 0 { progress?(min(1, t / info.duration)) }
        }

        let times = frames.map { $0.time }
        let fps = info.nominalFPS > 0 ? info.nominalFPS : (TimestampNormalizer.estimatedFPS(times: times) ?? 0)
        let duration = max(info.duration, times.last ?? 0)
        let report = TrackingReport(
            frames: frames, duration: duration, fps: fps,
            displaySize: .init(width: mapping.displayWidth, height: mapping.displayHeight),
            analysisSize: .init(width: Double(info.analysisWidth), height: Double(info.analysisHeight))
        )
        return TrackingResult(report: report, frames: frames, info: info,
                              trackerErrors: trackerErrors, droppedTimestamps: dropped,
                              lastTrackerError: lastTrackerError)
    }
}
#endif
