import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Escolhe QUEM é o sujeito. Funções puras e determinísticas.
///
/// Score = areaWeight·área + centralityWeight·centralidade + persistenceWeight·persistência
///   • área:          min(1, área / areaSaturation)
///   • centralidade:  1 − distância(centro, (0,5; 0,5)) / 0,7071  (0...1)
///   • persistência:  IoU com o box do sujeito atual (0 se não houver)
public struct SubjectSelector: Sendable {
    public let settings: TrackingSettings

    public init(settings: TrackingSettings = .default) {
        self.settings = settings
    }

    /// Detecções que valem a pena considerar.
    public func usable(_ detections: [Observation]) -> [Observation] {
        return detections.filter {
            $0.confidence.isFinite && $0.confidence >= settings.minDetectionConfidence
                && BoxMath.isValid($0.box)
        }
    }

    public func score(box: CGRect, incumbent: CGRect?) -> Double {
        let area = min(1, BoxMath.area(box) / max(settings.areaSaturation, 1e-9))
        let c = BoxMath.center(box)
        let dist = ((c.x - 0.5) * (c.x - 0.5) + (c.y - 0.5) * (c.y - 0.5)).squareRoot()
        let centrality = max(0, 1 - dist / 0.70710678118654752)
        let persistence = incumbent.map { BoxMath.iou(box, $0) } ?? 0
        return settings.areaWeight * area
            + settings.centralityWeight * centrality
            + settings.persistenceWeight * persistence
    }

    /// Escolha inicial (sem sujeito atual). Desempate determinístico:
    /// maior score, depois maior área, depois menor x, depois menor y.
    public func pickInitial(_ detections: [Observation]) -> Observation? {
        let candidates = usable(detections)
        guard !candidates.isEmpty else { return nil }
        return candidates.min { lhs, rhs in
            let sl = score(box: lhs.box, incumbent: nil), sr = score(box: rhs.box, incumbent: nil)
            if sl != sr { return sl > sr }
            let al = BoxMath.area(lhs.box), ar = BoxMath.area(rhs.box)
            if al != ar { return al > ar }
            if lhs.box.minX != rhs.box.minX { return lhs.box.minX < rhs.box.minX }
            return lhs.box.minY < rhs.box.minY
        }
    }

    /// Escolha manual: a pessoa que o usuário tocou. Prefere a caixa que CONTÉM o ponto
    /// (se várias, a de centro mais próximo); senão a caixa mais próxima, até `hintMaxDistance`.
    public func pickNear(_ hint: CGPoint, among detections: [Observation]) -> Observation? {
        let candidates = usable(detections)
        let containing = candidates.filter { $0.box.contains(hint) }
        func centerDistance(_ o: Observation) -> Double {
            let c = BoxMath.center(o.box)
            return ((c.x - hint.x) * (c.x - hint.x) + (c.y - hint.y) * (c.y - hint.y)).squareRoot()
        }
        if !containing.isEmpty {
            return containing.min { centerDistance($0) < centerDistance($1) }
        }
        func edgeDistance(_ o: Observation) -> Double {
            let dx = max(o.box.minX - hint.x, 0, hint.x - o.box.maxX)
            let dy = max(o.box.minY - hint.y, 0, hint.y - o.box.maxY)
            return (dx * dx + dy * dy).squareRoot()
        }
        guard let best = candidates.min(by: { edgeDistance($0) < edgeDistance($1) }),
              edgeDistance(best) <= settings.hintMaxDistance else { return nil }
        return best
    }

    /// Entre as detecções, a que melhor representa `reference` (a pessoa que já
    /// seguimos). Aceita se IoU >= `minIoU` OU, quando `allowProximity`, se o
    /// centro está perto e o tamanho é parecido (recuperação depois de perda).
    public func bestMatch(for reference: CGRect,
                          among detections: [Observation],
                          minIoU: Double,
                          allowProximity: Bool = false) -> Observation? {
        var best: (obs: Observation, iou: Double, dist: Double)?
        for d in usable(detections) {
            let iou = BoxMath.iou(reference, d.box)
            let dist = BoxMath.centerDistance(reference, d.box)
            var ok = iou >= minIoU && iou > 0
            if !ok && allowProximity {
                ok = dist <= settings.recoveryMaxCenterDistance
                    && BoxMath.areaRatio(reference, d.box) >= settings.recoveryMinAreaRatio
            }
            guard ok else { continue }
            if let b = best {
                if iou > b.iou || (iou == b.iou && dist < b.dist) { best = (d, iou, dist) }
            } else {
                best = (d, iou, dist)
            }
        }
        return best?.obs
    }

    /// O melhor desafiante: maior score entre as detecções que NÃO são o
    /// sujeito atual (IoU < reassociationIoU com ele), com persistência 0.
    /// Retorna nil se ninguém supera o sujeito atual por `switchMargin`.
    public func challenger(against incumbent: CGRect, among detections: [Observation]) -> Observation? {
        let incumbentScore = score(box: incumbent, incumbent: incumbent)
        var best: (obs: Observation, score: Double)?
        for d in usable(detections) {
            guard BoxMath.iou(incumbent, d.box) < settings.reassociationIoU else { continue }
            let s = score(box: d.box, incumbent: incumbent)
            if best == nil || s > best!.score { best = (d, s) }
        }
        guard let b = best, b.score > incumbentScore + settings.switchMargin else { return nil }
        return b.obs
    }
}
