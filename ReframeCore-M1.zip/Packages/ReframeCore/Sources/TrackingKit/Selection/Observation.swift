import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Uma caixa de pessoa (detectada ou rastreada) JÁ na convenção do ReframeCore
/// e na orientação de exibição: normalizada, origem no topo-esquerdo, +Y baixo.
public struct Observation: Equatable, Sendable {
    public let box: CGRect
    public let confidence: Float

    public init(box: CGRect, confidence: Float) {
        self.box = box
        self.confidence = confidence
    }
}
