import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

public enum TrackingState: String, Codable, Equatable, Sendable {
    /// Ainda sem sujeito escolhido (nenhuma detecção aceitável até agora).
    case acquiring
    /// Seguindo o sujeito normalmente.
    case tracking
    /// Perda temporária: mantendo o último box válido (dentro de `holdDuration`).
    case held
    /// Perdido além de `holdDuration`. A identidade é guardada até `recoveryWindow`.
    case lost
}

/// Resultado por frame.
public struct TrackedFrame: Equatable, Sendable {
    public let time: Double
    /// nil apenas enquanto nenhum sujeito foi adquirido (`acquiring`).
    public let box: CGRect?
    /// 0 quando `lost`; reduzida quando `held`.
    public let confidence: Float
    public let state: TrackingState
    /// 1, 2, 3... Muda somente quando o alvo é de fato trocado.
    public let subjectID: Int?

    public init(time: Double, box: CGRect?, confidence: Float, state: TrackingState, subjectID: Int?) {
        self.time = time; self.box = box; self.confidence = confidence
        self.state = state; self.subjectID = subjectID
    }
}

/// Máquina de estados que decide a identidade do sujeito. Nada de Vision aqui:
/// recebe `Observation`s e devolve `TrackedFrame`s. A lógica de "trocar de
/// alvo" e de "manter o último box na perda" mora AQUI, não no ReframeEngine.
public struct SubjectTracker: Sendable {
    public let settings: TrackingSettings
    private let selector: SubjectSelector

    public private(set) var subjectID: Int?
    public private(set) var lastBox: CGRect?
    private var lastConfidence: Float = 0
    private var lastGoodTime: Double = 0
    private var nextID: Int = 1

    private var challengerBox: CGRect?
    private var challengerSince: Double = 0
    private var isHealthy = false

    public init(settings: TrackingSettings = .default) {
        self.settings = settings
        self.selector = SubjectSelector(settings: settings)
    }

    /// true enquanto ainda não existe sujeito, ou ele não está sendo seguido
    /// normalmente: o chamador deve rodar detecção a cada frame (ver `RedetectionScheduler`).
    public var needsDetection: Bool {
        return subjectID == nil || !isHealthy
    }

    /// - Parameters:
    ///   - time: segundos desde o início (estritamente crescente).
    ///   - tracked: resultado do tracker neste frame (nil se não há tracker ativo ou ele falhou).
    ///   - detections: resultado da detecção, se ela rodou neste frame (nil = não rodou).
    public mutating func update(time: Double, tracked: Observation?, detections: [Observation]?) -> TrackedFrame {
        // 1) Ainda sem sujeito: tenta escolher um.
        if subjectID == nil {
            if let dets = detections, let pick = selector.pickInitial(dets) {
                startNewSubject(pick, at: time)
                return frame(time, .tracking)
            }
            isHealthy = false
            return TrackedFrame(time: time, box: nil, confidence: 0, state: .acquiring, subjectID: nil)
        }

        var accepted: Observation?

        // 2) Resultado do tracker, se for confiável e contínuo.
        var healthyTracked: Observation?
        if let t = tracked, t.confidence.isFinite, t.confidence >= settings.minTrackingConfidence,
           BoxMath.isValid(t.box) {
            let continuous = lastBox.map { BoxMath.iou($0, t.box) >= settings.minContinuityIoU } ?? true
            if continuous { healthyTracked = t }
        }

        if let dets = detections {
            if let t = healthyTracked {
                // Re-ancora no detector se ele concorda com o tracker...
                let base = selector.bestMatch(for: t.box, among: dets, minIoU: settings.reassociationIoU) ?? t
                // ...e só troca de alvo se um desafiante vencer de forma sustentada.
                accepted = considerSwitch(current: base, detections: dets, time: time) ?? base
            } else if let ref = lastBox {
                // Tracker perdeu: tenta reassociar a MESMA pessoa.
                if let m = selector.bestMatch(for: ref, among: dets,
                                              minIoU: settings.recoveryIoU, allowProximity: true) {
                    accepted = m
                    challengerBox = nil
                } else if time - lastGoodTime > settings.recoveryWindow,
                          let pick = selector.pickInitial(dets) {
                    // Janela esgotada: só agora pode escolher outra pessoa.
                    startNewSubject(pick, at: time)
                    return frame(time, .tracking)
                }
            }
        } else if let t = healthyTracked {
            accepted = t
        }

        if let a = accepted {
            lastBox = a.box
            lastConfidence = a.confidence
            lastGoodTime = time
            isHealthy = true
            return frame(time, .tracking)
        }

        // 3) Perda: mantém o último box dentro da política; sem saltos.
        isHealthy = false
        let elapsed = time - lastGoodTime
        if elapsed <= settings.holdDuration {
            return TrackedFrame(time: time, box: lastBox,
                                confidence: lastConfidence * settings.heldConfidenceFactor,
                                state: .held, subjectID: subjectID)
        }
        return TrackedFrame(time: time, box: lastBox, confidence: 0, state: .lost, subjectID: subjectID)
    }

    // MARK: - Privado

    private mutating func startNewSubject(_ obs: Observation, at time: Double) {
        subjectID = nextID
        nextID += 1
        lastBox = obs.box
        lastConfidence = obs.confidence
        lastGoodTime = time
        challengerBox = nil
        isHealthy = true
    }

    private func frame(_ time: Double, _ state: TrackingState) -> TrackedFrame {
        return TrackedFrame(time: time, box: lastBox, confidence: lastConfidence, state: state, subjectID: subjectID)
    }

    /// Troca de alvo "pegajosa": o desafiante precisa superar o atual por
    /// `switchMargin` continuamente por `switchDwell` segundos.
    /// Devolve o desafiante quando a troca deve acontecer; senão nil.
    private mutating func considerSwitch(current: Observation, detections: [Observation], time: Double) -> Observation? {
        guard let ch = selector.challenger(against: current.box, among: detections) else {
            challengerBox = nil
            return nil
        }
        if let prev = challengerBox, BoxMath.iou(prev, ch.box) >= settings.reassociationIoU {
            challengerBox = ch.box
            if time - challengerSince >= settings.switchDwell {
                // Troca: novo ID.
                subjectID = nextID
                nextID += 1
                challengerBox = nil
                return ch
            }
        } else {
            challengerBox = ch.box
            challengerSince = time
        }
        return nil
    }
}
