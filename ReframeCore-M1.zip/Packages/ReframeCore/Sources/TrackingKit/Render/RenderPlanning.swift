import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
import ReframeCore

// MARK: - Orientação de exibição

/// Rotação que o `preferredTransform` aplica ao vídeo cru para ele ficar de pé.
/// Só rotações de 90° (as que a câmera do iPhone grava). Espelhamentos e
/// transformações arbitrárias não são suportados pelo render (devolve nil).
public enum DisplayOrientation: Equatable, Sendable {
    case up            // identidade
    case clockwise90   // iPhone em retrato
    case rotated180    // iPhone de cabeça para baixo
    case counterClockwise90

    public init?(transform t: PreferredTransform) {
        func near(_ v: Double, _ target: Double) -> Bool { abs(v - target) < 1e-6 }
        if near(t.a, 1), near(t.b, 0), near(t.c, 0), near(t.d, 1) { self = .up }
        else if near(t.a, 0), near(t.b, 1), near(t.c, -1), near(t.d, 0) { self = .clockwise90 }
        else if near(t.a, -1), near(t.b, 0), near(t.c, 0), near(t.d, -1) { self = .rotated180 }
        else if near(t.a, 0), near(t.b, -1), near(t.c, 1), near(t.d, 0) { self = .counterClockwise90 }
        else { return nil }
    }
}

// MARK: - Geometria do vídeo de saída

/// Tamanho do vídeo de saída e posição do recorte, em pixels. Puro e testável.
///
/// O recorte ocupa a altura inteira do frame de exibição (escala fixa, como no
/// ReframeEngine). Com `outputHeight` diferente da altura de exibição, o frame
/// inteiro é escalado ANTES do recorte, assim a janela tem sempre um número
/// inteiro de pixels.
public struct RenderGeometry: Equatable, Sendable {
    public let displayWidth: Int
    public let displayHeight: Int
    /// Fator aplicado ao frame de exibição antes do recorte (outputHeight / displayHeight).
    public let scale: Double
    /// Largura do frame de exibição depois da escala (pode ser fracionária).
    public let scaledWidth: Double
    public let outputWidth: Int
    public let outputHeight: Int

    /// - Parameters:
    ///   - outputAspect: largura / altura da saída (9/16 para vertical).
    ///   - outputHeight: altura desejada; nil = altura do vídeo de exibição.
    /// Retorna nil para entradas inválidas.
    public init?(displayWidth: Int, displayHeight: Int, outputAspect: Double, outputHeight: Int? = nil) {
        guard displayWidth >= 2, displayHeight >= 2, outputAspect.isFinite, outputAspect > 0 else { return nil }
        if let h = outputHeight, h < 2 { return nil }
        func even(_ v: Int) -> Int { max(2, v - (v % 2)) }

        let outH = even(outputHeight ?? displayHeight)
        let scale = Double(outH) / Double(displayHeight)
        let scaledW = Double(displayWidth) * scale
        var outW = even(Int((Double(outH) * outputAspect).rounded()))
        // Saída mais larga que o frame (ex.: fonte vertical → 9:16): usa o frame inteiro.
        if Double(outW) > scaledW { outW = even(Int(scaledW.rounded(.down))) }

        self.displayWidth = displayWidth
        self.displayHeight = displayHeight
        self.scale = scale
        self.scaledWidth = scaledW
        self.outputWidth = outW
        self.outputHeight = outH
    }

    /// Posição X (px, no frame já escalado) do canto esquerdo da janela para um
    /// centro normalizado. Sempre dentro do frame.
    public func cropX(centerX: Double) -> Double {
        let maxX = max(0, scaledWidth - Double(outputWidth))
        guard centerX.isFinite else { return maxX / 2 }
        let x = centerX * scaledWidth - Double(outputWidth) / 2
        return min(max(x, 0), maxX)
    }
}

// MARK: - Trajetória por instante

/// Centro do crop em qualquer instante, por interpolação linear entre os
/// `CropPoint`s do engine (que são amostrados a `fps`, não necessariamente
/// nos mesmos instantes dos frames).
public struct CropTimeline: Equatable, Sendable {
    private let times: [Double]
    private let centers: [Double]

    public init(points: [CropPoint]) {
        let sorted = points
            .filter { $0.time.isFinite && $0.centerX.isFinite }
            .sorted { $0.time < $1.time }
        self.times = sorted.map { $0.time }
        self.centers = sorted.map { Double($0.centerX) }
    }

    public var isEmpty: Bool { times.isEmpty }

    /// Sem pontos: 0,5 (centro). Fora do intervalo: o valor da borda.
    public func centerX(at time: Double) -> Double {
        guard let first = times.first, let last = times.last, time.isFinite else { return 0.5 }
        if time <= first { return centers[0] }
        if time >= last { return centers[centers.count - 1] }
        var lo = 0, hi = times.count - 1
        while hi - lo > 1 {
            let mid = (lo + hi) / 2
            if times[mid] <= time { lo = mid } else { hi = mid }
        }
        let span = times[hi] - times[lo]
        guard span > 0 else { return centers[lo] }
        let f = (time - times[lo]) / span
        return centers[lo] + (centers[hi] - centers[lo]) * f
    }
}

// MARK: - Estilos de recorte (presets)

/// Estilos de movimento do recorte, escolhidos a partir da comparação lado a lado
/// (A/B/C/D). Só mudam parâmetros do render; os padrões do ReframeCore NÃO mudam.
public enum RenderPreset: String, CaseIterable, Equatable, Sendable {
    /// A: baseline do M1.
    case padrao
    /// B: baseline + filtro One Euro.
    case oneeuro
    /// C: reage mais rápido, recorte mais "nervoso".
    case rapido
    /// D: bem suave, mais atraso. Padrão do `reframe render`.
    case suave

    public var useOneEuro: Bool { return self == .oneeuro }

    public var reframeSettings: ReframeSettings {
        var s = ReframeSettings()
        switch self {
        case .padrao, .oneeuro: break
        case .rapido:
            s.smoothingTime = 0.25; s.lookAhead = 0.30; s.maxSpeed = 0.60
        case .suave:
            s.smoothingTime = 0.80; s.deadZoneWidth = 0.40; s.maxSpeed = 0.25
        }
        return s
    }
}

// MARK: - Opções da linha de comando

/// `reframe render <video> --tracking <json> --output <mp4> [opções]`
public struct RenderCommandOptions: Equatable, Sendable {
    public var input: String
    public var tracking: String
    public var output: String
    /// largura / altura da saída. Padrão 9:16.
    public var aspect: Double = 9.0 / 16.0
    public var outputHeight: Int?
    public var maxSeconds: Double?
    public var bitrate: Int?
    public var useOneEuro: Bool = false
    /// Estilo do recorte. Padrão: suave (D).
    public var preset: RenderPreset = .suave

    public enum ParseError: Error, Equatable, CustomStringConvertible {
        case missingCommand
        case unknownCommand(String)
        case missingInput
        case missingTracking
        case missingOutput
        case missingValue(String)
        case invalidValue(String, String)
        case unknownOption(String)

        public var description: String {
            switch self {
            case .missingCommand: return "faltou o comando (use: render)"
            case .unknownCommand(let c): return "comando desconhecido: \(c)"
            case .missingInput: return "faltou o arquivo de vídeo"
            case .missingTracking: return "faltou --tracking <arquivo.json>"
            case .missingOutput: return "faltou --output <arquivo.mp4>"
            case .missingValue(let o): return "faltou o valor de \(o)"
            case .invalidValue(let o, let v): return "valor inválido para \(o): \(v)"
            case .unknownOption(let o): return "opção desconhecida: \(o)"
            }
        }
    }

    public static let usage = """
    uso: reframe render <video> --tracking <tracking.json> --output <saida.mp4> [opções]
      --aspect <L:A>          proporção da saída (padrão 9:16; ex.: 4:5, 1:1)
      --output-height <px>    altura da saída (padrão: altura do vídeo original)
      --bitrate <bits/s>      bitrate do vídeo (padrão: automático)
      --preset <estilo>       padrao | oneeuro | rapido | suave (padrão: suave)
      --one-euro              liga o filtro One Euro (experimental) por cima do estilo
      --max-seconds <s>       processa só os primeiros N segundos
    """

    /// "9:16" → 0,5625; "1:1" → 1; também aceita decimal ("0.5625"). nil se inválido.
    public static func parseAspect(_ text: String) -> Double? {
        let parts = text.split(separator: ":", omittingEmptySubsequences: false)
        if parts.count == 2, let w = Double(parts[0]), let h = Double(parts[1]),
           w.isFinite, h.isFinite, w > 0, h > 0 {
            return w / h
        }
        if parts.count == 1, let v = Double(text), v.isFinite, v > 0 { return v }
        return nil
    }

    /// `arguments` NÃO inclui o nome do programa.
    public static func parse(_ arguments: [String]) throws -> RenderCommandOptions {
        guard let command = arguments.first else { throw ParseError.missingCommand }
        guard command == "render" else { throw ParseError.unknownCommand(command) }

        var input: String?, tracking: String?, output: String?
        var aspect = 9.0 / 16.0
        var height: Int?, bitrate: Int?
        var maxSeconds: Double?
        var oneEuro = false
        var preset = RenderPreset.suave

        var i = 1
        func value(_ name: String) throws -> String {
            guard i + 1 < arguments.count else { throw ParseError.missingValue(name) }
            i += 1
            return arguments[i]
        }
        while i < arguments.count {
            let a = arguments[i]
            switch a {
            case "--tracking", "-t": tracking = try value(a)
            case "--output", "-o": output = try value(a)
            case "--one-euro": oneEuro = true
            case "--preset":
                let v = try value(a)
                guard let p = RenderPreset(rawValue: v.lowercased()) else { throw ParseError.invalidValue(a, v) }
                preset = p
            case "--aspect":
                let v = try value(a)
                guard let r = parseAspect(v) else { throw ParseError.invalidValue(a, v) }
                aspect = r
            case "--output-height":
                let v = try value(a)
                guard let n = Int(v), n >= 16, n <= 8192 else { throw ParseError.invalidValue(a, v) }
                height = n
            case "--bitrate":
                let v = try value(a)
                guard let n = Int(v), n >= 100_000, n <= 200_000_000 else { throw ParseError.invalidValue(a, v) }
                bitrate = n
            case "--max-seconds":
                let v = try value(a)
                guard let d = Double(v), d.isFinite, d > 0 else { throw ParseError.invalidValue(a, v) }
                maxSeconds = d
            default:
                if a.hasPrefix("-") { throw ParseError.unknownOption(a) }
                input = a
            }
            i += 1
        }
        guard let inp = input else { throw ParseError.missingInput }
        guard let trk = tracking else { throw ParseError.missingTracking }
        guard let out = output else { throw ParseError.missingOutput }
        var o = RenderCommandOptions(input: inp, tracking: trk, output: out)
        o.aspect = aspect
        o.outputHeight = height
        o.bitrate = bitrate
        o.maxSeconds = maxSeconds
        o.useOneEuro = oneEuro
        o.preset = preset
        return o
    }
}
