import Foundation
#if canImport(AVFoundation) && canImport(CoreImage)
import AVFoundation
import CoreImage
import CoreVideo
import CoreMedia
import ImageIO
#if canImport(CoreGraphics)
import CoreGraphics
#endif
import ReframeCore

public struct RenderOptions: Sendable {
    /// largura / altura da saída (padrão 9:16).
    public var aspect: Double = 9.0 / 16.0
    /// Altura da saída em px; nil = altura do vídeo (como exibido).
    public var outputHeight: Int?
    public var maxSeconds: Double?
    /// Bits por segundo do H.264; nil = automático (~0,1 bit por pixel a 30 fps).
    public var bitrate: Int?
    /// Experimental: filtro One Euro antes do engine (baseline = false).
    public var useOneEuro: Bool = false
    /// Parâmetros do engine (padrões do M1).
    public var reframe = ReframeSettings()
    /// Quando o sujeito está `lost`, o recorte volta suavemente ao centro.
    public var recenterWhenLost: Bool = true

    public init() {}
}

public struct RenderResult: Sendable {
    public let outputWidth: Int
    public let outputHeight: Int
    public let framesWritten: Int
    public let hasAudio: Bool
    /// true se o áudio precisou ser recodificado (o normal é copiar sem recodificar).
    public let audioReencoded: Bool
    public let orientation: DisplayOrientation
}

public enum RenderError: Error, CustomStringConvertible {
    case noVideoTrack
    case invalidGeometry
    case unsupportedTransform
    case trackingMismatch(String)
    case readerFailed(String)
    case writerFailed(String)

    public var description: String {
        switch self {
        case .noVideoTrack: return "o arquivo não tem trilha de vídeo"
        case .invalidGeometry: return "dimensões inválidas para o render"
        case .unsupportedTransform: return "preferredTransform não suportado (só rotações de 90°; sem espelhamento)"
        case .trackingMismatch(let m): return "o tracking não combina com o vídeo: \(m)"
        case .readerFailed(let m): return "falha ao ler o vídeo: \(m)"
        case .writerFailed(let m): return "falha ao escrever o vídeo: \(m)"
        }
    }
}

extension DisplayOrientation {
    var imageOrientation: CGImagePropertyOrientation {
        switch self {
        case .up: return .up
        case .clockwise90: return .right
        case .rotated180: return .down
        case .counterClockwise90: return .left
        }
    }
}

/// Estado compartilhado entre as filas de vídeo e áudio.
private final class RenderState: @unchecked Sendable {
    private let lock = NSLock()
    private var _error: Error?
    private var _frames = 0
    private var _firstPTS: Double?

    var error: Error? { lock.lock(); defer { lock.unlock() }; return _error }
    var frames: Int { lock.lock(); defer { lock.unlock() }; return _frames }

    func fail(_ e: Error) { lock.lock(); if _error == nil { _error = e }; lock.unlock() }
    func countFrame() { lock.lock(); _frames += 1; lock.unlock() }
    /// Tempo relativo ao primeiro frame (o mesmo critério do TimestampNormalizer do tracking).
    func relativeTime(_ seconds: Double) -> Double {
        lock.lock(); defer { lock.unlock() }
        if _firstPTS == nil { _firstPTS = seconds }
        return seconds - _firstPTS!
    }
}

/// Render vertical offline: lê o vídeo ORIGINAL em resolução cheia, aplica o
/// preferredTransform, recorta a janela que o ReframeEngine calculou para cada
/// frame e escreve um MP4 H.264. O áudio é copiado sem recodificar.
///
/// Limitações (v1): só SDR; só rotações de 90° no preferredTransform;
/// saída em H.264 com altura = altura do vídeo (ou `outputHeight`).
public enum VerticalRenderer {

    public static func render(input: URL,
                              report: TrackingReport,
                              output: URL,
                              options: RenderOptions = RenderOptions(),
                              progress: ((Double) -> Void)? = nil) async throws -> RenderResult {
        // 1) Geometria do vídeo
        let asset = AVURLAsset(url: input)
        guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
            throw RenderError.noVideoTrack
        }
        let natural = try await videoTrack.load(.naturalSize)
        let cgTransform = try await videoTrack.load(.preferredTransform)
        let cmDuration = try await asset.load(.duration)
        let assetDuration = CMTimeGetSeconds(cmDuration)

        let transform = PreferredTransform(a: Double(cgTransform.a), b: Double(cgTransform.b),
                                           c: Double(cgTransform.c), d: Double(cgTransform.d),
                                           tx: Double(cgTransform.tx), ty: Double(cgTransform.ty))
        guard let mapping = DisplayMapping(naturalWidth: Double(natural.width), naturalHeight: Double(natural.height),
                                           transform: transform) else { throw RenderError.invalidGeometry }
        guard let orientation = DisplayOrientation(transform: transform) else { throw RenderError.unsupportedTransform }

        let displayW = Int(mapping.displayWidth.rounded()), displayH = Int(mapping.displayHeight.rounded())
        if abs(report.displaySize.width - mapping.displayWidth) > 1 || abs(report.displaySize.height - mapping.displayHeight) > 1 {
            throw RenderError.trackingMismatch(
                "vídeo \(displayW)x\(displayH), tracking \(Int(report.displaySize.width))x\(Int(report.displaySize.height))")
        }
        guard let geometry = RenderGeometry(displayWidth: displayW, displayHeight: displayH,
                                            outputAspect: options.aspect, outputHeight: options.outputHeight) else {
            throw RenderError.invalidGeometry
        }

        // 2) Trajetória da câmera virtual (engine do M1, inalterado)
        let fps = report.fps > 0 ? report.fps : 30
        let pipeline = ReframePipeline(sourceAspect: mapping.displayAspect, outputAspect: options.aspect,
                                       settings: ReframePipelineSettings(reframe: options.reframe,
                                                                         useOneEuro: options.useOneEuro))
        let cropPoints = pipeline.trajectory(for: report.toSubjectTrack(), fps: fps,
                                             timeRange: 0...max(report.duration, 0.001))
        let finalPoints = options.recenterWhenLost
            ? LostRecentering.apply(to: cropPoints,
                                    states: report.points.map { (time: $0.time, lost: $0.state == .lost) })
            : cropPoints
        let timeline = CropTimeline(points: finalPoints)

        // 3) Leitor (vídeo em resolução cheia + áudio)
        let reader: AVAssetReader
        do { reader = try AVAssetReader(asset: asset) } catch { throw RenderError.readerFailed("\(error)") }
        if let limit = options.maxSeconds {
            reader.timeRange = CMTimeRange(start: .zero, duration: CMTime(seconds: limit, preferredTimescale: 600))
        }
        let videoOutput = AVAssetReaderTrackOutput(track: videoTrack, outputSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ])
        videoOutput.alwaysCopiesSampleData = false
        guard reader.canAdd(videoOutput) else { throw RenderError.readerFailed("saída de vídeo não suportada") }
        reader.add(videoOutput)

        // 4) Escritor
        try? FileManager.default.removeItem(at: output)
        let fileType: AVFileType = output.pathExtension.lowercased() == "mov" ? .mov : .mp4
        let writer: AVAssetWriter
        do { writer = try AVAssetWriter(outputURL: output, fileType: fileType) }
        catch { throw RenderError.writerFailed("\(error)") }

        let bitrate = options.bitrate
            ?? max(2_000_000, Int(Double(geometry.outputWidth * geometry.outputHeight) * 30 * 0.1))
        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: geometry.outputWidth,
            AVVideoHeightKey: geometry.outputHeight,
            AVVideoColorPropertiesKey: [
                AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2,
                AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2
            ],
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: bitrate,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]
        let videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        videoInput.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: videoInput, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: geometry.outputWidth,
            kCVPixelBufferHeightKey as String: geometry.outputHeight
        ])
        guard writer.canAdd(videoInput) else { throw RenderError.writerFailed("entrada de vídeo não suportada") }
        writer.add(videoInput)

        // Áudio: cópia sem recodificar (passthrough); se o contêiner não aceitar, recodifica em AAC.
        var audioOutput: AVAssetReaderTrackOutput?
        var audioInput: AVAssetWriterInput?
        var audioReencoded = false
        if let audioTrack = try await asset.loadTracks(withMediaType: .audio).first {
            let formats = try await audioTrack.load(.formatDescriptions)
            let passthrough = AVAssetWriterInput(mediaType: .audio, outputSettings: nil, sourceFormatHint: formats.first)
            passthrough.expectsMediaDataInRealTime = false
            if writer.canAdd(passthrough) {
                writer.add(passthrough)
                audioInput = passthrough
                audioOutput = AVAssetReaderTrackOutput(track: audioTrack, outputSettings: nil)
            } else {
                var channels = 2
                var rate = 48000.0
                if let f = formats.first, let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(f)?.pointee {
                    channels = max(1, min(Int(asbd.mChannelsPerFrame), 2))
                    if asbd.mSampleRate > 0 { rate = asbd.mSampleRate }
                }
                let aac = AVAssetWriterInput(mediaType: .audio, outputSettings: [
                    AVFormatIDKey: kAudioFormatMPEG4AAC,
                    AVNumberOfChannelsKey: channels,
                    AVSampleRateKey: rate,
                    AVEncoderBitRateKey: 128_000
                ])
                aac.expectsMediaDataInRealTime = false
                if writer.canAdd(aac) {
                    writer.add(aac)
                    audioInput = aac
                    audioReencoded = true
                    audioOutput = AVAssetReaderTrackOutput(track: audioTrack, outputSettings: [
                        AVFormatIDKey: kAudioFormatLinearPCM,
                        AVLinearPCMBitDepthKey: 16,
                        AVLinearPCMIsFloatKey: false,
                        AVLinearPCMIsBigEndianKey: false,
                        AVLinearPCMIsNonInterleaved: false
                    ])
                }
            }
            if let out = audioOutput {
                out.alwaysCopiesSampleData = false
                if reader.canAdd(out) { reader.add(out) } else { audioOutput = nil; audioInput = nil }
            }
        }

        guard writer.startWriting() else { throw RenderError.writerFailed(writer.error.map { "\($0)" } ?? "não iniciou") }
        guard reader.startReading() else { throw RenderError.readerFailed(reader.error.map { "\($0)" } ?? "não iniciou") }
        writer.startSession(atSourceTime: .zero)

        // 5) Bombeia vídeo e áudio em filas separadas (o writer intercala as trilhas)
        let state = RenderState()
        let ciContext = CIContext(options: [.cacheIntermediates: false])
        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB)
        let outBounds = CGRect(x: 0, y: 0, width: geometry.outputWidth, height: geometry.outputHeight)
        let imageOrientation = orientation.imageOrientation
        let group = DispatchGroup()

        group.enter()
        videoInput.requestMediaDataWhenReady(on: DispatchQueue(label: "reframe.render.video")) {
            while videoInput.isReadyForMoreMediaData {
                if state.error != nil { videoInput.markAsFinished(); group.leave(); return }
                var finished = false
                autoreleasepool {
                    guard let sample = videoOutput.copyNextSampleBuffer() else { finished = true; return }
                    guard let source = CMSampleBufferGetImageBuffer(sample) else { return }
                    let pts = CMSampleBufferGetPresentationTimeStamp(sample)
                    let seconds = CMTimeGetSeconds(pts)
                    let t = state.relativeTime(seconds)

                    // Frame cru → de pé → (escala) → janela do engine
                    var image = CIImage(cvPixelBuffer: source).oriented(imageOrientation)
                    image = image.transformed(by: CGAffineTransform(translationX: -image.extent.origin.x,
                                                                    y: -image.extent.origin.y))
                    if abs(geometry.scale - 1) > 1e-9 {
                        image = image.transformed(by: CGAffineTransform(scaleX: CGFloat(geometry.scale),
                                                                        y: CGFloat(geometry.scale)))
                    }
                    let x = geometry.cropX(centerX: timeline.centerX(at: t))
                    image = image
                        .transformed(by: CGAffineTransform(translationX: CGFloat(-x), y: 0))
                        .cropped(to: outBounds)

                    guard let pool = adaptor.pixelBufferPool else {
                        state.fail(RenderError.writerFailed("pool de buffers indisponível")); finished = true; return
                    }
                    var buffer: CVPixelBuffer?
                    CVPixelBufferPoolCreatePixelBuffer(nil, pool, &buffer)
                    guard let outBuffer = buffer else {
                        state.fail(RenderError.writerFailed("sem buffer de saída")); finished = true; return
                    }
                    ciContext.render(image, to: outBuffer, bounds: outBounds, colorSpace: colorSpace)
                    if !adaptor.append(outBuffer, withPresentationTime: pts) {
                        state.fail(RenderError.writerFailed(writer.error.map { "\($0)" } ?? "append de vídeo falhou"))
                        finished = true
                        return
                    }
                    state.countFrame()
                    if assetDuration > 0 { progress?(min(1, t / assetDuration)) }
                }
                if finished { videoInput.markAsFinished(); group.leave(); return }
            }
        }

        if let audioInput = audioInput, let audioOutput = audioOutput {
            group.enter()
            audioInput.requestMediaDataWhenReady(on: DispatchQueue(label: "reframe.render.audio")) {
                while audioInput.isReadyForMoreMediaData {
                    if state.error != nil { audioInput.markAsFinished(); group.leave(); return }
                    guard let sample = audioOutput.copyNextSampleBuffer() else {
                        audioInput.markAsFinished(); group.leave(); return
                    }
                    if !audioInput.append(sample) {
                        state.fail(RenderError.writerFailed(writer.error.map { "\($0)" } ?? "append de áudio falhou"))
                        audioInput.markAsFinished(); group.leave(); return
                    }
                }
            }
        }

        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            group.notify(queue: .global()) { continuation.resume() }
        }

        if let e = state.error {
            writer.cancelWriting()
            reader.cancelReading()
            throw e
        }
        if reader.status == .failed {
            writer.cancelWriting()
            throw RenderError.readerFailed(reader.error.map { "\($0)" } ?? "desconhecido")
        }
        await writer.finishWriting()
        guard writer.status == .completed else {
            throw RenderError.writerFailed(writer.error.map { "\($0)" } ?? "status \(writer.status.rawValue)")
        }
        return RenderResult(outputWidth: geometry.outputWidth, outputHeight: geometry.outputHeight,
                            framesWritten: state.frames, hasAudio: audioInput != nil,
                            audioReencoded: audioReencoded, orientation: orientation)
    }
}
#endif
