import Foundation

/// Argumentos do comando `reframe track`. Puro e testável (sem tocar em disco).
///
///     reframe track input.mov --output tracking.json
///             [--debug-video debug.mp4] [--crop]
///             [--analysis-width 960] [--redetect 0.5] [--max-seconds 30]
public struct TrackCommandOptions: Equatable, Sendable {
    public var input: String
    public var output: String
    public var debugVideo: String?
    public var showCrop: Bool = false
    public var cpuOnly: Bool = false
    public var analysisWidth: Int?
    public var redetectInterval: Double?
    public var maxSeconds: Double?

    public enum ParseError: Error, Equatable, CustomStringConvertible {
        case missingCommand
        case unknownCommand(String)
        case missingInput
        case missingOutput
        case missingValue(String)
        case invalidValue(String, String)
        case unknownOption(String)

        public var description: String {
            switch self {
            case .missingCommand: return "faltou o comando (use: track)"
            case .unknownCommand(let c): return "comando desconhecido: \(c)"
            case .missingInput: return "faltou o arquivo de vídeo"
            case .missingOutput: return "faltou --output <arquivo.json>"
            case .missingValue(let o): return "faltou o valor de \(o)"
            case .invalidValue(let o, let v): return "valor inválido para \(o): \(v)"
            case .unknownOption(let o): return "opção desconhecida: \(o)"
            }
        }
    }

    public static let usage = """
    uso: reframe track <video> --output <tracking.json> [opções]
      --debug-video <arquivo.mp4>  gera vídeo de debug (caixa, confiança, estado, ID)
      --cpu-only                   força o Vision a usar só a CPU (para máquinas sem GPU)
      --crop                       desenha também o centro do crop 9:16 no vídeo de debug
      --analysis-width <px>        largura de análise (padrão 960)
      --redetect <segundos>        intervalo entre detecções (padrão 0.5)
      --max-seconds <segundos>     processa só os primeiros N segundos
    """

    /// `arguments` NÃO inclui o nome do programa.
    public static func parse(_ arguments: [String]) throws -> TrackCommandOptions {
        guard let command = arguments.first else { throw ParseError.missingCommand }
        guard command == "track" else { throw ParseError.unknownCommand(command) }

        var input: String?
        var output: String?
        var debug: String?
        var crop = false
        var cpuOnly = false
        var width: Int?
        var redetect: Double?
        var maxSeconds: Double?

        var i = 1
        func value(_ name: String) throws -> String {
            guard i + 1 < arguments.count else { throw ParseError.missingValue(name) }
            i += 1
            return arguments[i]
        }
        while i < arguments.count {
            let a = arguments[i]
            switch a {
            case "--output", "-o": output = try value(a)
            case "--debug-video": debug = try value(a)
            case "--crop": crop = true
            case "--cpu-only": cpuOnly = true
            case "--analysis-width":
                let v = try value(a)
                guard let n = Int(v), n >= 16, n <= 8192 else { throw ParseError.invalidValue(a, v) }
                width = n
            case "--redetect":
                let v = try value(a)
                guard let d = Double(v), d.isFinite, d > 0 else { throw ParseError.invalidValue(a, v) }
                redetect = d
            case "--max-seconds":
                let v = try value(a)
                guard let d = Double(v), d.isFinite, d > 0 else { throw ParseError.invalidValue(a, v) }
                maxSeconds = d
            default:
                if a.hasPrefix("-") { throw ParseError.unknownOption(a) }
                input = a
            }
            i += 1
        }
        guard let inp = input else { throw ParseError.missingInput }
        guard let out = output else { throw ParseError.missingOutput }
        var o = TrackCommandOptions(input: inp, output: out)
        o.debugVideo = debug
        o.showCrop = crop
        o.cpuOnly = cpuOnly
        o.analysisWidth = width
        o.redetectInterval = redetect
        o.maxSeconds = maxSeconds
        return o
    }

    /// Aplica as opções sobre os padrões.
    public func settings(base: TrackingSettings = .default) -> TrackingSettings {
        var s = base
        if let w = analysisWidth { s.analysisWidth = w }
        if let r = redetectInterval { s.redetectInterval = r }
        if cpuOnly { s.visionCPUOnly = true }
        return s
    }
}
