import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
import ReframeCore

/// Representação de debug do tracking, exportável como JSON.
///
/// Mesma convenção do ReframeCore: boundingBox normalizado, origem no
/// topo-esquerdo, +X direita, +Y baixo, na orientação de exibição.
public struct TrackingReport: Codable, Equatable, Sendable {

    public struct Box: Codable, Equatable, Sendable {
        public var x: Double, y: Double, width: Double, height: Double
        public init(x: Double, y: Double, width: Double, height: Double) {
            self.x = x; self.y = y; self.width = width; self.height = height
        }
        public init(_ r: CGRect) {
            self.init(x: Double(r.origin.x), y: Double(r.origin.y), width: Double(r.width), height: Double(r.height))
        }
        public var rect: CGRect {
            CGRect(x: CGFloat(x), y: CGFloat(y), width: CGFloat(width), height: CGFloat(height))
        }
    }

    public struct Point: Codable, Equatable, Sendable {
        public var time: Double
        /// Ausente enquanto nenhum sujeito foi adquirido.
        public var boundingBox: Box?
        public var confidence: Float
        public var state: TrackingState
        public var subjectID: Int?
        public init(time: Double, boundingBox: Box?, confidence: Float, state: TrackingState, subjectID: Int?) {
            self.time = time; self.boundingBox = boundingBox; self.confidence = confidence
            self.state = state; self.subjectID = subjectID
        }
    }

    public struct Size: Codable, Equatable, Sendable {
        public var width: Double, height: Double
        public init(width: Double, height: Double) { self.width = width; self.height = height }
    }

    public var version: Int
    public var duration: Double
    public var fps: Double
    /// Tamanho do vídeo como exibido (px, já com preferredTransform).
    public var displaySize: Size
    /// Tamanho decodificado para o Vision (px, buffer cru).
    public var analysisSize: Size
    public var points: [Point]

    public init(version: Int = 1, duration: Double, fps: Double, displaySize: Size, analysisSize: Size, points: [Point]) {
        self.version = version; self.duration = duration; self.fps = fps
        self.displaySize = displaySize; self.analysisSize = analysisSize; self.points = points
    }

    public init(frames: [TrackedFrame], duration: Double, fps: Double, displaySize: Size, analysisSize: Size) {
        let pts = frames.map {
            Point(time: $0.time, boundingBox: $0.box.map(Box.init), confidence: $0.confidence,
                  state: $0.state, subjectID: $0.subjectID)
        }
        self.init(duration: duration, fps: fps, displaySize: displaySize, analysisSize: analysisSize, points: pts)
    }

    // MARK: SubjectTrack (entrada do ReframeEngine)

    /// Converte para o modelo do ReframeCore. Frames sem box (`acquiring`) são
    /// omitidos. Frames `lost` entram com confiança 0 e o engine os ignora
    /// (a política de perda do engine continua sendo a dele).
    ///
    /// Todos os frames entram em UM SubjectTrack: é a trajetória da pessoa
    /// que a câmera virtual deve seguir. Use `subjectTracks()` para separar por ID.
    public func toSubjectTrack(id: UUID = UUID()) -> SubjectTrack {
        return SubjectTrack(id: id, points: Self.trackingPoints(points))
    }

    /// Um SubjectTrack por `subjectID` (ordenados pelo ID).
    public func subjectTracks(idFor: (Int) -> UUID = { _ in UUID() }) -> [SubjectTrack] {
        let ids = Set(points.compactMap { $0.subjectID }).sorted()
        return ids.map { sid in
            SubjectTrack(id: idFor(sid), points: Self.trackingPoints(points.filter { $0.subjectID == sid }))
        }
    }

    private static func trackingPoints(_ pts: [Point]) -> [TrackingPoint] {
        return pts.compactMap { p in
            guard let b = p.boundingBox else { return nil }
            return TrackingPoint(time: p.time, boundingBox: b.rect, confidence: p.confidence)
        }
    }

    // MARK: JSON

    /// JSON determinístico (chaves ordenadas, indentado).
    public func jsonData() throws -> Data {
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        return try enc.encode(self)
    }

    public static func decode(from data: Data) throws -> TrackingReport {
        return try JSONDecoder().decode(TrackingReport.self, from: data)
    }
}
