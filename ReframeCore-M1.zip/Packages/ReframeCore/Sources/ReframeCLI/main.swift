import Foundation
import TrackingKit

#if canImport(AVFoundation) && canImport(Vision)

func fail(_ message: String, code: Int32 = 1) -> Never {
    FileHandle.standardError.write(Data((message + "\n").utf8))
    exit(code)
}

let arguments = Array(CommandLine.arguments.dropFirst())
let options: TrackCommandOptions
do {
    options = try TrackCommandOptions.parse(arguments)
} catch {
    fail("erro: \(error)\n\n\(TrackCommandOptions.usage)", code: 2)
}

do {
    let settings = options.settings()
    let pipeline = TrackingPipeline(settings: settings)
    var lastPrinted = -1
    let result = try await pipeline.run(url: URL(fileURLWithPath: options.input),
                                        maxSeconds: options.maxSeconds) { p in
        let percent = Int(p * 100) / 10 * 10
        if percent != lastPrinted { lastPrinted = percent; print("tracking \(percent)%") }
    }
    let report = result.report
    try report.jsonData().write(to: URL(fileURLWithPath: options.output))

    var counts: [TrackingState: Int] = [:]
    for f in result.frames { counts[f.state, default: 0] += 1 }
    let subjects = Set(result.frames.compactMap { $0.subjectID }).count
    print("frames: \(result.frames.count)  fps: \(String(format: "%.2f", report.fps))  duração: \(String(format: "%.2f", report.duration))s")
    print("exibição: \(Int(report.displaySize.width))x\(Int(report.displaySize.height))  análise: \(Int(report.analysisSize.width))x\(Int(report.analysisSize.height))")
    print("estados: tracking=\(counts[.tracking, default: 0]) held=\(counts[.held, default: 0]) lost=\(counts[.lost, default: 0]) acquiring=\(counts[.acquiring, default: 0])  sujeitos=\(subjects)")
    print("erros do tracker: \(result.trackerErrors)  timestamps descartados: \(result.droppedTimestamps)")
    print("JSON: \(options.output)")

    if let debugPath = options.debugVideo {
        let reader = try await VideoFrameReader.open(url: URL(fileURLWithPath: options.input),
                                                     analysisWidth: settings.analysisWidth)
        try DebugVideoWriter.write(reader: reader, report: report, to: URL(fileURLWithPath: debugPath),
                                   showCrop: options.showCrop, maxSeconds: options.maxSeconds)
        print("vídeo de debug: \(debugPath)")
    }
} catch {
    fail("erro: \(error)")
}

#else
print("reframe: este comando só funciona no macOS (precisa de Vision e AVFoundation).")
exit(1)
#endif
