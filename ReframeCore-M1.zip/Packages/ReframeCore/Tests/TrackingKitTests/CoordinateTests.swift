import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import TrackingKit

final class CoordinateTests: XCTestCase {

    private func assertRect(_ a: CGRect, _ x: Double, _ y: Double, _ w: Double, _ h: Double,
                            accuracy: Double = 1e-9, file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(Double(a.origin.x), x, accuracy: accuracy, "x", file: file, line: line)
        XCTAssertEqual(Double(a.origin.y), y, accuracy: accuracy, "y", file: file, line: line)
        XCTAssertEqual(Double(a.width), w, accuracy: accuracy, "w", file: file, line: line)
        XCTAssertEqual(Double(a.height), h, accuracy: accuracy, "h", file: file, line: line)
    }

    // MARK: Vision ⇄ ReframeCore

    func testVisionBottomLeftToTopLeft() {
        // Vision: caixa colada no canto INFERIOR-esquerdo.
        let top = VisionCoordinates.toTopLeft(CGRect(x: 0, y: 0, width: 0.1, height: 0.1))
        assertRect(top, 0, 0.9, 0.1, 0.1)
        // Vision: caixa colada no TOPO (y + h = 1) vira y = 0.
        let topEdge = VisionCoordinates.toTopLeft(CGRect(x: 0.2, y: 0.7, width: 0.3, height: 0.3))
        assertRect(topEdge, 0.2, 0, 0.3, 0.3)
        assertRect(VisionCoordinates.toTopLeft(CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)), 0.1, 0.4, 0.3, 0.4)
    }

    func testVisionConversionIsItsOwnInverse() {
        let r = CGRect(x: 0.13, y: 0.27, width: 0.31, height: 0.52)
        let back = VisionCoordinates.toVision(VisionCoordinates.toTopLeft(r))
        assertRect(back, 0.13, 0.27, 0.31, 0.52)
        let back2 = VisionCoordinates.toTopLeft(VisionCoordinates.toVision(r))
        assertRect(back2, 0.13, 0.27, 0.31, 0.52)
    }

    // MARK: preferredTransform

    func testIdentityMapping() throws {
        let m = try XCTUnwrap(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080))
        XCTAssertEqual(m.displayWidth, 1920); XCTAssertEqual(m.displayHeight, 1080)
        XCTAssertEqual(m.displayAspect, 16.0 / 9.0, accuracy: 1e-12)
        XCTAssertFalse(m.swapsAxes)
        assertRect(m.rawToDisplay(CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)), 0.1, 0.2, 0.3, 0.4)
    }

    /// iPhone em retrato: arquivo físico 1920×1080 + rotação de 90° horário.
    func testIPhonePortraitRotatedClockwise() throws {
        let t = PreferredTransform.rotated90Clockwise(naturalHeight: 1080)
        let m = try XCTUnwrap(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080, transform: t))
        XCTAssertEqual(m.displayWidth, 1080, accuracy: 1e-9)
        XCTAssertEqual(m.displayHeight, 1920, accuracy: 1e-9)
        XCTAssertEqual(m.displayAspect, 9.0 / 16.0, accuracy: 1e-12)
        XCTAssertTrue(m.swapsAxes)
        // Canto superior-ESQUERDO do arquivo vai para o canto superior-DIREITO da tela.
        assertRect(m.rawToDisplay(CGRect(x: 0, y: 0, width: 0.1, height: 0.1)), 0.9, 0, 0.1, 0.1)
        // Caixa qualquer, calculada à mão (x' = H − y ; y' = x, em pixels):
        assertRect(m.rawToDisplay(CGRect(x: 0.5, y: 0.25, width: 0.2, height: 0.5)), 0.25, 0.5, 0.5, 0.2)
    }

    func testRotated180() throws {
        let t = PreferredTransform.rotated180(naturalWidth: 1920, naturalHeight: 1080)
        let m = try XCTUnwrap(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080, transform: t))
        XCTAssertEqual(m.displayAspect, 16.0 / 9.0, accuracy: 1e-12)
        XCTAssertFalse(m.swapsAxes)
        assertRect(m.rawToDisplay(CGRect(x: 0.1, y: 0.2, width: 0.3, height: 0.4)), 0.6, 0.4, 0.3, 0.4)
    }

    func testRotated90CounterClockwise() throws {
        let t = PreferredTransform.rotated90CounterClockwise(naturalWidth: 1920)
        let m = try XCTUnwrap(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080, transform: t))
        XCTAssertEqual(m.displayAspect, 9.0 / 16.0, accuracy: 1e-12)
        // Canto superior-esquerdo do arquivo vai para o canto inferior-ESQUERDO da tela.
        assertRect(m.rawToDisplay(CGRect(x: 0, y: 0, width: 0.1, height: 0.1)), 0, 0.9, 0.1, 0.1)
    }

    /// O erro clássico: arquivo landscape, coordenadas lidas em outra orientação.
    func testWideRawBoxBecomesTallWhenVideoIsRotated() throws {
        let t = PreferredTransform.rotated90Clockwise(naturalHeight: 1080)
        let m = try XCTUnwrap(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080, transform: t))
        // No arquivo: 768 px × 216 px (larga). Na tela do usuário: 216 × 768 (alta).
        let raw = CGRect(x: 0.4, y: 0.4, width: 0.4, height: 0.2)
        let d = m.rawToDisplay(raw)
        let pixelWidth = Double(d.width) * m.displayWidth
        let pixelHeight = Double(d.height) * m.displayHeight
        XCTAssertEqual(pixelWidth, 216, accuracy: 1e-6)
        XCTAssertEqual(pixelHeight, 768, accuracy: 1e-6)
        XCTAssertGreaterThan(pixelHeight, pixelWidth)
        // E ler o transform como identidade daria um resultado diferente (o bug).
        let identity = try XCTUnwrap(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080))
        XCTAssertNotEqual(identity.rawToDisplay(raw), d)
    }

    func testPersonOnTheLeftOfAPortraitScreen() throws {
        // Na tela (retrato) a pessoa está no lado ESQUERDO. No arquivo (landscape)
        // isso é a parte de BAIXO do frame (rotação horária: x' = H − y).
        let t = PreferredTransform.rotated90Clockwise(naturalHeight: 1080)
        let m = try XCTUnwrap(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080, transform: t))
        let onScreen = CGRect(x: 0.1, y: 0.3, width: 0.2, height: 0.4)
        let inFile = m.displayToRaw(onScreen)
        XCTAssertGreaterThan(Double(inFile.minY), 0.65) // parte de baixo do arquivo
        assertRect(m.rawToDisplay(inFile), 0.1, 0.3, 0.2, 0.4)
    }

    func testRoundTripForAllTransforms() throws {
        let w = 1920.0, h = 1080.0
        let transforms: [PreferredTransform] = [
            .identity,
            .rotated90Clockwise(naturalHeight: h),
            .rotated180(naturalWidth: w, naturalHeight: h),
            .rotated90CounterClockwise(naturalWidth: w),
            // espelhamento horizontal (câmera frontal)
            PreferredTransform(a: -1, b: 0, c: 0, d: 1, tx: w, ty: 0),
            // tx/ty "sujos": o mapeamento usa a caixa delimitadora, não tx/ty
            PreferredTransform(a: 0, b: 1, c: -1, d: 0, tx: 0, ty: 0)
        ]
        var rng = DeterministicRNG(seed: 7)
        for t in transforms {
            let m = try XCTUnwrap(DisplayMapping(naturalWidth: w, naturalHeight: h, transform: t))
            for _ in 0..<100 {
                let x = rng.next(0, 0.8), y = rng.next(0, 0.8)
                let r = CGRect(x: x, y: y, width: rng.next(0.01, 0.2), height: rng.next(0.01, 0.2))
                let display = m.rawToDisplay(r)
                // Fica dentro do frame de exibição e conserva a área (em pixels).
                XCTAssertGreaterThanOrEqual(Double(display.minX), -1e-9)
                XCTAssertLessThanOrEqual(Double(display.maxX), 1 + 1e-9)
                XCTAssertGreaterThanOrEqual(Double(display.minY), -1e-9)
                XCTAssertLessThanOrEqual(Double(display.maxY), 1 + 1e-9)
                let pxRaw = Double(r.width) * w * Double(r.height) * h
                let pxDisplay = Double(display.width) * m.displayWidth * Double(display.height) * m.displayHeight
                XCTAssertEqual(pxRaw, pxDisplay, accuracy: 1e-6)
                assertRect(m.displayToRaw(display), Double(r.origin.x), Double(r.origin.y),
                           Double(r.width), Double(r.height), accuracy: 1e-9)
            }
        }
    }

    func testInvalidMappingsAreRejected() {
        XCTAssertNil(DisplayMapping(naturalWidth: 0, naturalHeight: 1080))
        XCTAssertNil(DisplayMapping(naturalWidth: 1920, naturalHeight: -1))
        XCTAssertNil(DisplayMapping(naturalWidth: .nan, naturalHeight: 1080))
        XCTAssertNil(DisplayMapping(naturalWidth: 1920, naturalHeight: 1080,
                                    transform: PreferredTransform(a: 0, b: 0, c: 0, d: 0, tx: 0, ty: 0)))
    }

    // MARK: Normalização / IoU

    func testClampedToUnit() {
        let r = BoxMath.clampedToUnit(CGRect(x: -0.1, y: 0.5, width: 0.3, height: 0.8))
        XCTAssertNotNil(r)
        assertRect(r!, 0, 0.5, 0.2, 0.5)
        XCTAssertNil(BoxMath.clampedToUnit(CGRect(x: 1.2, y: 0.1, width: 0.2, height: 0.2)))
        XCTAssertNil(BoxMath.clampedToUnit(CGRect(x: .nan, y: 0, width: 0.2, height: 0.2)))
    }

    func testIoU() {
        let a = CGRect(x: 0, y: 0, width: 0.5, height: 0.5)
        XCTAssertEqual(BoxMath.iou(a, a), 1, accuracy: 1e-12)
        XCTAssertEqual(BoxMath.iou(a, CGRect(x: 0.6, y: 0.6, width: 0.2, height: 0.2)), 0)
        // Meio sobreposto: interseção 0,125 / união 0,375.
        let b = CGRect(x: 0.25, y: 0, width: 0.5, height: 0.5)
        XCTAssertEqual(BoxMath.iou(a, b), 1.0 / 3.0, accuracy: 1e-12)
        XCTAssertEqual(BoxMath.iou(a, b), BoxMath.iou(b, a), accuracy: 1e-15)
        // Contida: 0,25 / 1.
        XCTAssertEqual(BoxMath.iou(CGRect(x: 0, y: 0, width: 1, height: 1),
                                   CGRect(x: 0.25, y: 0.25, width: 0.5, height: 0.5)), 0.25, accuracy: 1e-12)
        // Encostadas apenas na borda: 0.
        XCTAssertEqual(BoxMath.iou(a, CGRect(x: 0.5, y: 0, width: 0.5, height: 0.5)), 0)
        // Inválidas.
        XCTAssertEqual(BoxMath.iou(a, CGRect(x: 0, y: 0, width: 0, height: 0.5)), 0)
        XCTAssertEqual(BoxMath.iou(a, CGRect(x: .nan, y: 0, width: 0.5, height: 0.5)), 0)
    }

    func testAreaRatioAndDistance() {
        let a = CGRect(x: 0, y: 0, width: 0.2, height: 0.2)
        let b = CGRect(x: 0.3, y: 0, width: 0.2, height: 0.4)
        XCTAssertEqual(BoxMath.areaRatio(a, b), 0.5, accuracy: 1e-12)
        XCTAssertEqual(BoxMath.centerDistance(a, a), 0)
        XCTAssertEqual(BoxMath.centerDistance(CGRect(x: 0, y: 0, width: 0.2, height: 0.2),
                                              CGRect(x: 0.3, y: 0.4, width: 0.2, height: 0.2)), 0.5, accuracy: 1e-12)
    }
}

/// Gerador determinístico simples (SplitMix64) para os testes.
struct DeterministicRNG {
    private var state: UInt64
    init(seed: UInt64) { state = seed }
    mutating func nextUInt64() -> UInt64 {
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }
    mutating func next(_ lo: Double, _ hi: Double) -> Double {
        return lo + (hi - lo) * Double(nextUInt64() >> 11) / Double(1 << 53)
    }
}
