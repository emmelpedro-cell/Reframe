import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import TrackingKit

final class SubjectTrackerTests: XCTestCase {

    // Pessoa A (central) e pessoa B (longe, à direita).
    let A = obs(0.40, 0.20, 0.15, 0.60, 0.90)
    let B = obs(0.75, 0.25, 0.10, 0.50, 0.95)

    /// Tracker que já está seguindo A desde t=0, com última atualização em `until`.
    private func trackerFollowingA(until: Double = 1.0) -> SubjectTracker {
        var t = SubjectTracker()
        _ = t.update(time: 0, tracked: nil, detections: [A])
        var time = 0.0
        while time + 1.0 / 30 <= until + 1e-9 {
            time += 1.0 / 30
            _ = t.update(time: time, tracked: A, detections: nil)
        }
        return t
    }

    // MARK: Aquisição

    func testAcquiringUntilSomeoneIsDetected() {
        var t = SubjectTracker()
        XCTAssertTrue(t.needsDetection)
        let f0 = t.update(time: 0, tracked: nil, detections: nil)
        XCTAssertEqual(f0.state, .acquiring); XCTAssertNil(f0.box); XCTAssertNil(f0.subjectID)
        let f1 = t.update(time: 0.1, tracked: nil, detections: [])
        XCTAssertEqual(f1.state, .acquiring)
        let f2 = t.update(time: 0.2, tracked: nil, detections: [obs(0.1, 0.1, 0.1, 0.3, 0.05)]) // fraca demais
        XCTAssertEqual(f2.state, .acquiring)
        let f3 = t.update(time: 0.3, tracked: nil, detections: [A])
        XCTAssertEqual(f3.state, .tracking); XCTAssertEqual(f3.subjectID, 1); XCTAssertEqual(f3.box, A.box)
        XCTAssertFalse(t.needsDetection)
    }

    func testFollowsTrackerBetweenDetections() {
        var t = trackerFollowingA(until: 0.3)
        let moved = obs(0.42, 0.20, 0.15, 0.60, 0.88)
        let f = t.update(time: 0.4, tracked: moved, detections: nil)
        XCTAssertEqual(f.state, .tracking); XCTAssertEqual(f.box, moved.box)
        XCTAssertEqual(f.confidence, 0.88); XCTAssertEqual(f.subjectID, 1)
    }

    func testDetectionReanchorsTheTracker() {
        var t = trackerFollowingA(until: 0.3)
        let drifted = obs(0.43, 0.20, 0.15, 0.60, 0.70)
        let detected = obs(0.41, 0.20, 0.15, 0.60, 0.95)
        let f = t.update(time: 0.5, tracked: drifted, detections: [detected, B])
        XCTAssertEqual(f.box, detected.box)
        XCTAssertEqual(f.subjectID, 1)
    }

    // MARK: Perda e recuperação

    func testHoldsLastValidBoxWithoutJumping() {
        var t = trackerFollowingA(until: 1.0)
        let last = A.box
        var time = 1.0
        while time < 1.9 {
            time += 1.0 / 30
            let f = t.update(time: time, tracked: nil, detections: nil)
            XCTAssertEqual(f.state, .held)
            XCTAssertEqual(f.box, last)               // nenhum salto
            XCTAssertEqual(f.subjectID, 1)
            XCTAssertEqual(f.confidence, 0.9 * 0.7, accuracy: 1e-6)
        }
    }

    func testBecomesLostAfterHoldDurationButKeepsIdentityAndBox() {
        var t = trackerFollowingA(until: 1.0)
        let f = t.update(time: 2.2, tracked: nil, detections: nil) // 1,2 s depois > holdDuration (1,0)
        XCTAssertEqual(f.state, .lost)
        XCTAssertEqual(f.confidence, 0)
        XCTAssertEqual(f.box, A.box)
        XCTAssertEqual(f.subjectID, 1)
        XCTAssertTrue(t.needsDetection)
    }

    func testDoesNotSwitchToAnotherPersonDuringRecoveryWindow() {
        var t = trackerFollowingA(until: 1.0)
        for time in stride(from: 1.1, through: 4.9, by: 0.1) {      // até 3,9 s depois (< 4,0 s)
            let f = t.update(time: time, tracked: nil, detections: [B])
            XCTAssertEqual(f.subjectID, 1, "t=\(time)")
            XCTAssertNotEqual(f.state, .tracking, "t=\(time)")
            XCTAssertEqual(f.box, A.box, "t=\(time)")
        }
    }

    func testPicksSomeoneElseOnlyAfterRecoveryWindow() {
        var t = trackerFollowingA(until: 1.0)
        let f = t.update(time: 5.2, tracked: nil, detections: [B]) // 4,2 s depois > 4,0 s
        XCTAssertEqual(f.state, .tracking)
        XCTAssertEqual(f.subjectID, 2)
        XCTAssertEqual(f.box, B.box)
    }

    func testRecoversSamePersonByOverlap() {
        var t = trackerFollowingA(until: 1.0)
        _ = t.update(time: 2.5, tracked: nil, detections: nil)
        let reappeared = obs(0.45, 0.20, 0.15, 0.60, 0.9)             // IoU 0,5 com A
        let f = t.update(time: 2.6, tracked: nil, detections: [B, reappeared])
        XCTAssertEqual(f.state, .tracking)
        XCTAssertEqual(f.subjectID, 1)
        XCTAssertEqual(f.box, reappeared.box)
    }

    func testRecoversSamePersonByProximityWithoutOverlap() {
        var t = trackerFollowingA(until: 1.0)
        let nearby = obs(0.62, 0.20, 0.15, 0.60, 0.9)                 // sem sobreposição, centro a 0,22
        let f = t.update(time: 3.0, tracked: nil, detections: [nearby])
        XCTAssertEqual(f.subjectID, 1)
        XCTAssertEqual(f.state, .tracking)
    }

    func testTrackerCanRecoverByItself() {
        var t = trackerFollowingA(until: 1.0)
        _ = t.update(time: 1.5, tracked: nil, detections: nil)        // held
        let back = obs(0.41, 0.20, 0.15, 0.60, 0.8)
        let f = t.update(time: 1.6, tracked: back, detections: nil)
        XCTAssertEqual(f.state, .tracking); XCTAssertEqual(f.box, back.box); XCTAssertEqual(f.subjectID, 1)
    }

    func testTrackerJumpIsRejected() {
        var t = trackerFollowingA(until: 1.0)
        // O tracker "pula" para outra região (IoU 0 com o último box): tratado como perda.
        let jumped = obs(0.75, 0.25, 0.10, 0.50, 0.95)
        let f = t.update(time: 1.1, tracked: jumped, detections: nil)
        XCTAssertEqual(f.state, .held)
        XCTAssertEqual(f.box, A.box)
    }

    func testLowConfidenceTrackerCountsAsLost() {
        var t = trackerFollowingA(until: 1.0)
        let f = t.update(time: 1.1, tracked: obs(0.40, 0.20, 0.15, 0.60, 0.1), detections: nil)
        XCTAssertEqual(f.state, .held)
        XCTAssertEqual(f.box, A.box)
    }

    // MARK: Identidade pegajosa

    private let small = obs(0.05, 0.40, 0.05, 0.20, 0.9)   // sujeito atual: pequeno, na borda
    private let big = obs(0.35, 0.20, 0.30, 0.60, 0.95)    // desafiante: grande e central

    private func trackerFollowingSmall() -> SubjectTracker {
        var t = SubjectTracker()
        _ = t.update(time: 0, tracked: nil, detections: [small])
        return t
    }

    func testSwitchesOnlyAfterSustainedDwell() {
        var t = trackerFollowingSmall()
        for time in [0.5, 1.0, 1.5, 2.0] {                 // desafiante visto há < 2,0 s
            let f = t.update(time: time, tracked: small, detections: [small, big])
            XCTAssertEqual(f.subjectID, 1, "t=\(time)")
            XCTAssertEqual(f.box, small.box, "t=\(time)")
        }
        let f = t.update(time: 2.5, tracked: small, detections: [small, big]) // 2,0 s desde 0,5
        XCTAssertEqual(f.subjectID, 2)
        XCTAssertEqual(f.box, big.box)
        XCTAssertEqual(f.state, .tracking)
    }

    func testMomentaryChallengerNeverTakesOver() {
        var t = trackerFollowingSmall()
        _ = t.update(time: 0.5, tracked: small, detections: [small, big])
        _ = t.update(time: 1.0, tracked: small, detections: [small])        // sumiu: zera a contagem
        _ = t.update(time: 1.5, tracked: small, detections: [small, big])   // reaparece
        let f = t.update(time: 2.5, tracked: small, detections: [small, big])
        XCTAssertEqual(f.subjectID, 1)                                       // só 1,0 s seguidos
    }

    func testBiggerPersonAloneNeverCausesASwitch() {
        // O sujeito atual é central e grande; outra pessoa é só um pouco maior.
        let current = obs(0.40, 0.20, 0.20, 0.60, 0.9)
        let bigger = obs(0.02, 0.10, 0.30, 0.80, 0.95)
        var t = SubjectTracker()
        _ = t.update(time: 0, tracked: nil, detections: [current])
        for i in 1...40 {
            let f = t.update(time: Double(i) * 0.5, tracked: current, detections: [current, bigger])
            XCTAssertEqual(f.subjectID, 1)
        }
    }

    func testIdentityStableWithJitteringTracker() {
        var t = SubjectTracker()
        _ = t.update(time: 0, tracked: nil, detections: [A])
        var rng = DeterministicRNG(seed: 11)
        for i in 1...300 {
            let jitter = rng.next(-0.01, 0.01)
            let o = obs(0.40 + jitter, 0.20, 0.15, 0.60, Float(rng.next(0.5, 1)))
            let det: [Observation]? = i % 15 == 0 ? [Observation(box: o.box, confidence: 0.9), B] : nil
            let f = t.update(time: Double(i) / 30, tracked: o, detections: det)
            XCTAssertEqual(f.subjectID, 1)
            XCTAssertEqual(f.state, .tracking)
        }
    }

    // MARK: Determinismo e robustez

    func testDeterministic() {
        func run() -> [TrackedFrame] {
            var t = SubjectTracker()
            var out: [TrackedFrame] = []
            out.append(t.update(time: 0, tracked: nil, detections: [A, B]))
            for i in 1..<60 {
                let lost = i > 20 && i < 40
                out.append(t.update(time: Double(i) / 30, tracked: lost ? nil : A,
                                    detections: i % 15 == 0 ? [A, B] : nil))
            }
            return out
        }
        XCTAssertEqual(run(), run())
    }

    func testGarbageInputNeverProducesInvalidOutput() {
        var rng = DeterministicRNG(seed: 5)
        func randomObs() -> Observation? {
            let kind = Int(rng.nextUInt64() % 6)
            switch kind {
            case 0: return nil
            case 1: return obs(.nan, 0.2, 0.2, 0.5)
            case 2: return obs(0.2, 0.2, -0.1, 0.5)
            case 3: return obs(0.2, 0.2, 0.2, 0.5, .nan)
            default: return obs(rng.next(0, 0.8), rng.next(0, 0.5), rng.next(0.02, 0.3), rng.next(0.05, 0.5), Float(rng.next(0, 1)))
            }
        }
        var t = SubjectTracker()
        for i in 0..<500 {
            let dets: [Observation]? = rng.nextUInt64() % 3 == 0 ? (0..<3).compactMap { _ in randomObs() } : nil
            let f = t.update(time: Double(i) / 30, tracked: randomObs(), detections: dets)
            if let b = f.box {
                XCTAssertTrue(BoxMath.isValid(b))
            }
            XCTAssertTrue(f.confidence.isFinite)
            if f.state == .acquiring { XCTAssertNil(f.box) } else { XCTAssertNotNil(f.box) }
        }
    }

    func testCustomSettingsAreHonoured() {
        var s = TrackingSettings()
        s.holdDuration = 0.2
        s.heldConfidenceFactor = 0.5
        var t = SubjectTracker(settings: s)
        _ = t.update(time: 0, tracked: nil, detections: [A])
        XCTAssertEqual(t.update(time: 0.1, tracked: nil, detections: nil).state, .held)
        XCTAssertEqual(t.update(time: 0.1, tracked: nil, detections: nil).confidence, 0.45, accuracy: 1e-6)
        XCTAssertEqual(t.update(time: 0.5, tracked: nil, detections: nil).state, .lost)
    }

    // MARK: Deriva do tracker (pessoa sai do quadro e o tracker gruda no fundo)

    /// Cena: A confirmado em t=0; depois o tracker "gruda" em outro lugar (rack)
    /// enquanto o detector não vê ninguém.
    private func driftScenario() -> (SubjectTracker, [TrackedFrame]) {
        var t = SubjectTracker()
        var out: [TrackedFrame] = []
        out.append(t.update(time: 0, tracked: nil, detections: [A]))
        let rack = obs(0.30, 0.30, 0.20, 0.50, 0.98)      // sobrepõe A (IoU ~0,36): deriva contínua, não 'salto'
        var time = 0.0
        while time < 3.0 - 1e-9 {
            time += 1.0 / 30
            let detect = abs(time / 0.5 - (time / 0.5).rounded()) < 1e-6 || t.needsDetection
            out.append(t.update(time: time, tracked: rack, detections: detect ? [] : nil))
        }
        return (t, out)
    }

    func testDriftingTrackerIsRejectedWhenNoDetectionAgrees() {
        let (_, frames) = driftScenario()
        // Depois do timeout, o box volta ao último confirmado (A), não fica no "rack".
        let late = frames.last!
        XCTAssertEqual(late.box, A.box)
        XCTAssertNotEqual(late.state, .tracking)
    }

    func testDriftingTrackerIsFollowedOnlyBrieflyBeforeRejection() {
        let (_, frames) = driftScenario()
        // Até o timeout (0,8 s) ainda é aceito como antes.
        let early = frames.first { abs($0.time - 0.3) < 0.02 }!
        XCTAssertEqual(early.state, .tracking)
        // Nenhum frame depois de 1,6 s pode estar "tracking" no box à deriva.
        for f in frames where f.time > 1.6 {
            XCTAssertNotEqual(f.state, .tracking)
            XCTAssertEqual(f.box, A.box)
        }
    }

    func testRejectedTrackerStaysIgnoredUntilDetectionFindsSubjectAgain() {
        var (t, _) = driftScenario()
        let rack = obs(0.30, 0.30, 0.20, 0.50, 0.98)
        // Sem detecção, o tracker à deriva continua ignorado.
        let f1 = t.update(time: 3.1, tracked: rack, detections: nil)
        XCTAssertEqual(f1.box, A.box)
        XCTAssertNotEqual(f1.state, .tracking)
        // A pessoa volta (perto do último box): recuperada com o MESMO ID.
        let back = obs(0.42, 0.20, 0.15, 0.60, 0.92)
        let f2 = t.update(time: 3.2, tracked: rack, detections: [back])
        XCTAssertEqual(f2.state, .tracking)
        XCTAssertEqual(f2.box, back.box)
        XCTAssertEqual(f2.subjectID, 1)
        // E o tracker volta a ser aceito depois de re-ancorado.
        let moved = obs(0.43, 0.20, 0.15, 0.60, 0.9)
        let f3 = t.update(time: 3.3, tracked: moved, detections: nil)
        XCTAssertEqual(f3.state, .tracking)
        XCTAssertEqual(f3.box, moved.box)
    }

    func testTrackerConfirmedByDetectionsIsNeverRejected() {
        var t = SubjectTracker()
        _ = t.update(time: 0, tracked: nil, detections: [A])
        var time = 0.0
        for _ in 0..<20 {                                   // 10 s, detecção a cada 0,5 s
            time += 0.5
            let f = t.update(time: time, tracked: A, detections: [A])
            XCTAssertEqual(f.state, .tracking)
        }
    }

    func testOneMissedDetectionDoesNotRejectTheTracker() {
        var t = SubjectTracker()
        _ = t.update(time: 0, tracked: nil, detections: [A])
        let f1 = t.update(time: 0.5, tracked: A, detections: [])     // detector falhou 1x
        XCTAssertEqual(f1.state, .tracking)
        let f2 = t.update(time: 1.0 / 30 + 0.5, tracked: A, detections: nil)
        XCTAssertEqual(f2.state, .tracking)
    }

    // MARK: Escolha manual

    private func trackerWithHint(_ x: Double, _ y: Double) -> SubjectTracker {
        var st = TrackingSettings()
        st.subjectHint = CGPoint(x: x, y: y)
        return SubjectTracker(settings: st)
    }

    func testHintPicksTheTouchedPersonEvenIfAnotherScoresHigher() {
        var t = trackerWithHint(0.80, 0.50)                 // toque em B
        let f = t.update(time: 0, tracked: nil, detections: [A, B])
        XCTAssertEqual(f.state, .tracking); XCTAssertEqual(f.box, B.box); XCTAssertEqual(f.subjectID, 1)
        // sem hint, A venceria
        var auto = SubjectTracker()
        XCTAssertEqual(auto.update(time: 0, tracked: nil, detections: [A, B]).box, A.box)
    }

    func testHintWaitsWhileNobodyIsDetected() {
        var t = trackerWithHint(0.80, 0.50)
        XCTAssertEqual(t.update(time: 0, tracked: nil, detections: []).state, .acquiring)
        XCTAssertEqual(t.update(time: 0.1, tracked: nil, detections: nil).state, .acquiring)
        let f = t.update(time: 0.2, tracked: nil, detections: [A, B])
        XCTAssertEqual(f.box, B.box)
    }

    func testHintWithNobodyNearFallsBackToAutomaticChoice() {
        var t = trackerWithHint(0.05, 0.95)                 // canto vazio
        let f = t.update(time: 0, tracked: nil, detections: [A, B])
        XCTAssertEqual(f.box, A.box)
    }

    func testChosenSubjectIsLockedAgainstSwitching() {
        let small = obs(0.78, 0.40, 0.06, 0.20, 0.9)        // pessoa escolhida (pequena, longe do centro)
        let big = obs(0.30, 0.10, 0.40, 0.85, 0.95)         // desafiante enorme e central
        var t = trackerWithHint(0.81, 0.50)
        _ = t.update(time: 0, tracked: nil, detections: [small, big])
        var time = 0.0
        for _ in 0..<12 {                                    // 6 s, muito mais que o switchDwell
            time += 0.5
            let f = t.update(time: time, tracked: small, detections: [small, big])
            XCTAssertEqual(f.box, small.box); XCTAssertEqual(f.subjectID, 1)
        }
        // o mesmo cenário SEM escolha manual troca de alvo
        var auto = SubjectTracker()
        _ = auto.update(time: 0, tracked: nil, detections: [small])
        var autoTime = 0.0, switched = false
        for _ in 0..<12 {
            autoTime += 0.5
            if auto.update(time: autoTime, tracked: small, detections: [small, big]).subjectID == 2 { switched = true }
        }
        XCTAssertTrue(switched)
    }

    func testHintOnlyAppliesToTheFirstChoice() {
        var t = trackerWithHint(0.80, 0.50)
        _ = t.update(time: 0, tracked: nil, detections: [A, B])          // escolhe B
        _ = t.update(time: 0.5, tracked: B, detections: [B])
        // B some por muito tempo (> recoveryWindow); só A longe de B aparece.
        var time = 0.5
        while time < 7 {
            time += 0.5
            _ = t.update(time: time, tracked: nil, detections: [])
        }
        let f = t.update(time: 7.5, tracked: nil, detections: [A])
        XCTAssertEqual(f.state, .tracking); XCTAssertEqual(f.box, A.box)
        XCTAssertEqual(f.subjectID, 2)                                      // nova escolha, automática
    }
}
