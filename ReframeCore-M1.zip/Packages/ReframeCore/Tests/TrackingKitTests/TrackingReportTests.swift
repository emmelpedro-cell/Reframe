import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
import ReframeCore
@testable import TrackingKit

final class TrackingReportTests: XCTestCase {

    private func sampleFrames() -> [TrackedFrame] {
        return [
            TrackedFrame(time: 0.0, box: nil, confidence: 0, state: .acquiring, subjectID: nil),
            TrackedFrame(time: 0.1, box: CGRect(x: 0.42, y: 0.18, width: 0.16, height: 0.62),
                         confidence: 0.94, state: .tracking, subjectID: 1),
            TrackedFrame(time: 0.2, box: CGRect(x: 0.43, y: 0.18, width: 0.16, height: 0.62),
                         confidence: 0.66, state: .held, subjectID: 1),
            TrackedFrame(time: 0.3, box: CGRect(x: 0.43, y: 0.18, width: 0.16, height: 0.62),
                         confidence: 0, state: .lost, subjectID: 1)
        ]
    }

    private func sampleReport() -> TrackingReport {
        return TrackingReport(frames: sampleFrames(), duration: 12.4, fps: 30,
                              displaySize: .init(width: 1920, height: 1080),
                              analysisSize: .init(width: 960, height: 540))
    }

    func testJSONRoundTrip() throws {
        let r = sampleReport()
        let decoded = try TrackingReport.decode(from: try r.jsonData())
        XCTAssertEqual(decoded, r)
    }

    func testJSONIsDeterministicAndHasExpectedShape() throws {
        let r = sampleReport()
        XCTAssertEqual(try r.jsonData(), try r.jsonData())
        let obj = try XCTUnwrap(JSONSerialization.jsonObject(with: try r.jsonData()) as? [String: Any])
        XCTAssertEqual(number(obj["duration"]), 12.4)
        XCTAssertEqual(number(obj["fps"]), 30)
        let points = try XCTUnwrap(obj["points"] as? [[String: Any]])
        XCTAssertEqual(points.count, 4)
        let p = points[1]
        XCTAssertEqual(number(p["time"]), 0.1)
        XCTAssertEqual(p["state"] as? String, "tracking")
        XCTAssertEqual(number(p["subjectID"]), 1)
        let box = try XCTUnwrap(p["boundingBox"] as? [String: Any])
        XCTAssertEqual(number(box["x"]), 0.42); XCTAssertEqual(number(box["y"]), 0.18)
        XCTAssertEqual(number(box["width"]), 0.16); XCTAssertEqual(number(box["height"]), 0.62)
        // Enquanto nada foi adquirido, não há boundingBox nem subjectID.
        XCTAssertNil(points[0]["boundingBox"])
        XCTAssertNil(points[0]["subjectID"])
    }

    private func number(_ v: Any?) -> Double? {
        if let d = v as? Double { return d }
        if let i = v as? Int { return Double(i) }
        if let n = v as? NSNumber { return n.doubleValue }
        return nil
    }

    func testSubjectTrackConversion() {
        let id = UUID()
        let track = sampleReport().toSubjectTrack(id: id)
        XCTAssertEqual(track.id, id)
        XCTAssertEqual(track.points.count, 3)                       // `acquiring` fica de fora
        XCTAssertEqual(track.points.map { $0.time }, [0.1, 0.2, 0.3])
        XCTAssertEqual(track.points[0].confidence, 0.94)
        XCTAssertEqual(track.points[2].confidence, 0)               // `lost` entra com confiança 0
        XCTAssertEqual(track.points[0].boundingBox, CGRect(x: 0.42, y: 0.18, width: 0.16, height: 0.62))
    }

    func testSubjectTracksSplitByID() {
        var frames = sampleFrames()
        frames.append(TrackedFrame(time: 6, box: CGRect(x: 0.7, y: 0.2, width: 0.1, height: 0.5),
                                   confidence: 0.9, state: .tracking, subjectID: 2))
        let r = TrackingReport(frames: frames, duration: 7, fps: 30,
                               displaySize: .init(width: 1920, height: 1080),
                               analysisSize: .init(width: 960, height: 540))
        let tracks = r.subjectTracks()
        XCTAssertEqual(tracks.count, 2)
        XCTAssertEqual(tracks[0].points.count, 3)
        XCTAssertEqual(tracks[1].points.count, 1)
    }

    /// O SubjectTrack do TrackingKit alimenta o ReframeEngine SEM alterá-lo.
    func testFeedsTheUnmodifiedReframeEngine() {
        // Pessoa caminhando da esquerda para a direita durante 10 s, a 30 fps,
        // passando pelo SubjectTracker de verdade.
        var tracker = SubjectTracker()
        var frames: [TrackedFrame] = []
        for i in 0..<300 {
            let t = Double(i) / 30
            let x = 0.15 + 0.60 * t / 10
            let o = obs(x, 0.2, 0.08, 0.6, 0.9)
            frames.append(tracker.update(time: t, tracked: i == 0 ? nil : o,
                                         detections: i % 15 == 0 ? [o] : nil))
        }
        let report = TrackingReport(frames: frames, duration: 10, fps: 30,
                                    displaySize: .init(width: 1920, height: 1080),
                                    analysisSize: .init(width: 960, height: 540))
        let engine = ReframeEngine(sourceAspect: 16.0 / 9.0, outputAspect: 9.0 / 16.0)
        let crop = engine.trajectory(for: report.toSubjectTrack(), fps: 30, timeRange: 0...10)
        XCTAssertFalse(crop.isEmpty)
        let g = engine.geometry
        for c in crop {
            XCTAssertGreaterThanOrEqual(Double(c.centerX), g.minCenterX - 1e-9)
            XCTAssertLessThanOrEqual(Double(c.centerX), g.maxCenterX + 1e-9)
        }
        XCTAssertGreaterThan(Double(crop.last!.centerX), Double(crop.first!.centerX) + 0.2)
    }

    /// Frames `lost` (confiança 0) não viram "sujeito presente" para o engine.
    func testLostFramesAreIgnoredByTheEngine() {
        let report = sampleReport()
        let engine = ReframeEngine(sourceAspect: 16.0 / 9.0, outputAspect: 9.0 / 16.0)
        let onlyLost = TrackingReport(frames: [
            TrackedFrame(time: 0, box: CGRect(x: 0.9, y: 0.2, width: 0.05, height: 0.5),
                         confidence: 0, state: .lost, subjectID: 1)
        ], duration: 1, fps: 30, displaySize: report.displaySize, analysisSize: report.analysisSize)
        let crop = engine.trajectory(for: onlyLost.toSubjectTrack(), fps: 30, timeRange: 0...1)
        // Sem nenhuma observação válida o engine fica no centro, não vai atrás do box perdido.
        for c in crop { XCTAssertEqual(Double(c.centerX), 0.5, accuracy: 1e-9) }
    }
}
