import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
#if canImport(AVFoundation) && canImport(Vision)
import AVFoundation
import CoreVideo
import CoreMedia
import ReframeCore
@testable import TrackingKit

// MARK: - Detector de teste

/// Detector de TESTE (não é o Vision): procura pixels magenta no buffer e
/// devolve a caixa deles. Serve para os vídeos-fixture, que têm um bloco
/// magenta se movendo. Assim, o decode, a escala, o preferredTransform e o
/// VNTrackObjectRequest REAL do Vision são exercitados com verdade conhecida.
final class ColorBlockDetector: HumanDetecting {
    private(set) var calls = 0

    func detect(in pb: CVPixelBuffer) throws -> [Observation] {
        calls += 1
        CVPixelBufferLockBaseAddress(pb, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(pb) else { return [] }
        let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb)
        let bpr = CVPixelBufferGetBytesPerRow(pb)
        let ptr = base.assumingMemoryBound(to: UInt8.self)
        var minX = w, maxX = -1, minY = h, maxY = -1, count = 0
        for y in 0..<h {
            let row = ptr + y * bpr
            for x in 0..<w {
                let p = row + x * 4              // BGRA
                let b = p[0], g = p[1], r = p[2]
                if r > 170 && b > 170 && g < 100 {
                    count += 1
                    if x < minX { minX = x }; if x > maxX { maxX = x }
                    if y < minY { minY = y }; if y > maxY { maxY = y }
                }
            }
        }
        guard count >= 30, maxX >= minX, maxY >= minY else { return [] }
        let box = CGRect(x: Double(minX) / Double(w), y: Double(minY) / Double(h),
                         width: Double(maxX - minX + 1) / Double(w), height: Double(maxY - minY + 1) / Double(h))
        return [Observation(box: box, confidence: 0.9)]
    }
}

final class VisionIntegrationTests: XCTestCase {

    // Verdade conhecida dos fixtures (640×360 cru, 30 fps, 3 s):
    // bloco 80×180 px, y = 90..270, x(t) = 40 + 150·t.
    private func rawTruthCenter(at t: Double) -> (x: Double, y: Double) {
        return ((40 + 150 * t + 40) / 640, (90 + 90) / 360)
    }

    private func fixture(_ name: String) throws -> URL {
        let url = Bundle.module.url(forResource: name, withExtension: "mov", subdirectory: "Fixtures")
        return try XCTUnwrap(url, "fixture \(name).mov não encontrado no bundle de testes")
    }

    private func settings(width: Int = 320, redetect: Double = 0.5) -> TrackingSettings {
        var s = TrackingSettings()
        s.analysisWidth = width
        s.redetectInterval = redetect
        s.visionCPUOnly = true      // o runner de CI (VM) não tem GPU
        return s
    }

    private func run(_ name: String, detector: HumanDetecting? = nil,
                     settings: TrackingSettings? = nil, maxSeconds: Double? = nil) async throws -> TrackingResult {
        let pipeline = TrackingPipeline(settings: settings ?? self.settings(), detector: detector ?? ColorBlockDetector())
        return try await pipeline.run(url: try fixture(name), maxSeconds: maxSeconds)
    }

    // MARK: Leitura / timestamps / escala

    func testReaderLandscape() async throws {
        let reader = try await VideoFrameReader.open(url: try fixture("landscape_block"), analysisWidth: 320)
        let info = reader.info
        XCTAssertEqual(info.mapping.displayWidth, 640); XCTAssertEqual(info.mapping.displayHeight, 360)
        XCTAssertEqual(info.mapping.displayAspect, 16.0 / 9.0, accuracy: 1e-9)
        XCTAssertEqual(info.nominalFPS, 30, accuracy: 0.5)
        XCTAssertEqual(info.duration, 3, accuracy: 0.1)
        XCTAssertEqual(info.analysisWidth, 320); XCTAssertEqual(info.analysisHeight, 180)

        var normalizer = TimestampNormalizer()
        var times: [Double] = []
        var firstSize: (Int, Int)?
        try reader.forEachFrame { pixels, pts in
            if firstSize == nil { firstSize = (CVPixelBufferGetWidth(pixels), CVPixelBufferGetHeight(pixels)) }
            if let t = normalizer.normalize(pts) { times.append(t) }
        }
        XCTAssertEqual(firstSize?.0, 320, "o decode deve sair em resolução reduzida")
        XCTAssertEqual(firstSize?.1, 180)
        XCTAssertTrue((88...91).contains(times.count), "frames: \(times.count)")
        XCTAssertEqual(times.first, 0)
        XCTAssertEqual(times.last ?? 0, 89.0 / 30, accuracy: 0.05)
        for i in 1..<times.count { XCTAssertGreaterThan(times[i], times[i - 1]) }
        XCTAssertEqual(TimestampNormalizer.estimatedFPS(times: times) ?? 0, 30, accuracy: 0.5)
    }

    func testReaderDoesNotUpscaleBeyondNaturalWidth() async throws {
        let reader = try await VideoFrameReader.open(url: try fixture("landscape_block"), analysisWidth: 960)
        XCTAssertEqual(reader.info.analysisWidth, 640)
        XCTAssertEqual(reader.info.analysisHeight, 360)
    }

    /// O arquivo é fisicamente 640×360 (landscape) mas tem rotação de 90° (estilo iPhone em retrato).
    func testReaderReadsPreferredTransformOfPortraitVideo() async throws {
        let reader = try await VideoFrameReader.open(url: try fixture("portrait_rotated_block"), analysisWidth: 320)
        let m = reader.info.mapping
        XCTAssertEqual(m.naturalWidth, 640); XCTAssertEqual(m.naturalHeight, 360)
        XCTAssertEqual(m.displayWidth, 360, accuracy: 1e-6)
        XCTAssertEqual(m.displayHeight, 640, accuracy: 1e-6)
        XCTAssertEqual(m.displayAspect, 9.0 / 16.0, accuracy: 1e-9)
        XCTAssertTrue(m.swapsAxes)
        XCTAssertEqual(m.transform.a, 0, accuracy: 1e-6); XCTAssertEqual(m.transform.b, 1, accuracy: 1e-6)
        XCTAssertEqual(m.transform.c, -1, accuracy: 1e-6); XCTAssertEqual(m.transform.d, 0, accuracy: 1e-6)
        // Os buffers continuam CRUS (landscape): quem gira é o mapeamento.
        XCTAssertGreaterThan(reader.info.analysisWidth, reader.info.analysisHeight)
    }

    func testMaxSecondsLimitsProcessing() async throws {
        let r = try await run("landscape_block", maxSeconds: 1.0)
        XCTAssertTrue((30...32).contains(r.frames.count), "frames: \(r.frames.count)")
        XCTAssertLessThanOrEqual(r.frames.last?.time ?? 0, 1.0 + 1.0 / 30)
    }

    // MARK: Pipeline completo, vídeo horizontal

    func testLandscapePipelineFollowsMovingBlock() async throws {
        let r = try await run("landscape_block")
        let report = r.report
        XCTAssertEqual(r.trackerErrors, 0, "erro do tracker: \(r.lastTrackerError ?? "-")")
        XCTAssertEqual(report.displaySize.width, 640); XCTAssertEqual(report.displaySize.height, 360)
        XCTAssertEqual(report.fps, 30, accuracy: 0.5)
        XCTAssertTrue((88...91).contains(report.points.count))

        let tracking = report.points.filter { $0.state == .tracking }
        XCTAssertGreaterThanOrEqual(Double(tracking.count) / Double(report.points.count), 0.9)
        XCTAssertEqual(report.points.first?.state, .tracking)   // detectado já no primeiro frame
        XCTAssertEqual(Set(report.points.compactMap { $0.subjectID }), [1])

        var worst = 0.0
        for p in tracking {
            let box = try XCTUnwrap(p.boundingBox).rect
            let truth = rawTruthCenter(at: p.time)
            let err = max(abs(Double(box.midX) - truth.x), abs(Double(box.midY) - truth.y))
            worst = max(worst, err)
            XCTAssertEqual(Double(box.width), 0.125, accuracy: 0.06, "t=\(p.time)")
            XCTAssertEqual(Double(box.height), 0.5, accuracy: 0.12, "t=\(p.time)")
        }
        XCTAssertLessThan(worst, 0.05, "maior erro do centro (normalizado): \(worst)")

        // A caixa realmente ANDA: da esquerda para a direita.
        let first = try XCTUnwrap(tracking.first?.boundingBox).rect
        let last = try XCTUnwrap(tracking.last?.boundingBox).rect
        XCTAssertGreaterThan(Double(last.midX - first.midX), 0.55)
        XCTAssertEqual(Double(last.midY), Double(first.midY), accuracy: 0.05)
    }

    // MARK: preferredTransform no pipeline completo

    func testPortraitPipelineProducesCoordinatesInVisualOrientation() async throws {
        let r = try await run("portrait_rotated_block")
        let report = r.report
        XCTAssertEqual(r.trackerErrors, 0, "erro do tracker: \(r.lastTrackerError ?? "-")")
        XCTAssertEqual(report.displaySize.width, 360, accuracy: 1e-6)
        XCTAssertEqual(report.displaySize.height, 640, accuracy: 1e-6)

        let tracking = report.points.filter { $0.state == .tracking }
        XCTAssertGreaterThanOrEqual(Double(tracking.count) / Double(report.points.count), 0.9)

        // Girando 90° horário, o bloco que anda da esquerda para a direita no ARQUIVO
        // desce na TELA: cx = 1 − y_arquivo (constante, 0,5) e cy = x_arquivo.
        var worst = 0.0
        for p in tracking {
            let box = try XCTUnwrap(p.boundingBox).rect
            let raw = rawTruthCenter(at: p.time)
            let expectedCX = 1 - raw.y, expectedCY = raw.x
            worst = max(worst, abs(Double(box.midX) - expectedCX), abs(Double(box.midY) - expectedCY))
            // No arquivo 80×180 px (alto 0,5 × largo 0,125); na tela vira 180×80 px → 0,5 × 0,125.
            XCTAssertEqual(Double(box.width), 0.5, accuracy: 0.12, "t=\(p.time)")
            XCTAssertEqual(Double(box.height), 0.125, accuracy: 0.06, "t=\(p.time)")
        }
        XCTAssertLessThan(worst, 0.05, "maior erro (normalizado): \(worst)")

        let first = try XCTUnwrap(tracking.first?.boundingBox).rect
        let last = try XCTUnwrap(tracking.last?.boundingBox).rect
        XCTAssertGreaterThan(Double(last.midY - first.midY), 0.5)          // desceu
        XCTAssertEqual(Double(last.midX), Double(first.midX), accuracy: 0.05) // sem deriva lateral
    }

    // MARK: Sem ninguém / Vision real

    func testSceneWithoutPeopleGivesValidEmptyTrack() async throws {
        let r = try await run("empty_scene")
        XCTAssertFalse(r.report.points.isEmpty)
        XCTAssertTrue(r.report.points.allSatisfy { $0.state == .acquiring && $0.boundingBox == nil })
        XCTAssertTrue(r.report.toSubjectTrack().points.isEmpty)
        _ = try r.report.jsonData()
        let engine = ReframeEngine(sourceAspect: 16.0 / 9.0, outputAspect: 9.0 / 16.0)
        let crop = engine.trajectory(for: r.report.toSubjectTrack(), fps: 30, timeRange: 0...1)
        XCTAssertTrue(crop.allSatisfy { abs(Double($0.centerX) - 0.5) < 1e-9 })
    }

    /// O detector REAL do Vision roda de ponta a ponta e produz um track válido.
    /// (Os fixtures não têm gente de verdade: aqui não afirmamos o que ele acha,
    /// só que o pipeline não quebra e o resultado é consistente.)
    func testRealVisionHumanDetectorProducesValidTrack() async throws {
        let result: TrackingResult
        do {
            result = try await run("landscape_block", detector: VisionHumanDetector(cpuOnly: true), maxSeconds: 1.0)
        } catch let e as TrackingError {
            if case .visionFailed(let m) = e { throw XCTSkip("Vision indisponível neste ambiente: \(m)") }
            throw e
        }
        XCTAssertFalse(result.report.points.isEmpty)
        var last = -1.0
        for p in result.report.points {
            XCTAssertGreaterThan(p.time, last); last = p.time
            XCTAssertTrue(p.confidence.isFinite)
            if let b = p.boundingBox { XCTAssertTrue(BoxMath.isValid(b.rect)) }
        }
        _ = try result.report.jsonData()
    }

    // MARK: Redetecção configurável

    func testRedetectionIntervalIsConfigurable() async throws {
        let fast = ColorBlockDetector(), slow = ColorBlockDetector()
        _ = try await run("landscape_block", detector: fast, settings: settings(redetect: 0.5))
        _ = try await run("landscape_block", detector: slow, settings: settings(redetect: 1.0))
        XCTAssertTrue((5...8).contains(fast.calls), "0,5 s: \(fast.calls) detecções")
        XCTAssertTrue((3...5).contains(slow.calls), "1,0 s: \(slow.calls) detecções")
        XCTAssertGreaterThan(fast.calls, slow.calls)
    }

    // MARK: Vídeo de debug

    func testDebugVideoIsWrittenForLandscape() async throws {
        let url = try fixture("landscape_block")
        let r = try await run("landscape_block")
        let reader = try await VideoFrameReader.open(url: url, analysisWidth: 320)
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("debug_\(UUID().uuidString).mp4")
        defer { try? FileManager.default.removeItem(at: out) }
        try DebugVideoWriter.write(reader: reader, report: r.report, to: out, showCrop: true)

        let size = (try FileManager.default.attributesOfItem(atPath: out.path)[.size] as? Int) ?? 0
        XCTAssertGreaterThan(size, 1000)
        let asset = AVURLAsset(url: out)
        let tracks = try await asset.loadTracks(withMediaType: .video)
        XCTAssertEqual(tracks.count, 1)
        let natural = try await tracks[0].load(.naturalSize)
        XCTAssertEqual(Double(natural.width), 320); XCTAssertEqual(Double(natural.height), 180)
        let cmDuration = try await asset.load(.duration)
        XCTAssertEqual(CMTimeGetSeconds(cmDuration), 3, accuracy: 0.2)
    }

    func testDebugVideoKeepsPreferredTransformForPortrait() async throws {
        let url = try fixture("portrait_rotated_block")
        let r = try await run("portrait_rotated_block")
        let reader = try await VideoFrameReader.open(url: url, analysisWidth: 320)
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("debug_\(UUID().uuidString).mp4")
        defer { try? FileManager.default.removeItem(at: out) }
        try DebugVideoWriter.write(reader: reader, report: r.report, to: out, showCrop: false)

        let asset = AVURLAsset(url: out)
        let tracks = try await asset.loadTracks(withMediaType: .video)
        let t = try await tracks[0].load(.preferredTransform)
        XCTAssertEqual(Double(t.a), 0, accuracy: 1e-6); XCTAssertEqual(Double(t.b), 1, accuracy: 1e-6)
        XCTAssertEqual(Double(t.c), -1, accuracy: 1e-6); XCTAssertEqual(Double(t.d), 0, accuracy: 1e-6)
    }
}
#endif
