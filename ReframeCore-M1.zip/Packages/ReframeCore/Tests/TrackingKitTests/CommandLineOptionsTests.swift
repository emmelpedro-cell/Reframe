import XCTest
import Foundation
@testable import TrackingKit

final class CommandLineOptionsTests: XCTestCase {

    func testMinimalTrackCommand() throws {
        let o = try TrackCommandOptions.parse(["track", "in.mov", "--output", "out.json"])
        XCTAssertEqual(o.input, "in.mov"); XCTAssertEqual(o.output, "out.json")
        XCTAssertNil(o.debugVideo); XCTAssertFalse(o.showCrop)
        XCTAssertNil(o.analysisWidth); XCTAssertNil(o.redetectInterval); XCTAssertNil(o.maxSeconds)
    }

    func testAllOptionsAndAnyOrder() throws {
        let o = try TrackCommandOptions.parse(["track", "--output", "t.json", "--crop", "--debug-video", "d.mp4",
                                               "--analysis-width", "640", "--redetect", "0.25",
                                               "--max-seconds", "12", "clip.mov"])
        XCTAssertEqual(o.input, "clip.mov"); XCTAssertEqual(o.output, "t.json")
        XCTAssertEqual(o.debugVideo, "d.mp4"); XCTAssertTrue(o.showCrop)
        XCTAssertEqual(o.analysisWidth, 640); XCTAssertEqual(o.redetectInterval, 0.25)
        XCTAssertEqual(o.maxSeconds, 12)
    }

    func testSettingsMapping() throws {
        let o = try TrackCommandOptions.parse(["track", "a.mov", "-o", "a.json", "--analysis-width", "480", "--redetect", "1"])
        let s = o.settings()
        XCTAssertEqual(s.analysisWidth, 480); XCTAssertEqual(s.redetectInterval, 1)
        XCTAssertEqual(s.holdDuration, TrackingSettings.default.holdDuration) // o resto não muda
        XCTAssertFalse(s.visionCPUOnly)
        let cpu = try TrackCommandOptions.parse(["track", "a.mov", "-o", "a.json", "--cpu-only"])
        XCTAssertTrue(cpu.cpuOnly); XCTAssertTrue(cpu.settings().visionCPUOnly)
        XCTAssertEqual(TrackingSettings.default.analysisWidth, 960)
        XCTAssertEqual(TrackingSettings.default.redetectInterval, 0.5)
    }

    func testErrors() {
        func parseError(_ args: [String]) -> TrackCommandOptions.ParseError? {
            do { _ = try TrackCommandOptions.parse(args); return nil }
            catch let e as TrackCommandOptions.ParseError { return e }
            catch { return nil }
        }
        XCTAssertEqual(parseError([]), .missingCommand)
        XCTAssertEqual(parseError(["render", "a.mov"]), .unknownCommand("render"))
        XCTAssertEqual(parseError(["track", "--output", "o.json"]), .missingInput)
        XCTAssertEqual(parseError(["track", "a.mov"]), .missingOutput)
        XCTAssertEqual(parseError(["track", "a.mov", "--output"]), .missingValue("--output"))
        XCTAssertEqual(parseError(["track", "a.mov", "-o", "o.json", "--bogus"]), .unknownOption("--bogus"))
        XCTAssertEqual(parseError(["track", "a.mov", "-o", "o.json", "--redetect", "abc"]), .invalidValue("--redetect", "abc"))
        XCTAssertEqual(parseError(["track", "a.mov", "-o", "o.json", "--redetect", "-1"]), .invalidValue("--redetect", "-1"))
        XCTAssertEqual(parseError(["track", "a.mov", "-o", "o.json", "--analysis-width", "4"]), .invalidValue("--analysis-width", "4"))
    }
}
