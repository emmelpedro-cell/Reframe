import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
#if canImport(AVFoundation) && canImport(Vision) && canImport(CoreImage)
import AVFoundation
import CoreVideo
import CoreMedia
import ReframeCore
@testable import TrackingKit

/// Render vertical de ponta a ponta com os vídeos-fixture (bloco magenta se movendo):
/// tracking (tracker real do Vision + detector de cor) → engine → VerticalRenderer → MP4,
/// e depois a leitura do MP4 gerado para conferir o que saiu.
final class RenderIntegrationTests: XCTestCase {

    // O bloco magenta cru tem 80×180 px de 640×360 → 14 400 px no frame de exibição landscape.
    private let blockPixels = 80 * 180

    private func fixture(_ name: String) throws -> URL {
        let url = Bundle.module.url(forResource: name, withExtension: "mov", subdirectory: "Fixtures")
        return try XCTUnwrap(url, "fixture \(name).mov não encontrado")
    }

    private func tempURL(_ ext: String = "mp4") -> URL {
        return FileManager.default.temporaryDirectory.appendingPathComponent("render_\(UUID().uuidString).\(ext)")
    }

    private func track(_ name: String) async throws -> TrackingReport {
        var s = TrackingSettings()
        s.analysisWidth = 320
        s.visionCPUOnly = true       // o runner de CI (VM) não tem GPU
        let r = try await TrackingPipeline(settings: s, detector: ColorBlockDetector()).run(url: try fixture(name))
        XCTAssertEqual(r.trackerErrors, 0, "erro do tracker: \(r.lastTrackerError ?? "-")")
        return r.report
    }

    private struct OutFrame {
        let time: Double
        let magentaCount: Int
        /// Centro do magenta, normalizado (0...1, origem topo-esquerdo) no frame de SAÍDA.
        let cx: Double, cy: Double
    }

    /// Lê o MP4 gerado e localiza o bloco magenta em cada frame.
    private func readOutput(_ url: URL) async throws -> (frames: [OutFrame], width: Int, height: Int) {
        let asset = AVURLAsset(url: url)
        let track = try XCTUnwrap(try await asset.loadTracks(withMediaType: .video).first)
        let reader = try AVAssetReader(asset: asset)
        let out = AVAssetReaderTrackOutput(track: track, outputSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ])
        reader.add(out)
        XCTAssertTrue(reader.startReading())
        var frames: [OutFrame] = []
        var first: Double?
        var size = (0, 0)
        while let sample = out.copyNextSampleBuffer() {
            guard let pb = CMSampleBufferGetImageBuffer(sample) else { continue }
            let pts = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
            if first == nil { first = pts }
            CVPixelBufferLockBaseAddress(pb, .readOnly)
            let w = CVPixelBufferGetWidth(pb), h = CVPixelBufferGetHeight(pb)
            size = (w, h)
            let bpr = CVPixelBufferGetBytesPerRow(pb)
            let ptr = CVPixelBufferGetBaseAddress(pb)!.assumingMemoryBound(to: UInt8.self)
            var count = 0, sx = 0.0, sy = 0.0
            for y in 0..<h {
                let row = ptr + y * bpr
                for x in 0..<w {
                    let p = row + x * 4
                    if p[2] > 170 && p[0] > 170 && p[1] < 100 { count += 1; sx += Double(x); sy += Double(y) }
                }
            }
            CVPixelBufferUnlockBaseAddress(pb, .readOnly)
            frames.append(OutFrame(time: pts - (first ?? pts), magentaCount: count,
                                   cx: count > 0 ? sx / Double(count) / Double(w) : -1,
                                   cy: count > 0 ? sy / Double(count) / Double(h) : -1))
        }
        XCTAssertEqual(reader.status, .completed)
        return (frames, size.0, size.1)
    }

    // MARK: Recorte vertical, em todas as orientações

    /// Para cada orientação do arquivo (identidade, 180°, 90° horário e anti-horário) o vídeo,
    /// depois do preferredTransform, é a MESMA cena landscape. O render precisa manter o bloco
    /// dentro da janela 9:16 na maior parte do tempo e produzir 202×360 (608/1080 → 9:16 em 360 px).
    func testVerticalRenderKeepsSubjectInViewForEveryOrientation() async throws {
        let cases: [(String, DisplayOrientation)] = [
            ("landscape_block", .up),
            ("landscape_rot180", .rotated180),
            ("landscape_via_ccw90", .counterClockwise90),
            ("landscape_via_cw90", .clockwise90)
        ]
        for (name, expected) in cases {
            let report = try await track(name)
            XCTAssertEqual(report.displaySize.width, 640, "\(name)")
            XCTAssertEqual(report.displaySize.height, 360, "\(name)")

            let out = tempURL()
            defer { try? FileManager.default.removeItem(at: out) }
            let result = try await VerticalRenderer.render(input: try fixture(name), report: report, output: out)
            XCTAssertEqual(result.orientation, expected, "\(name)")
            XCTAssertEqual(result.outputWidth, 202, "\(name)")
            XCTAssertEqual(result.outputHeight, 360, "\(name)")
            XCTAssertFalse(result.hasAudio, "\(name)")

            let (frames, w, h) = try await readOutput(out)
            XCTAssertEqual(w, 202, "\(name)"); XCTAssertEqual(h, 360, "\(name)")
            XCTAssertTrue((88...91).contains(frames.count), "\(name): \(frames.count) frames")
            XCTAssertEqual(result.framesWritten, frames.count, "\(name)")

            // O bloco aparece (>= 50 % dos pixels) em pelo menos 85 % dos frames...
            let visible = frames.filter { $0.magentaCount >= blockPixels / 2 }
            XCTAssertGreaterThanOrEqual(Double(visible.count) / Double(frames.count), 0.85,
                                        "\(name): bloco visível em \(visible.count)/\(frames.count) frames")
            // ...e fica no miolo da janela (a câmera vai atrás dele).
            for f in visible { XCTAssertTrue((0.1...0.9).contains(f.cx), "\(name) t=\(f.time) cx=\(f.cx)") }
            // O bloco passa de lado a lado do vídeo original, mas a janela é estreita: sem
            // seguir o sujeito ele sairia do quadro; aqui ele aparece nos dois extremos do vídeo.
            XCTAssertGreaterThanOrEqual(frames.first?.magentaCount ?? 0, blockPixels / 2, "\(name) primeiro frame")
            XCTAssertGreaterThanOrEqual(frames.last?.magentaCount ?? 0, blockPixels / 2, "\(name) último frame")
        }
    }

    /// Fixture em retrato (9:16 depois do transform): a saída é o frame inteiro, de pé,
    /// e o bloco desce na tela exatamente como o tracking afirma.
    func testPortraitSourceIsRenderedUpright() async throws {
        let report = try await track("portrait_rotated_block")
        let out = tempURL()
        defer { try? FileManager.default.removeItem(at: out) }
        let result = try await VerticalRenderer.render(input: try fixture("portrait_rotated_block"), report: report, output: out)
        XCTAssertEqual(result.orientation, .clockwise90)
        XCTAssertEqual(result.outputWidth, 360); XCTAssertEqual(result.outputHeight, 640)

        let (frames, w, h) = try await readOutput(out)
        XCTAssertEqual(w, 360); XCTAssertEqual(h, 640)
        let visible = frames.filter { $0.magentaCount > 5000 }
        XCTAssertGreaterThanOrEqual(Double(visible.count) / Double(frames.count), 0.95)
        for f in visible {
            // Verdade conhecida: cx = 0,5 constante; cy = (80 + 150·t)/640 (desce).
            XCTAssertEqual(f.cx, 0.5, accuracy: 0.05, "t=\(f.time)")
            XCTAssertEqual(f.cy, (80 + 150 * f.time) / 640, accuracy: 0.05, "t=\(f.time)")
        }
    }

    // MARK: Áudio

    func testAudioIsCopiedWithoutReencoding() async throws {
        let input = try fixture("landscape_block_audio")
        let report = try await track("landscape_block_audio")
        let out = tempURL()
        defer { try? FileManager.default.removeItem(at: out) }
        let result = try await VerticalRenderer.render(input: input, report: report, output: out)
        XCTAssertTrue(result.hasAudio)
        XCTAssertFalse(result.audioReencoded, "o áudio AAC deve ser copiado sem recodificar")

        let outAsset = AVURLAsset(url: out)
        let audioTracks = try await outAsset.loadTracks(withMediaType: .audio)
        XCTAssertEqual(audioTracks.count, 1)
        let formats = try await audioTracks[0].load(.formatDescriptions)
        let subtype = try XCTUnwrap(formats.first).mediaSubType.rawValue
        XCTAssertEqual(subtype, kAudioFormatMPEG4AAC)

        let inAsset = AVURLAsset(url: input)
        let inAudio = try XCTUnwrap(try await inAsset.loadTracks(withMediaType: .audio).first)
        let inRange = try await inAudio.load(.timeRange)
        let outRange = try await audioTracks[0].load(.timeRange)
        XCTAssertEqual(CMTimeGetSeconds(outRange.duration), CMTimeGetSeconds(inRange.duration), accuracy: 0.1)
        XCTAssertEqual(CMTimeGetSeconds(outRange.start), CMTimeGetSeconds(inRange.start), accuracy: 0.1)

        // O vídeo continua com a duração do original.
        let outVideo = try XCTUnwrap(try await outAsset.loadTracks(withMediaType: .video).first)
        let vRange = try await outVideo.load(.timeRange)
        XCTAssertEqual(CMTimeGetSeconds(vRange.duration), 3, accuracy: 0.15)
    }

    // MARK: Opções

    func testOutputHeightScalesTheWholeFrameBeforeCropping() async throws {
        let report = try await track("landscape_block")
        var opts = RenderOptions()
        opts.outputHeight = 180
        let out = tempURL()
        defer { try? FileManager.default.removeItem(at: out) }
        let result = try await VerticalRenderer.render(input: try fixture("landscape_block"), report: report, output: out, options: opts)
        XCTAssertEqual(result.outputHeight, 180)
        XCTAssertEqual(result.outputWidth, 100)       // 180 · 9/16 = 101,25 → 101 → par: 100
        let (frames, w, h) = try await readOutput(out)
        XCTAssertEqual(w, 100); XCTAssertEqual(h, 180)
        // Bloco reduzido à metade (40×90 = 3 600 px): continua aparecendo.
        let visible = frames.filter { $0.magentaCount >= 3600 / 2 }
        XCTAssertGreaterThanOrEqual(Double(visible.count) / Double(frames.count), 0.85)
    }

    func testOtherAspectRatios() async throws {
        let report = try await track("landscape_block")
        for (aspect, expectedW, expectedH) in [(1.0, 360, 360), (4.0 / 5.0, 288, 360)] {
            var opts = RenderOptions()
            opts.aspect = aspect
            let out = tempURL()
            defer { try? FileManager.default.removeItem(at: out) }
            let result = try await VerticalRenderer.render(input: try fixture("landscape_block"), report: report, output: out, options: opts)
            XCTAssertEqual(result.outputWidth, expectedW, "aspect \(aspect)")
            XCTAssertEqual(result.outputHeight, expectedH, "aspect \(aspect)")
            let (frames, w, h) = try await readOutput(out)
            XCTAssertEqual(w, expectedW); XCTAssertEqual(h, expectedH)
            XCTAssertTrue((88...91).contains(frames.count))
        }
    }

    func testMaxSecondsLimitsTheRender() async throws {
        let report = try await track("landscape_block")
        var opts = RenderOptions()
        opts.maxSeconds = 1.0
        let out = tempURL()
        defer { try? FileManager.default.removeItem(at: out) }
        let result = try await VerticalRenderer.render(input: try fixture("landscape_block"), report: report, output: out, options: opts)
        XCTAssertTrue((30...32).contains(result.framesWritten), "frames: \(result.framesWritten)")
    }

    func testOneEuroOptionRendersAValidVideo() async throws {
        let report = try await track("landscape_block")
        var base = RenderOptions(), exp = RenderOptions()
        exp.useOneEuro = true
        base.useOneEuro = false
        let a = tempURL(), b = tempURL()
        defer { try? FileManager.default.removeItem(at: a); try? FileManager.default.removeItem(at: b) }
        let ra = try await VerticalRenderer.render(input: try fixture("landscape_block"), report: report, output: a, options: base)
        let rb = try await VerticalRenderer.render(input: try fixture("landscape_block"), report: report, output: b, options: exp)
        XCTAssertEqual(ra.framesWritten, rb.framesWritten)
        XCTAssertEqual(ra.outputWidth, rb.outputWidth)
        let (fb, _, _) = try await readOutput(b)
        XCTAssertGreaterThanOrEqual(Double(fb.filter { $0.magentaCount >= blockPixels / 2 }.count) / Double(fb.count), 0.8)
    }

    func testMovContainerIsSupported() async throws {
        let report = try await track("landscape_block_audio")
        let out = tempURL("mov")
        defer { try? FileManager.default.removeItem(at: out) }
        let result = try await VerticalRenderer.render(input: try fixture("landscape_block_audio"), report: report, output: out)
        XCTAssertTrue(result.hasAudio)
        let (frames, _, _) = try await readOutput(out)
        XCTAssertTrue((88...91).contains(frames.count))
    }

    // MARK: Erros

    func testMismatchedTrackingIsRejected() async throws {
        var report = try await track("landscape_block")
        report.displaySize = .init(width: 1080, height: 1920)       // tracking de outro vídeo
        let out = tempURL()
        defer { try? FileManager.default.removeItem(at: out) }
        do {
            _ = try await VerticalRenderer.render(input: try fixture("landscape_block"), report: report, output: out)
            XCTFail("deveria rejeitar um tracking de outro tamanho")
        } catch let e as RenderError {
            guard case .trackingMismatch = e else { return XCTFail("erro inesperado: \(e)") }
        }
    }

    func testTrackingWithoutAnyPersonStillRendersACenteredCrop() async throws {
        let report = try await track("empty_scene")
        let out = tempURL()
        defer { try? FileManager.default.removeItem(at: out) }
        let result = try await VerticalRenderer.render(input: try fixture("empty_scene"), report: report, output: out)
        XCTAssertEqual(result.outputWidth, 202)
        XCTAssertTrue((29...31).contains(result.framesWritten))
    }
}
#endif
