import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import TrackingKit

func obs(_ x: Double, _ y: Double, _ w: Double, _ h: Double, _ c: Float = 0.9) -> Observation {
    return Observation(box: CGRect(x: x, y: y, width: w, height: h), confidence: c)
}

final class SubjectSelectorTests: XCTestCase {
    let selector = SubjectSelector()

    func testBiggerBoxScoresHigher() {
        let small = CGRect(x: 0.45, y: 0.4, width: 0.05, height: 0.1)
        let big = CGRect(x: 0.4, y: 0.2, width: 0.2, height: 0.6)
        XCTAssertGreaterThan(selector.score(box: big, incumbent: nil), selector.score(box: small, incumbent: nil))
    }

    func testCentralBoxScoresHigherThanEdgeBoxOfSameSize() {
        let center = CGRect(x: 0.4, y: 0.2, width: 0.2, height: 0.6)
        let edge = CGRect(x: 0.0, y: 0.2, width: 0.2, height: 0.6)
        XCTAssertGreaterThan(selector.score(box: center, incumbent: nil), selector.score(box: edge, incumbent: nil))
    }

    func testPersistenceRaisesScoreOfTheIncumbent() {
        let b = CGRect(x: 0.1, y: 0.2, width: 0.2, height: 0.6)
        XCTAssertGreaterThan(selector.score(box: b, incumbent: b), selector.score(box: b, incumbent: nil))
    }

    func testUsableFiltersLowConfidenceAndInvalid() {
        let all = [obs(0.1, 0.1, 0.2, 0.5, 0.1),            // baixa confiança
                   obs(0.3, 0.1, 0.2, 0.5, .nan),           // confiança inválida
                   obs(0.3, 0.1, 0.0, 0.5, 0.9),            // largura zero
                   obs(0.5, 0.1, 0.2, 0.5, 0.9)]            // ok
        XCTAssertEqual(selector.usable(all).count, 1)
    }

    func testPickInitialPrefersLargeCentralPerson() {
        let sideSmall = obs(0.02, 0.4, 0.06, 0.25)
        let centralBig = obs(0.4, 0.15, 0.2, 0.7)
        XCTAssertEqual(selector.pickInitial([sideSmall, centralBig]), centralBig)
        XCTAssertEqual(selector.pickInitial([centralBig, sideSmall]), centralBig)
    }

    func testPickInitialIsOrderIndependent() {
        var rng = DeterministicRNG(seed: 3)
        for _ in 0..<50 {
            let list = (0..<5).map { _ in obs(rng.next(0, 0.8), rng.next(0, 0.5), rng.next(0.05, 0.2), rng.next(0.1, 0.5)) }
            let a = selector.pickInitial(list)
            let b = selector.pickInitial(Array(list.reversed()))
            XCTAssertEqual(a, b)
        }
    }

    func testPickInitialWithNothingUsable() {
        XCTAssertNil(selector.pickInitial([]))
        XCTAssertNil(selector.pickInitial([obs(0.1, 0.1, 0.2, 0.5, 0.05)]))
    }

    func testBestMatchPicksHighestIoUAndRespectsThreshold() {
        let ref = CGRect(x: 0.4, y: 0.2, width: 0.2, height: 0.6)
        let near = obs(0.42, 0.2, 0.2, 0.6)
        let far = obs(0.8, 0.2, 0.15, 0.6)
        XCTAssertEqual(selector.bestMatch(for: ref, among: [far, near], minIoU: 0.3), near)
        XCTAssertNil(selector.bestMatch(for: ref, among: [far], minIoU: 0.3))
        XCTAssertNil(selector.bestMatch(for: ref, among: [obs(0.55, 0.2, 0.2, 0.6)], minIoU: 0.9))
    }

    func testBestMatchProximityForRecovery() {
        let ref = CGRect(x: 0.40, y: 0.2, width: 0.15, height: 0.6)
        // Sem sobreposição, mas perto e do mesmo tamanho: aceito só no modo recuperação.
        let moved = obs(0.62, 0.2, 0.15, 0.6)
        XCTAssertNil(selector.bestMatch(for: ref, among: [moved], minIoU: 0.1, allowProximity: false))
        XCTAssertEqual(selector.bestMatch(for: ref, among: [moved], minIoU: 0.1, allowProximity: true), moved)
        // Longe demais.
        XCTAssertNil(selector.bestMatch(for: ref, among: [obs(0.85, 0.2, 0.15, 0.6)], minIoU: 0.1, allowProximity: true))
        // Perto, mas de tamanho muito diferente.
        XCTAssertNil(selector.bestMatch(for: ref, among: [obs(0.62, 0.55, 0.05, 0.1)], minIoU: 0.1, allowProximity: true))
    }

    func testBiggerPersonDoesNotBeatIncumbentByMargin() {
        // Atual: já grande e central (com bônus de persistência). O outro é só um pouco maior.
        let incumbent = CGRect(x: 0.4, y: 0.2, width: 0.2, height: 0.6)
        let bigger = obs(0.05, 0.1, 0.3, 0.8)
        XCTAssertNil(selector.challenger(against: incumbent, among: [bigger]))
    }

    func testClearlyBetterPersonIsAChallenger() {
        let incumbent = CGRect(x: 0.05, y: 0.4, width: 0.05, height: 0.2) // pequeno e na borda
        let better = obs(0.35, 0.2, 0.3, 0.6)                              // grande e central
        XCTAssertEqual(selector.challenger(against: incumbent, among: [better]), better)
    }

    func testIncumbentItselfIsNeverItsOwnChallenger() {
        let incumbent = CGRect(x: 0.05, y: 0.4, width: 0.05, height: 0.2)
        XCTAssertNil(selector.challenger(against: incumbent, among: [Observation(box: incumbent, confidence: 0.9)]))
    }
}
