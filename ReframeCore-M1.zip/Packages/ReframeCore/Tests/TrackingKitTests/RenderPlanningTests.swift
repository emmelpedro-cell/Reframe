import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
import ReframeCore
@testable import TrackingKit

final class RenderPlanningTests: XCTestCase {

    // MARK: DisplayOrientation

    func testOrientationFromStandardIPhoneTransforms() {
        XCTAssertEqual(DisplayOrientation(transform: .identity), .up)
        XCTAssertEqual(DisplayOrientation(transform: .rotated90Clockwise(naturalHeight: 1080)), .clockwise90)
        XCTAssertEqual(DisplayOrientation(transform: .rotated180(naturalWidth: 1920, naturalHeight: 1080)), .rotated180)
        XCTAssertEqual(DisplayOrientation(transform: .rotated90CounterClockwise(naturalWidth: 1920)), .counterClockwise90)
    }

    func testOrientationIgnoresTranslation() {
        XCTAssertEqual(DisplayOrientation(transform: PreferredTransform(a: 0, b: 1, c: -1, d: 0, tx: 0, ty: 0)), .clockwise90)
        XCTAssertEqual(DisplayOrientation(transform: PreferredTransform(a: -1, b: 0, c: 0, d: -1, tx: 123, ty: -4)), .rotated180)
    }

    func testUnsupportedTransformsAreRejected() {
        // espelhamento horizontal
        XCTAssertNil(DisplayOrientation(transform: PreferredTransform(a: -1, b: 0, c: 0, d: 1, tx: 1920, ty: 0)))
        // rotação de 45°
        let s = 2.0.squareRoot() / 2
        XCTAssertNil(DisplayOrientation(transform: PreferredTransform(a: s, b: s, c: -s, d: s, tx: 0, ty: 0)))
        // escala
        XCTAssertNil(DisplayOrientation(transform: PreferredTransform(a: 2, b: 0, c: 0, d: 2, tx: 0, ty: 0)))
    }

    // MARK: RenderGeometry

    func testGeometryHorizontalToVertical1080p() throws {
        let g = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 9.0 / 16.0))
        XCTAssertEqual(g.outputHeight, 1080)
        XCTAssertEqual(g.outputWidth, 608)       // 607,5 → 608 (par)
        XCTAssertEqual(g.scale, 1)
        XCTAssertEqual(g.outputWidth % 2, 0)
        XCTAssertEqual(Double(g.outputWidth) / Double(g.outputHeight), 9.0 / 16.0, accuracy: 0.001)
    }

    func testGeometryOtherAspects() throws {
        let g45 = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 4.0 / 5.0))
        XCTAssertEqual(g45.outputWidth, 864); XCTAssertEqual(g45.outputHeight, 1080)
        let g11 = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 1))
        XCTAssertEqual(g11.outputWidth, 1080); XCTAssertEqual(g11.outputHeight, 1080)
    }

    func testGeometry4KKeepsFullResolution() throws {
        let g = try XCTUnwrap(RenderGeometry(displayWidth: 3840, displayHeight: 2160, outputAspect: 9.0 / 16.0))
        XCTAssertEqual(g.outputHeight, 2160)
        XCTAssertEqual(g.outputWidth, 1214)      // 1215 → 1214 (par)
    }

    func testGeometryWithOutputHeightScalesFirst() throws {
        let g = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 9.0 / 16.0, outputHeight: 540))
        XCTAssertEqual(g.outputHeight, 540)
        XCTAssertEqual(g.outputWidth, 304)       // 303,75 → 304
        XCTAssertEqual(g.scale, 0.5)
        XCTAssertEqual(g.scaledWidth, 960)
        // Upscale também é aceito (ex.: 1080 → 1920 de altura).
        let up = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 9.0 / 16.0, outputHeight: 1920))
        XCTAssertEqual(up.outputWidth, 1080); XCTAssertEqual(up.outputHeight, 1920)
    }

    func testGeometryOddOutputHeightBecomesEven() throws {
        let g = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 9.0 / 16.0, outputHeight: 721))
        XCTAssertEqual(g.outputHeight % 2, 0); XCTAssertEqual(g.outputWidth % 2, 0)
    }

    func testGeometryVerticalSourceUsesWholeFrame() throws {
        // Fonte já 9:16 pedindo 9:16: a saída é o frame inteiro.
        let g = try XCTUnwrap(RenderGeometry(displayWidth: 1080, displayHeight: 1920, outputAspect: 9.0 / 16.0))
        XCTAssertEqual(g.outputWidth, 1080); XCTAssertEqual(g.outputHeight, 1920)
        XCTAssertEqual(g.cropX(centerX: 0.2), 0)
        // Fonte mais estreita que a saída pedida (ex.: 9:16 → 1:1): não passa da largura do frame.
        let wide = try XCTUnwrap(RenderGeometry(displayWidth: 1080, displayHeight: 1920, outputAspect: 1))
        XCTAssertLessThanOrEqual(wide.outputWidth, 1080)
    }

    func testGeometryRejectsInvalidInput() {
        XCTAssertNil(RenderGeometry(displayWidth: 0, displayHeight: 1080, outputAspect: 0.5))
        XCTAssertNil(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 0))
        XCTAssertNil(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: .nan))
        XCTAssertNil(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 0.5, outputHeight: 1))
    }

    func testCropXAlwaysInsideTheFrame() throws {
        let g = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 9.0 / 16.0))
        XCTAssertEqual(g.cropX(centerX: 0.5), 960 - 304, accuracy: 1e-9)
        XCTAssertEqual(g.cropX(centerX: 0), 0)                       // encostado à esquerda
        XCTAssertEqual(g.cropX(centerX: 1), 1920 - 608, accuracy: 1e-9) // encostado à direita
        XCTAssertEqual(g.cropX(centerX: -5), 0)
        XCTAssertEqual(g.cropX(centerX: 7), 1920 - 608, accuracy: 1e-9)
        XCTAssertEqual(g.cropX(centerX: .nan), (1920 - 608) / 2, accuracy: 1e-9)
        var rng = DeterministicRNG(seed: 21)
        for _ in 0..<500 {
            let x = g.cropX(centerX: rng.next(-0.5, 1.5))
            XCTAssertGreaterThanOrEqual(x, 0)
            XCTAssertLessThanOrEqual(x + Double(g.outputWidth), g.scaledWidth + 1e-9)
        }
    }

    /// O centro do engine (limitado a [cropWidth/2, 1−cropWidth/2]) cai dentro do frame sem ser cortado pelo clamp.
    func testEngineCenterMapsToPixelsWithoutExtraClamp() throws {
        let g = try XCTUnwrap(RenderGeometry(displayWidth: 1920, displayHeight: 1080, outputAspect: 9.0 / 16.0))
        let engine = ReframeEngine(sourceAspect: 1920.0 / 1080.0, outputAspect: 9.0 / 16.0)
        let lo = g.cropX(centerX: engine.geometry.minCenterX)
        let hi = g.cropX(centerX: engine.geometry.maxCenterX)
        XCTAssertLessThan(lo, 2)                              // ≈ 0 (607,5 vs 608 px)
        XCTAssertGreaterThan(hi, 1920 - 608 - 2)
    }

    // MARK: CropTimeline

    func testTimelineInterpolatesLinearly() {
        let t = CropTimeline(points: [CropPoint(time: 0, centerX: 0.2), CropPoint(time: 1, centerX: 0.6)])
        XCTAssertEqual(t.centerX(at: 0), 0.2, accuracy: 1e-12)
        XCTAssertEqual(t.centerX(at: 0.5), 0.4, accuracy: 1e-12)
        XCTAssertEqual(t.centerX(at: 0.25), 0.3, accuracy: 1e-12)
        XCTAssertEqual(t.centerX(at: 1), 0.6, accuracy: 1e-12)
    }

    func testTimelineClampsOutsideRange() {
        let t = CropTimeline(points: [CropPoint(time: 1, centerX: 0.3), CropPoint(time: 2, centerX: 0.7)])
        XCTAssertEqual(t.centerX(at: -5), 0.3, accuracy: 1e-12)
        XCTAssertEqual(t.centerX(at: 0.99), 0.3, accuracy: 1e-12)
        XCTAssertEqual(t.centerX(at: 9), 0.7, accuracy: 1e-12)
    }

    func testTimelineEmptyAndInvalid() {
        let empty = CropTimeline(points: [])
        XCTAssertTrue(empty.isEmpty)
        XCTAssertEqual(empty.centerX(at: 1), 0.5)
        let t = CropTimeline(points: [CropPoint(time: 0, centerX: 0.4)])
        XCTAssertEqual(t.centerX(at: 3), 0.4)
        XCTAssertEqual(t.centerX(at: .nan), 0.5)
        // pontos com valores inválidos são descartados
        let bad = CropTimeline(points: [CropPoint(time: .nan, centerX: 0.1), CropPoint(time: 0, centerX: .nan),
                                        CropPoint(time: 0, centerX: 0.8)])
        XCTAssertEqual(bad.centerX(at: 0.2), 0.8)
    }

    func testTimelineHandlesUnsortedInputAndMatchesEngineAtSamples() {
        let engine = ReframeEngine(sourceAspect: 16.0 / 9.0, outputAspect: 9.0 / 16.0)
        let track = SubjectTrack(points: (0..<150).map {
            TrackingPoint(time: Double($0) / 30, boundingBox: CGRect(x: 0.2 + 0.004 * Double($0), y: 0.2, width: 0.08, height: 0.6), confidence: 0.9)
        })
        let crop = engine.trajectory(for: track, fps: 30, timeRange: 0...5)
        let timeline = CropTimeline(points: Array(crop.reversed()))
        for c in crop {
            XCTAssertEqual(timeline.centerX(at: c.time), Double(c.centerX), accuracy: 1e-12)
        }
        // Entre amostras, o valor fica entre os dois vizinhos.
        for i in 1..<crop.count {
            let mid = timeline.centerX(at: (crop[i - 1].time + crop[i].time) / 2)
            XCTAssertGreaterThanOrEqual(mid, min(Double(crop[i - 1].centerX), Double(crop[i].centerX)) - 1e-12)
            XCTAssertLessThanOrEqual(mid, max(Double(crop[i - 1].centerX), Double(crop[i].centerX)) + 1e-12)
        }
    }

    // MARK: Opções do comando render

    func testRenderOptionsMinimal() throws {
        let o = try RenderCommandOptions.parse(["render", "in.mov", "--tracking", "t.json", "--output", "out.mp4"])
        XCTAssertEqual(o.input, "in.mov"); XCTAssertEqual(o.tracking, "t.json"); XCTAssertEqual(o.output, "out.mp4")
        XCTAssertEqual(o.aspect, 9.0 / 16.0, accuracy: 1e-12)
        XCTAssertNil(o.outputHeight); XCTAssertNil(o.bitrate); XCTAssertNil(o.maxSeconds)
        XCTAssertFalse(o.useOneEuro)
    }

    func testRenderOptionsAll() throws {
        let o = try RenderCommandOptions.parse(["render", "-t", "t.json", "--aspect", "4:5", "--output-height", "720",
                                                "--bitrate", "4000000", "--max-seconds", "5", "--one-euro",
                                                "-o", "o.mp4", "clip.mov"])
        XCTAssertEqual(o.input, "clip.mov"); XCTAssertEqual(o.aspect, 0.8, accuracy: 1e-12)
        XCTAssertEqual(o.outputHeight, 720); XCTAssertEqual(o.bitrate, 4_000_000)
        XCTAssertEqual(o.maxSeconds, 5); XCTAssertTrue(o.useOneEuro)
    }

    func testPresetDefaultsToSuave() throws {
        let o = try RenderCommandOptions.parse(["render", "in.mov", "--tracking", "t.json", "--output", "o.mp4"])
        XCTAssertEqual(o.preset, .suave)
        let p = try RenderCommandOptions.parse(["render", "in.mov", "-t", "t.json", "-o", "o.mp4", "--preset", "RAPIDO"])
        XCTAssertEqual(p.preset, .rapido)
        XCTAssertThrowsError(try RenderCommandOptions.parse(["render", "in.mov", "-t", "t.json", "-o", "o.mp4", "--preset", "xyz"]))
    }

    func testPresetsMatchTheComparedVariants() {
        let base = ReframeSettings()
        XCTAssertEqual(RenderPreset.padrao.reframeSettings, base)
        XCTAssertFalse(RenderPreset.padrao.useOneEuro)
        XCTAssertTrue(RenderPreset.oneeuro.useOneEuro)
        XCTAssertEqual(RenderPreset.oneeuro.reframeSettings, base)
        let r = RenderPreset.rapido.reframeSettings
        XCTAssertEqual(r.smoothingTime, 0.25); XCTAssertEqual(r.lookAhead, 0.30); XCTAssertEqual(r.maxSpeed, 0.60)
        let s = RenderPreset.suave.reframeSettings
        XCTAssertEqual(s.smoothingTime, 0.80); XCTAssertEqual(s.deadZoneWidth, 0.40); XCTAssertEqual(s.maxSpeed, 0.25)
        XCTAssertEqual(s.lookAhead, base.lookAhead)
        XCTAssertEqual(s.horizontalMargin, base.horizontalMargin)
    }

    func testRecenterFlag() throws {
        let a = try RenderCommandOptions.parse(["render", "in.mov", "-t", "t.json", "-o", "o.mp4"])
        XCTAssertTrue(a.recenterWhenLost)
        let b = try RenderCommandOptions.parse(["render", "in.mov", "-t", "t.json", "-o", "o.mp4", "--no-recenter"])
        XCTAssertFalse(b.recenterWhenLost)
    }

    // MARK: Recentralização

    private func flat(_ c: Double, until: Double, fps: Double = 30) -> [CropPoint] {
        return (0...Int(until * fps)).map { CropPoint(time: Double($0) / fps, centerX: CGFloat(c)) }
    }
    private func states(lostFrom a: Double, to b: Double, until: Double, fps: Double = 30) -> [(time: Double, lost: Bool)] {
        return (0...Int(until * fps)).map { i in
            let t = Double(i) / fps
            return (time: t, lost: t >= a && t < b)
        }
    }
    private func value(_ pts: [CropPoint], at t: Double) -> Double {
        return Double(pts.min { abs($0.time - t) < abs($1.time - t) }!.centerX)
    }

    func testRecenterNeverLostLeavesTrajectoryUntouched() {
        let pts = flat(0.2, until: 5)
        let out = LostRecentering.apply(to: pts, states: states(lostFrom: 99, to: 100, until: 5))
        XCTAssertEqual(out, pts)
    }

    func testRecenterGoesToCenterAndBack() {
        let pts = flat(0.2, until: 14)
        let out = LostRecentering.apply(to: pts, states: states(lostFrom: 2, to: 8, until: 14))
        XCTAssertEqual(value(out, at: 1.9), 0.2, accuracy: 1e-9)       // antes da perda
        XCTAssertEqual(value(out, at: 2.75), 0.35, accuracy: 0.01)      // metade da rampa
        XCTAssertEqual(value(out, at: 3.6), 0.5, accuracy: 1e-9)        // chegou ao centro
        XCTAssertEqual(value(out, at: 7.9), 0.5, accuracy: 1e-9)        // fica lá enquanto perdido
        XCTAssertEqual(value(out, at: 8.75), 0.35, accuracy: 0.01)      // voltando
        XCTAssertEqual(value(out, at: 10.0), 0.2, accuracy: 1e-9)       // seguindo o engine de novo
    }

    func testRecenterIsSmoothAndStaysInsideTheRange() {
        let pts2 = flat(0.84, until: 15)
        let out = LostRecentering.apply(to: pts2, states: states(lostFrom: 3, to: 9, until: 15))
        var maxStep = 0.0
        for i in 1..<out.count { maxStep = max(maxStep, abs(Double(out[i].centerX - out[i - 1].centerX))) }
        // inclinação máxima do smoothstep = 1,5; distância 0,34; rampa 1,5 s; 30 fps
        XCTAssertLessThan(maxStep, 1.5 * 0.34 / 1.5 / 30 + 1e-9)
        for p in out { XCTAssertTrue(p.centerX >= 0.5 - 1e-9 && p.centerX <= 0.84 + 1e-9) }
    }

    func testRecenterEmptyInputs() {
        XCTAssertEqual(LostRecentering.apply(to: [], states: [(time: 0, lost: true)]), [])
        let pts = flat(0.3, until: 1)
        XCTAssertEqual(LostRecentering.apply(to: pts, states: []), pts)
    }

    func testParseAspect() {
        XCTAssertEqual(RenderCommandOptions.parseAspect("9:16") ?? 0, 0.5625, accuracy: 1e-12)
        XCTAssertEqual(RenderCommandOptions.parseAspect("1:1"), 1)
        XCTAssertEqual(RenderCommandOptions.parseAspect("16:9") ?? 0, 16.0 / 9.0, accuracy: 1e-12)
        XCTAssertEqual(RenderCommandOptions.parseAspect("0.5625") ?? 0, 0.5625, accuracy: 1e-12)
        XCTAssertNil(RenderCommandOptions.parseAspect("9:0"))
        XCTAssertNil(RenderCommandOptions.parseAspect("a:b"))
        XCTAssertNil(RenderCommandOptions.parseAspect("1:2:3"))
        XCTAssertNil(RenderCommandOptions.parseAspect("-1"))
    }

    func testRenderOptionsErrors() {
        func err(_ a: [String]) -> RenderCommandOptions.ParseError? {
            do { _ = try RenderCommandOptions.parse(a); return nil }
            catch let e as RenderCommandOptions.ParseError { return e }
            catch { return nil }
        }
        XCTAssertEqual(err([]), .missingCommand)
        XCTAssertEqual(err(["track", "a.mov"]), .unknownCommand("track"))
        XCTAssertEqual(err(["render", "-t", "t.json", "-o", "o.mp4"]), .missingInput)
        XCTAssertEqual(err(["render", "a.mov", "-o", "o.mp4"]), .missingTracking)
        XCTAssertEqual(err(["render", "a.mov", "-t", "t.json"]), .missingOutput)
        XCTAssertEqual(err(["render", "a.mov", "-t", "t.json", "-o", "o.mp4", "--aspect", "x"]), .invalidValue("--aspect", "x"))
        XCTAssertEqual(err(["render", "a.mov", "-t", "t.json", "-o", "o.mp4", "--bitrate", "5"]), .invalidValue("--bitrate", "5"))
        XCTAssertEqual(err(["render", "a.mov", "-t", "t.json", "-o", "o.mp4", "--bogus"]), .unknownOption("--bogus"))
        XCTAssertEqual(err(["render", "a.mov", "-t", "t.json", "-o"]), .missingValue("-o"))
    }
}
