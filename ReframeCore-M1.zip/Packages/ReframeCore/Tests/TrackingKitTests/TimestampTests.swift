import XCTest
import Foundation
@testable import TrackingKit

final class TimestampTests: XCTestCase {

    func testFirstTimestampBecomesZero() {
        var n = TimestampNormalizer()
        XCTAssertEqual(n.normalize(5.0), 0)
        XCTAssertEqual(try XCTUnwrap(n.normalize(5.0 + 1.0 / 30)), 1.0 / 30, accuracy: 1e-12)
    }

    func testNegativeOrZeroStartIsRebased() {
        var n = TimestampNormalizer()
        XCTAssertEqual(n.normalize(-0.5), 0)
        XCTAssertEqual(try XCTUnwrap(n.normalize(0.5)), 1.0, accuracy: 1e-12)
    }

    func testDuplicatesAndBackwardsAreDropped() {
        var n = TimestampNormalizer()
        XCTAssertEqual(n.normalize(10), 0)
        XCTAssertNil(n.normalize(10))          // repetido
        XCTAssertEqual(try XCTUnwrap(n.normalize(10.1)), 0.1, accuracy: 1e-12)
        XCTAssertNil(n.normalize(10.05))       // voltou no tempo
        XCTAssertEqual(try XCTUnwrap(n.normalize(10.2)), 0.2, accuracy: 1e-12) // segue normal
    }

    func testNonFiniteIsDropped() {
        var n = TimestampNormalizer()
        XCTAssertNil(n.normalize(.nan))
        XCTAssertNil(n.normalize(.infinity))
        XCTAssertEqual(n.normalize(3), 0)
    }

    func testOutputIsStrictlyIncreasing() {
        var n = TimestampNormalizer()
        var rng = DeterministicRNG(seed: 99)
        var last = -1.0
        for i in 0..<500 {
            let jitter = rng.next(-0.02, 0.02)
            if let t = n.normalize(100 + Double(i) / 30 + jitter) {
                XCTAssertGreaterThan(t, last)
                last = t
            }
        }
    }

    func testEstimatedFPS() {
        let times30 = (0..<100).map { Double($0) / 30 }
        XCTAssertEqual(try XCTUnwrap(TimestampNormalizer.estimatedFPS(times: times30)), 30, accuracy: 1e-6)
        // Um intervalo anômalo não muda a mediana.
        var withHole = times30
        withHole[50] += 0.01
        XCTAssertEqual(try XCTUnwrap(TimestampNormalizer.estimatedFPS(times: withHole)), 30, accuracy: 0.5)
        XCTAssertNil(TimestampNormalizer.estimatedFPS(times: [1.0]))
        XCTAssertNil(TimestampNormalizer.estimatedFPS(times: []))
    }

    // MARK: Agendador de redetecção

    func testRedetectionEveryHalfSecondAt30fps() {
        var s = RedetectionScheduler(interval: 0.5)
        var count = 0
        for i in 0..<90 {
            if s.shouldDetect(at: Double(i) / 30) { count += 1 }
        }
        XCTAssertEqual(count, 6) // t = 0, 0.5, 1.0, 1.5, 2.0, 2.5
    }

    func testRedetectionFirstCallAndForce() {
        var s = RedetectionScheduler(interval: 10)
        XCTAssertTrue(s.shouldDetect(at: 0))
        XCTAssertFalse(s.shouldDetect(at: 1))
        XCTAssertTrue(s.shouldDetect(at: 2, force: true))
        XCTAssertFalse(s.shouldDetect(at: 3))   // o force também reinicia a contagem
        XCTAssertTrue(s.shouldDetect(at: 12))
    }

    func testRedetectionIsConfigurableNotHardcoded() {
        var fast = RedetectionScheduler(interval: 0.1)
        var slow = RedetectionScheduler(interval: 2.0)
        var f = 0, sl = 0
        for i in 0..<300 {
            let t = Double(i) / 30
            if fast.shouldDetect(at: t) { f += 1 }
            if slow.shouldDetect(at: t) { sl += 1 }
        }
        XCTAssertGreaterThan(f, sl * 5)
    }

    func testInvalidIntervalFallsBack() {
        XCTAssertEqual(RedetectionScheduler(interval: 0).interval, 0.5)
        XCTAssertEqual(RedetectionScheduler(interval: -1).interval, 0.5)
        XCTAssertEqual(RedetectionScheduler(interval: .nan).interval, 0.5)
    }
}
