import XCTest
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import ReframeCore

final class SpringTests: XCTestCase {
    func testStepSizeInvariance() {
        let spring = CriticallyDampedSpring(smoothingTime: 0.45)
        var fine = CriticallyDampedSpring.State(position: 0, velocity: 0)
        for _ in 0..<10 { fine = spring.update(current: fine, target: 1, deltaTime: 0.01) }
        let coarse = spring.update(current: .init(position: 0, velocity: 0), target: 1, deltaTime: 0.10)
        XCTAssertEqual(fine.position, coarse.position, accuracy: 1e-9)
        XCTAssertEqual(fine.velocity, coarse.velocity, accuracy: 1e-9)
    }

    func testNeverOvershoots() {
        let spring = CriticallyDampedSpring(smoothingTime: 0.45)
        var state = CriticallyDampedSpring.State(position: 0, velocity: 0)
        for _ in 0..<600 {
            state = spring.update(current: state, target: 1, deltaTime: 1.0 / 60.0)
            XCTAssertLessThanOrEqual(state.position, 1.0 + 1e-12)
        }
        XCTAssertEqual(state.position, 1.0, accuracy: 1e-6)
    }

    func testClosedFormValueAtSmoothingTime() {
        let spring = CriticallyDampedSpring(smoothingTime: 0.45)
        let s = spring.update(current: .init(position: 0, velocity: 0), target: 1, deltaTime: 0.45)
        // ω·t = 2 → 1 − 3·e^(−2)
        XCTAssertEqual(s.position, 1 - 3 * exp(-2.0), accuracy: 1e-9)
    }

    func testZeroSmoothingIsImmediate() {
        let spring = CriticallyDampedSpring(smoothingTime: 0)
        let s = spring.update(current: .init(position: 0.2, velocity: 3), target: 0.9, deltaTime: 1.0 / 30.0)
        XCTAssertEqual(s.position, 0.9, accuracy: 1e-12)
        XCTAssertEqual(s.velocity, 0, accuracy: 1e-12)
    }

    func testZeroDeltaTimeKeepsState() {
        let spring = CriticallyDampedSpring(smoothingTime: 0.45)
        let start = CriticallyDampedSpring.State(position: 0.2, velocity: 0.1)
        XCTAssertEqual(spring.update(current: start, target: 1, deltaTime: 0), start)
    }
}
