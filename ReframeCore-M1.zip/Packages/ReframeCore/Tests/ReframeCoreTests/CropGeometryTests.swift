import XCTest
@testable import ReframeCore

final class CropGeometryTests: XCTestCase {
    func testCropWidth16x9To9x16() {
        let g = CropGeometry(sourceAspect: 16.0 / 9.0, outputAspect: 9.0 / 16.0)
        XCTAssertEqual(g.cropWidth, 81.0 / 256.0, accuracy: 1e-12)
        XCTAssertEqual(g.minCenterX, g.cropWidth / 2, accuracy: 1e-12)
        XCTAssertEqual(g.maxCenterX, 1 - g.cropWidth / 2, accuracy: 1e-12)
    }

    func testCropWidthOtherOutputs() {
        let source = 16.0 / 9.0
        XCTAssertEqual(CropGeometry(sourceAspect: source, outputAspect: 1.0).cropWidth, 0.5625, accuracy: 1e-12)
        XCTAssertEqual(CropGeometry(sourceAspect: source, outputAspect: 4.0 / 5.0).cropWidth, 0.45, accuracy: 1e-12)
    }

    func testIndependentOfResolution() {
        let uhd = CropGeometry(sourceAspect: 3840.0 / 2160.0, outputAspect: 9.0 / 16.0)
        let hd = CropGeometry(sourceAspect: 1920.0 / 1080.0, outputAspect: 9.0 / 16.0)
        XCTAssertEqual(uhd.cropWidth, hd.cropWidth, accuracy: 1e-12)
    }

    func testOutputWiderThanSourceIsCappedAtFullWidth() {
        let g = CropGeometry(sourceAspect: 16.0 / 9.0, outputAspect: 21.0 / 9.0)
        XCTAssertEqual(g.cropWidth, 1.0, accuracy: 1e-12)
        XCTAssertEqual(g.minCenterX, 0.5, accuracy: 1e-12)
        XCTAssertEqual(g.maxCenterX, 0.5, accuracy: 1e-12)
    }
}
