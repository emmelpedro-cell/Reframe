import XCTest
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import ReframeCore

/// Paridade Swift × espelho Python.
///
/// `GoldenData.swift` foi gerado por `Reference/make_golden.py` (mesma matemática,
/// mesmas entradas determinísticas). Estes testes reconstroem as MESMAS entradas
/// e exigem que o engine Swift reproduza as trajetórias com tolerância de 1e-9.
/// Se algum falhar, a mensagem traz cenário, índice, esperado, obtido e diferença.
final class GoldenParityTests: XCTestCase {
    private let tolerance = 1e-9

    // MARK: Entradas (idênticas às de make_golden.py)

    private func jumpPoints() -> [TrackingPoint] {
        var points: [TrackingPoint] = []
        for i in 0..<150 {
            let t = Double(i) / 30.0
            let cx = t < 3.0 ? 0.40 + 0.01 * Double(min(i, 2)) : 0.80
            points.append(Scenario.point(t, centerX: cx))
        }
        return points
    }

    private func lossPoints() -> [TrackingPoint] {
        var points: [TrackingPoint] = []
        for i in 0...60 { points.append(Scenario.point(Double(i) / 30.0, centerX: 0.50)) }
        for i in 180...240 { points.append(Scenario.point(Double(i) / 30.0, centerX: 0.70)) }
        return points
    }

    // MARK: Comparação

    private func assertMatches(
        _ name: String, points: [TrackingPoint], fps: Double, settings: ReframeSettings,
        count: Int, samples: [Double], file: StaticString = #filePath, line: UInt = #line
    ) {
        let trajectory = Scenario.engine(settings).trajectory(points: points, fps: fps)
        XCTAssertEqual(trajectory.count, count, "\(name): número de amostras", file: file, line: line)
        guard trajectory.count == count else { return }
        for (k, expected) in samples.enumerated() {
            let index = k * GoldenData.stride
            let got = Double(trajectory[index].centerX)
            let diff = abs(got - expected)
            if !(diff <= tolerance) {
                XCTFail("\(name)[\(index)] t=\(trajectory[index].time): esperado \(expected), obtido \(got), diferença \(diff)", file: file, line: line)
                return
            }
        }
    }

    private func check(
        _ name: String, _ points: [TrackingPoint], fps: Double = 30,
        settings: ReframeSettings = ReframeSettings(), count: Int, samples: [Double],
        file: StaticString = #filePath, line: UInt = #line
    ) {
        assertMatches(name, points: points, fps: fps, settings: settings, count: count, samples: samples, file: file, line: line)
    }

    // MARK: Cenários

    func testStationaryJitterMatchesPython() {
        check("stationaryJitter", Scenario.walk(from: 0.5, to: 0.5, start: 0, end: 1, duration: 4, fps: 30, jitter: 0.01),
              count: GoldenData.stationaryJitterCount, samples: GoldenData.stationaryJitter)
    }

    func testWalkMatchesPython() {
        check("walk", Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 9, duration: 10, fps: 30),
              count: GoldenData.walkCount, samples: GoldenData.walk)
    }

    func testJumpMatchesPython() {
        check("jump", jumpPoints(), count: GoldenData.jumpCount, samples: GoldenData.jump)
    }

    func testLossMatchesPython() {
        check("loss", lossPoints(), count: GoldenData.lossCount, samples: GoldenData.loss)
    }

    func testEdgesMatchPython() {
        check("edgeLeft", Scenario.walk(from: 0.05, to: 0.05, start: 0, end: 1, duration: 3, fps: 30),
              count: GoldenData.edgeLeftCount, samples: GoldenData.edgeLeft)
        check("edgeRight", Scenario.walk(from: 0.95, to: 0.95, start: 0, end: 1, duration: 3, fps: 30),
              count: GoldenData.edgeRightCount, samples: GoldenData.edgeRight)
    }

    func testSineAt30And60FpsMatchPython() {
        check("sine30", Scenario.sine(duration: 12, fps: 30), fps: 30,
              count: GoldenData.sine30Count, samples: GoldenData.sine30)
        check("sine60", Scenario.sine(duration: 12, fps: 60), fps: 60,
              count: GoldenData.sine60Count, samples: GoldenData.sine60)
    }

    func testLookAheadMatchesPython() {
        let walk = Scenario.walk(from: 0.35, to: 0.65, start: 2, end: 6, duration: 8, fps: 30)
        check("lookAheadZero", walk, settings: ReframeSettings(lookAhead: 0.0),
              count: GoldenData.lookAheadZeroCount, samples: GoldenData.lookAheadZero)
        check("lookAheadOn", walk, settings: ReframeSettings(lookAhead: 0.4),
              count: GoldenData.lookAheadOnCount, samples: GoldenData.lookAheadOn)
    }

    func testZeroSmoothingMatchesPython() {
        let settings = ReframeSettings(deadZoneWidth: 0, lookAhead: 0, smoothingTime: 0, maxSpeed: .infinity)
        check("zeroSmoothing", Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 3, duration: 5, fps: 30),
              settings: settings, count: GoldenData.zeroSmoothingCount, samples: GoldenData.zeroSmoothing)
    }

    func testLowMaxSpeedMatchesPython() {
        check("lowMaxSpeed", Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 2, duration: 5, fps: 30),
              settings: ReframeSettings(maxSpeed: 0.05), count: GoldenData.lowMaxSpeedCount, samples: GoldenData.lowMaxSpeed)
    }

    func testBoxWiderThanCropMatchesPython() {
        check("wideStill", Scenario.walk(from: 0.5, to: 0.5, start: 0, end: 1, duration: 3, fps: 30, boxWidth: 0.5, jitter: 0.02),
              count: GoldenData.wideStillCount, samples: GoldenData.wideStill)
        check("wideMoving", Scenario.walk(from: 0.4, to: 0.6, start: 1, end: 3, duration: 5, fps: 30, boxWidth: 0.5),
              count: GoldenData.wideMovingCount, samples: GoldenData.wideMoving)
    }

    // MARK: Métricas

    private func assertMetrics(_ name: String, _ m: ReframeMetrics, _ golden: [String: Double],
                               file: StaticString = #filePath, line: UInt = #line) {
        let actual: [String: Double] = [
            "meanSubjectError": m.meanSubjectError,
            "meanSubjectErrorInCropWidths": m.meanSubjectErrorInCropWidths,
            "insideCropRatio": m.insideCropRatio,
            "maxSpeed": m.maxSpeed,
            "maxAcceleration": m.maxAcceleration,
            "jerkRMS": m.jerkRMS,
            "directionChanges": Double(m.directionChanges),
            "apparentLag": m.apparentLag,
        ]
        for (key, expected) in golden {
            let got = actual[key] ?? .nan
            let diff = abs(got - expected)
            if !(diff <= 1e-6) {
                XCTFail("\(name).\(key): esperado \(expected), obtido \(got), diferença \(diff)", file: file, line: line)
            }
        }
    }

    func testMetricsMatchPython() {
        let walk = Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 9, duration: 10, fps: 30)
        let walkTrajectory = Scenario.engine().trajectory(points: walk, fps: 30)
        assertMetrics("walk", ReframeMetrics.evaluate(crop: walkTrajectory, subject: walk, geometry: Scenario.geometry), GoldenData.walkMetrics)

        let sine = Scenario.sine(duration: 12, fps: 30)
        let sineTrajectory = Scenario.engine().trajectory(points: sine, fps: 30)
        assertMetrics("sine30", ReframeMetrics.evaluate(crop: sineTrajectory, subject: sine, geometry: Scenario.geometry), GoldenData.sine30Metrics)
    }
}
