import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
import XCTest
@testable import ReframeCore

/// Gerador pseudoaleatório determinístico (SplitMix64) para testes reproduzíveis.
struct DeterministicRandom {
    private var state: UInt64
    init(seed: UInt64) { state = seed }

    mutating func next() -> Double {
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        z = z ^ (z >> 31)
        return Double(z >> 11) / 9007199254740992.0
    }

    mutating func next(in range: ClosedRange<Double>) -> Double {
        return range.lowerBound + (range.upperBound - range.lowerBound) * next()
    }
}

enum Scenario {
    static let sourceAspect = 16.0 / 9.0
    static let outputAspect = 9.0 / 16.0
    static let geometry = CropGeometry(sourceAspect: sourceAspect, outputAspect: outputAspect)

    static func engine(_ settings: ReframeSettings = ReframeSettings()) -> ReframeEngine {
        return ReframeEngine(geometry: geometry, settings: settings)
    }

    static func point(_ time: Double, centerX: Double, width: Double = 0.10, confidence: Float = 1) -> TrackingPoint {
        let box = CGRect(x: centerX - width / 2, y: 0.15, width: width, height: 0.70)
        return TrackingPoint(time: time, boundingBox: box, confidence: confidence)
    }

    /// Sujeito parado em `from`, anda linearmente até `to` entre `start` e `end`, depois para.
    static func walk(
        from x0: Double, to x1: Double, start: Double, end: Double,
        duration: Double, fps: Double, boxWidth: Double = 0.10,
        jitter: Double = 0, seed: UInt64 = 1
    ) -> [TrackingPoint] {
        var random = DeterministicRandom(seed: seed)
        let count = Int((duration * fps).rounded())
        var points: [TrackingPoint] = []
        for i in 0...count {
            let t = Double(i) / fps
            var alpha = 0.0
            if t >= end { alpha = 1.0 } else if t > start { alpha = (t - start) / (end - start) }
            var cx = x0 + (x1 - x0) * alpha
            if jitter > 0 { cx += random.next(in: -jitter...jitter) }
            points.append(point(t, centerX: cx, width: boxWidth))
        }
        return points
    }

    static func sine(duration: Double, fps: Double) -> [TrackingPoint] {
        let count = Int((duration * fps).rounded())
        return (0...count).map { i in
            let t = Double(i) / fps
            return point(t, centerX: 0.5 + 0.28 * sin(2 * Double.pi * t / 8.0))
        }
    }

    static func xs(_ trajectory: [CropPoint]) -> [Double] {
        return trajectory.map { Double($0.centerX) }
    }

    static func maxSpeed(_ trajectory: [CropPoint]) -> Double {
        var result = 0.0
        for i in 0..<(trajectory.count - 1) {
            let dt = trajectory[i + 1].time - trajectory[i].time
            let speed = abs(Double(trajectory[i + 1].centerX - trajectory[i].centerX)) / dt
            result = max(result, speed)
        }
        return result
    }

    static func assertValid(_ trajectory: [CropPoint], file: StaticString = #filePath, line: UInt = #line) {
        for p in trajectory {
            let x = Double(p.centerX)
            XCTAssertTrue(x.isFinite, "centerX não finito", file: file, line: line)
            XCTAssertGreaterThanOrEqual(x, geometry.minCenterX - 1e-12, file: file, line: line)
            XCTAssertLessThanOrEqual(x, geometry.maxCenterX + 1e-12, file: file, line: line)
        }
    }
}
