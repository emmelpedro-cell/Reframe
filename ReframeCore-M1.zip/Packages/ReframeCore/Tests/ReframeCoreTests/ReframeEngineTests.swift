import XCTest
@testable import ReframeCore

final class ReframeEngineTests: XCTestCase {
    private let fps = 30.0

    // MARK: Os cinco cenários originais

    /// Teste 1 — pessoa parada, com jitter de detecção de ±0,01.
    func testStationarySubjectProducesNoMicroMovements() {
        let points = Scenario.walk(from: 0.5, to: 0.5, start: 0, end: 1, duration: 4, fps: fps, jitter: 0.01)
        let xs = Scenario.xs(Scenario.engine().trajectory(points: points, fps: fps))
        XCTAssertLessThan((xs.max() ?? 0) - (xs.min() ?? 0), 1e-12)
        XCTAssertEqual(xs[0], 0.5, accuracy: 0.02)
    }

    /// Teste 2 — pessoa andando para a direita: o crop segue sem voltar atrás.
    func testWalkingSubjectIsFollowedSmoothly() {
        let points = Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 9, duration: 10, fps: fps)
        let trajectory = Scenario.engine().trajectory(points: points, fps: fps)
        let xs = Scenario.xs(trajectory)
        XCTAssertEqual(xs[0], 0.30, accuracy: 1e-9)
        XCTAssertGreaterThan(xs.last ?? 0, 0.65)
        for i in 0..<(xs.count - 1) { XCTAssertGreaterThanOrEqual(xs[i + 1], xs[i] - 1e-12) }
        let m = ReframeMetrics.evaluate(crop: trajectory, subject: points, geometry: Scenario.geometry)
        XCTAssertGreaterThanOrEqual(m.insideCropRatio, 0.99)
        XCTAssertLessThan(m.meanSubjectErrorInCropWidths, 0.03)
        XCTAssertEqual(m.directionChanges, 0)
    }

    /// Teste 3 — salto brusco 0,42 → 0,80: o crop não salta.
    func testSuddenJumpDoesNotTeleportTheCrop() {
        var points: [TrackingPoint] = []
        for i in 0..<150 {
            let t = Double(i) / fps
            let cx = t < 3.0 ? 0.40 + 0.01 * Double(min(i, 2)) : 0.80
            points.append(Scenario.point(t, centerX: cx))
        }
        let settings = ReframeSettings()
        let trajectory = Scenario.engine(settings).trajectory(points: points, fps: fps)
        XCTAssertLessThanOrEqual(Scenario.maxSpeed(trajectory), settings.maxSpeed + 1e-9)
        let atJump = trajectory.first { abs($0.time - 3.0) < 1e-6 }
        XCTAssertLessThan(Double(atJump?.centerX ?? 1), 0.60)
        XCTAssertGreaterThan(Double(trajectory.last?.centerX ?? 0), 0.75)
        Scenario.assertValid(trajectory)
    }

    /// Teste 4 — fuzz: o crop nunca sai do frame, qualquer que seja a entrada.
    func testCropNeverLeavesFrameWithRandomInput() {
        var random = DeterministicRandom(seed: 42)
        for _ in 0..<200 {
            var points: [TrackingPoint] = []
            for i in 0..<150 {
                let cx = random.next(in: -0.2...1.2)
                let width = random.next(in: 0.01...0.9)
                let conf = Float(random.next(in: 0...1))
                points.append(Scenario.point(Double(i) / fps, centerX: cx, width: width, confidence: conf))
            }
            Scenario.assertValid(Scenario.engine().trajectory(points: points, fps: fps))
        }
    }

    /// Teste 5 — tracking perdido: o crop fica estável e depois recupera o sujeito.
    func testLostTrackingHoldsThenRecovers() {
        var points: [TrackingPoint] = []
        for i in 0...60 { points.append(Scenario.point(Double(i) / fps, centerX: 0.50)) }
        for i in 180...240 { points.append(Scenario.point(Double(i) / fps, centerX: 0.70)) }
        let trajectory = Scenario.engine().trajectory(points: points, fps: fps)
        let held = trajectory.filter { $0.time >= 2.0 && $0.time <= 5.5 }.map { Double($0.centerX) }
        XCTAssertLessThan((held.max() ?? 0) - (held.min() ?? 0), 1e-12)
        XCTAssertEqual(Double(trajectory.last?.centerX ?? 0), 0.70, accuracy: 0.02)
        Scenario.assertValid(trajectory)
    }

    func testLowConfidencePointsCountAsLost() {
        var points: [TrackingPoint] = []
        for i in 0...60 { points.append(Scenario.point(Double(i) / fps, centerX: 0.50)) }
        for i in 61...180 { points.append(Scenario.point(Double(i) / fps, centerX: 0.75, confidence: 0.05)) }
        let xs = Scenario.xs(Scenario.engine().trajectory(points: points, fps: fps, timeRange: 0...6.0))
        XCTAssertLessThan((xs.max() ?? 0) - (xs.min() ?? 0), 1e-12)
    }

    // MARK: Casos extras

    /// A/B — sujeito colado nas bordas: crop fica encostado e válido.
    func testSubjectAtFarLeftAndFarRight() {
        let left = Scenario.walk(from: 0.05, to: 0.05, start: 0, end: 1, duration: 3, fps: fps)
        let leftTrajectory = Scenario.engine().trajectory(points: left, fps: fps)
        Scenario.assertValid(leftTrajectory)
        XCTAssertEqual(Double(leftTrajectory.last?.centerX ?? 1), Scenario.geometry.minCenterX, accuracy: 1e-9)
        XCTAssertEqual(ReframeMetrics.evaluate(crop: leftTrajectory, subject: left, geometry: Scenario.geometry).insideCropRatio, 1.0, accuracy: 1e-12)

        let right = Scenario.walk(from: 0.95, to: 0.95, start: 0, end: 1, duration: 3, fps: fps)
        let rightTrajectory = Scenario.engine().trajectory(points: right, fps: fps)
        Scenario.assertValid(rightTrajectory)
        XCTAssertEqual(Double(rightTrajectory.last?.centerX ?? 0), Scenario.geometry.maxCenterX, accuracy: 1e-9)
    }

    /// C — mesma trajetória temporal a 30 e 60 fps dá resultados equivalentes.
    func testThirtyAndSixtyFpsAreEquivalent() {
        let t30 = Scenario.engine().trajectory(points: Scenario.sine(duration: 12, fps: 30), fps: 30)
        let t60 = Scenario.engine().trajectory(points: Scenario.sine(duration: 12, fps: 60), fps: 60)
        var maxDifference = 0.0
        for i in 0..<t30.count {
            maxDifference = max(maxDifference, abs(Double(t30[i].centerX) - Double(t60[2 * i].centerX)))
        }
        XCTAssertLessThan(maxDifference, 0.004)
    }

    /// D — lookAhead = 0 não antecipa nem depende do futuro; lookAhead > 0 antecipa.
    func testLookAheadZeroHasNoAnticipation() {
        let points = Scenario.walk(from: 0.35, to: 0.65, start: 2, end: 6, duration: 8, fps: fps)
        func firstMove(_ lookAhead: Double) -> Double {
            let t = Scenario.engine(ReframeSettings(lookAhead: lookAhead)).trajectory(points: points, fps: fps)
            let start = Double(t[0].centerX)
            return t.first { abs(Double($0.centerX) - start) > 0.002 }?.time ?? .infinity
        }
        XCTAssertLessThanOrEqual(firstMove(0.4), firstMove(0.0) - 0.2)

        // Causalidade: mudar o futuro (t ≥ 4) não altera o passado quando lookAhead = 0.
        let changed = points.map { p -> TrackingPoint in
            guard p.time >= 4.0 else { return p }
            return TrackingPoint(time: p.time, boundingBox: p.boundingBox.offsetBy(dx: 0.2, dy: 0), confidence: p.confidence)
        }
        func maxPastDifference(_ lookAhead: Double) -> Double {
            let engine = Scenario.engine(ReframeSettings(lookAhead: lookAhead))
            let a = engine.trajectory(points: points, fps: fps)
            let b = engine.trajectory(points: changed, fps: fps)
            var result = 0.0
            for i in 0..<a.count where a[i].time < 3.9 {
                result = max(result, abs(Double(a[i].centerX) - Double(b[i].centerX)))
            }
            return result
        }
        XCTAssertEqual(maxPastDifference(0.0), 0, accuracy: 1e-12)
        XCTAssertGreaterThan(maxPastDifference(0.4), 0.01)
    }

    /// E — smoothingTime = 0, sem dead zone nem limite: o crop segue o alvo na hora.
    func testZeroSmoothingTracksTargetImmediately() {
        let settings = ReframeSettings(deadZoneWidth: 0, lookAhead: 0, smoothingTime: 0, maxSpeed: .infinity)
        let points = Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 3, duration: 5, fps: fps)
        let trajectory = Scenario.engine(settings).trajectory(points: points, fps: fps)
        for (i, p) in trajectory.enumerated() {
            let center = Double(points[i].boundingBox.midX)
            XCTAssertEqual(Double(p.centerX), Scenario.geometry.clampCenter(center), accuracy: 1e-9)
        }
    }

    /// F — maxSpeed muito baixo é respeitado mesmo com sujeito rápido.
    func testLowMaxSpeedIsRespected() {
        let settings = ReframeSettings(maxSpeed: 0.05)
        let points = Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 2, duration: 5, fps: fps)
        let trajectory = Scenario.engine(settings).trajectory(points: points, fps: fps)
        XCTAssertLessThanOrEqual(Scenario.maxSpeed(trajectory), 0.05 + 1e-9)
        Scenario.assertValid(trajectory)
    }

    /// G — box maior que o crop: composição estável (sem tremer) e sempre válida.
    func testBoxWiderThanCropStaysStableAndValid() {
        let still = Scenario.walk(from: 0.5, to: 0.5, start: 0, end: 1, duration: 3, fps: fps, boxWidth: 0.5, jitter: 0.02)
        let stillXs = Scenario.xs(Scenario.engine().trajectory(points: still, fps: fps))
        XCTAssertLessThan((stillXs.max() ?? 0) - (stillXs.min() ?? 0), 1e-12)

        let moving = Scenario.walk(from: 0.4, to: 0.6, start: 1, end: 3, duration: 5, fps: fps, boxWidth: 0.5)
        let trajectory = Scenario.engine().trajectory(points: moving, fps: fps)
        Scenario.assertValid(trajectory)
        XCTAssertGreaterThan(Double(trajectory.last?.centerX ?? 0), 0.55)
    }

    // MARK: Margem, aspect e bordas da API

    func testMarginKeepsSubjectBoxInsideCropOnceSettled() {
        let points = Scenario.walk(from: 0.30, to: 0.60, start: 1, end: 3, duration: 8, fps: fps, boxWidth: 0.20)
        let engine = Scenario.engine()
        let trajectory = engine.trajectory(points: points, fps: fps)
        let rules = CompositionRules(geometry: Scenario.geometry, settings: engine.settings)
        let last = points.last!
        let c = rules.composition(minX: Double(last.boundingBox.minX), maxX: Double(last.boundingBox.maxX))
        let x = Double(trajectory.last!.centerX)
        XCTAssertGreaterThanOrEqual(x, c.lowerBound - 1e-9)
        XCTAssertLessThanOrEqual(x, c.upperBound + 1e-9)
    }

    func testEngineWorksForOtherOutputAspects() {
        let points = Scenario.walk(from: 0.2, to: 0.8, start: 1, end: 5, duration: 6, fps: fps)
        for outputAspect in [9.0 / 16.0, 4.0 / 5.0, 1.0] {
            let engine = ReframeEngine(sourceAspect: 16.0 / 9.0, outputAspect: outputAspect)
            let trajectory = engine.trajectory(points: points, fps: fps)
            let g = engine.geometry
            for p in trajectory {
                XCTAssertGreaterThanOrEqual(Double(p.centerX), g.minCenterX - 1e-12)
                XCTAssertLessThanOrEqual(Double(p.centerX), g.maxCenterX + 1e-12)
            }
        }
    }

    func testEmptyInputAndTimeRange() {
        let engine = Scenario.engine()
        XCTAssertTrue(engine.trajectory(points: [], fps: fps).isEmpty)
        let centered = engine.trajectory(points: [], fps: fps, timeRange: 0...1)
        XCTAssertEqual(centered.count, 31)
        XCTAssertEqual(Double(centered[0].centerX), 0.5, accuracy: 1e-12)
        XCTAssertTrue(engine.trajectory(points: [], fps: 0, timeRange: 0...1).isEmpty)
    }

    func testDeterministicOutput() {
        let points = Scenario.walk(from: 0.3, to: 0.7, start: 1, end: 4, duration: 6, fps: fps, jitter: 0.01, seed: 7)
        let a = Scenario.engine().trajectory(points: points, fps: fps)
        let b = Scenario.engine().trajectory(points: points, fps: fps)
        XCTAssertEqual(a, b)
    }
}
