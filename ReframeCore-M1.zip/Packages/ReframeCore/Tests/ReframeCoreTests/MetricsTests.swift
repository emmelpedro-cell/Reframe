import XCTest
@testable import ReframeCore

final class MetricsTests: XCTestCase {
    private let fps = 30.0

    private func staticSubject(_ x: Double, count: Int) -> [TrackingPoint] {
        return (0..<count).map { Scenario.point(Double($0) / fps, centerX: x) }
    }

    func testPerfectlyCenteredStationaryCrop() {
        let crop = (0..<60).map { CropPoint(time: Double($0) / fps, centerX: 0.5) }
        let m = ReframeMetrics.evaluate(crop: crop, subject: staticSubject(0.5, count: 60), geometry: Scenario.geometry)
        XCTAssertEqual(m.meanSubjectError, 0, accuracy: 1e-12)
        XCTAssertEqual(m.insideCropRatio, 1, accuracy: 1e-12)
        XCTAssertEqual(m.maxSpeed, 0, accuracy: 1e-12)
        XCTAssertEqual(m.jerkRMS, 0, accuracy: 1e-12)
        XCTAssertEqual(m.directionChanges, 0)
        XCTAssertEqual(m.apparentLag, 0, accuracy: 1e-12)
    }

    func testConstantVelocityRamp() {
        let crop = (0..<61).map { CropPoint(time: Double($0) / fps, centerX: CGFloat(0.3 + 0.1 * Double($0) / fps)) }
        let m = ReframeMetrics.evaluate(crop: crop, subject: staticSubject(0.4, count: 61), geometry: Scenario.geometry)
        XCTAssertEqual(m.maxSpeed, 0.1, accuracy: 1e-9)
        XCTAssertEqual(m.maxAcceleration, 0, accuracy: 1e-6)
        XCTAssertEqual(m.jerkRMS, 0, accuracy: 1e-4)
        XCTAssertEqual(m.directionChanges, 0)
    }

    func testDirectionChangesAreCounted() {
        let xs: [CGFloat] = [0.40, 0.45, 0.40, 0.45, 0.40]
        let crop = xs.enumerated().map { CropPoint(time: Double($0.offset) / fps, centerX: $0.element) }
        let m = ReframeMetrics.evaluate(crop: crop, subject: staticSubject(0.42, count: 5), geometry: Scenario.geometry)
        XCTAssertEqual(m.directionChanges, 3)
    }

    func testSubjectOutsideCropLowersInsideRatio() {
        let crop = (0..<30).map { CropPoint(time: Double($0) / fps, centerX: 0.30) }
        let m = ReframeMetrics.evaluate(crop: crop, subject: staticSubject(0.80, count: 30), geometry: Scenario.geometry)
        XCTAssertEqual(m.insideCropRatio, 0, accuracy: 1e-12)
        XCTAssertGreaterThan(m.meanSubjectError, 0.4)
    }

    func testLookAheadReducesApparentLag() {
        let points = Scenario.walk(from: 0.30, to: 0.70, start: 2, end: 6, duration: 8, fps: fps)
        func lag(_ lookAhead: Double) -> Double {
            let trajectory = Scenario.engine(ReframeSettings(lookAhead: lookAhead)).trajectory(points: points, fps: fps)
            return ReframeMetrics.evaluate(crop: trajectory, subject: points, geometry: Scenario.geometry).apparentLag
        }
        XCTAssertLessThan(lag(0.4), lag(0.0))
    }

    func testTooFewSamplesReturnsZero() {
        let m = ReframeMetrics.evaluate(crop: [CropPoint(time: 0, centerX: 0.5)], subject: staticSubject(0.5, count: 1), geometry: Scenario.geometry)
        XCTAssertEqual(m, .zero)
    }
}
