# ReframeCore (M0 + M1)

Motor de Auto Reframe: transforma a trajetória do sujeito (`TrackingPoint`) na trajetória
da câmera vertical virtual (`CropPoint`). Sem AVFoundation, Vision ou SwiftUI.

## Convenções
- Coordenadas **normalizadas** do source: x, y ∈ 0...1, **origem no topo-esquerdo, +X direita, +Y baixo**.
- Conversão para/do Vision (y invertido) e `preferredTransform` fica no TrackingKit/RenderKit.
- Aspect = largura / altura. `cropWidth = outputAspect / sourceAspect` (limitado a 1).
- O engine não conhece resolução (4K, 1080p...), só proporções.

## Pipeline
TrackingPoint → expandir box → alvo → look-ahead → dead zone → spring → max speed → clamp físico → CropPoint

## Rodar os testes (Mac, Xcode 15+ / Swift 5.9+)
    cd ReframeCore
    swift test

`Reference/reframe_ref.py` é um espelho em Python da mesma matemática, usado para validar
cenários e limiares antes de existir um toolchain Swift.

## Validação do M1
`GoldenParityTests` compara o engine Swift com trajetórias geradas pelo espelho Python
(`Reference/make_golden.py` → `Tests/.../GoldenData.swift`), tolerância 1e-9, mais as métricas (1e-6).
Para regenerar: `python3 Reference/make_golden.py Tests/ReframeCoreTests/GoldenData.swift`.

Para enviar o resultado:

    swift test 2>&1 | tee swift-test.log

---

# M2 — TrackingKit (tracking real)

`Sources/TrackingKit` transforma vídeo real em `SubjectTrack` para o `ReframeEngine`.
O **ReframeCore não foi alterado** (nem seus testes): o TrackingKit só o consome
(`TrackingPoint`, `SubjectTrack`).

    Master.mov → decode reduzido (~960 px) → Vision (detecção periódica)
      → VNTrackObjectRequest entre detecções → reassociação → SubjectTracker
      → TrackingReport (JSON) / SubjectTrack

## Onde fica cada coisa
- `Geometry/VisionCoordinates` — ÚNICO lugar que sabe do Vision (origem embaixo → origem no topo).
- `Geometry/DisplayMapping` — `preferredTransform` (cru ⇄ orientação visual). iPhone em retrato é
  fisicamente landscape com rotação de 90°; o Vision vê os pixels crus, o ReframeCore espera a tela.
- `Selection/SubjectSelector` — score por área, proximidade do centro e persistência.
- `Selection/SubjectTracker` — máquina de estados (`acquiring/tracking/held/lost`), sujeito "pegajoso",
  manutenção do último box na perda, recuperação, troca de alvo. **Nada disso está no ReframeEngine.**
- `TrackingSettings` — todos os parâmetros (redetecção 0,5 s, largura de análise 960, janelas de perda...).
- `Vision/*` — só compila onde há Vision/AVFoundation (macOS/iOS). No Linux o resto roda normalmente.

## CLI
    swift run reframe track input.mov --output tracking.json --debug-video debug.mp4 --crop

O vídeo de debug mostra a caixa, a confiança, o estado, o ID do sujeito e (com `--crop`) a janela 9:16.

## Testes
- `CoordinateTests`, `TimestampTests`, `SubjectSelectorTests`, `SubjectTrackerTests`,
  `TrackingReportTests`, `CommandLineOptionsTests`: determinísticos (macOS e Linux).
- `VisionIntegrationTests` (só macOS): vídeos em `Tests/TrackingKitTests/Fixtures`
  (bloco magenta se movendo; um deles com rotação de 90° nos metadados).
  Usam o `VNTrackObjectRequest` real e um detector de cor no lugar do detector de pessoas.

## Ainda NÃO existe (próximas etapas)
Render vertical, export final, câmera ao vivo, múltiplas pessoas avançadas, instrumentos, Core ML.
