# ReframeCore (M0 + M1)

Motor de Auto Reframe: transforma a trajetória do sujeito (`TrackingPoint`) na trajetória
da câmera vertical virtual (`CropPoint`). Sem AVFoundation, Vision ou SwiftUI.

## Convenções
- Coordenadas **normalizadas** do source: x, y ∈ 0...1, **origem no topo-esquerdo, +X direita, +Y baixo**.
- Conversão para/do Vision (y invertido) e `preferredTransform` fica no TrackingKit/RenderKit.
- Aspect = largura / altura. `cropWidth = outputAspect / sourceAspect` (limitado a 1).
- O engine não conhece resolução (4K, 1080p...), só proporções.

## Pipeline
TrackingPoint → expandir box → alvo → look-ahead → dead zone → spring → max speed → clamp físico → CropPoint

## Rodar os testes (Mac, Xcode 15+ / Swift 5.9+)
    cd ReframeCore
    swift test

`Reference/reframe_ref.py` é um espelho em Python da mesma matemática, usado para validar
cenários e limiares antes de existir um toolchain Swift.

## Validação do M1
`GoldenParityTests` compara o engine Swift com trajetórias geradas pelo espelho Python
(`Reference/make_golden.py` → `Tests/.../GoldenData.swift`), tolerância 1e-9, mais as métricas (1e-6).
Para regenerar: `python3 Reference/make_golden.py Tests/ReframeCoreTests/GoldenData.swift`.

Para enviar o resultado:

    swift test 2>&1 | tee swift-test.log
