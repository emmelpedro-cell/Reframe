"""Gera Tests/ReframeCoreTests/GoldenData.swift a partir do espelho Python.
As entradas são idênticas às do Swift (SplitMix64 determinístico, mesma fórmula de caixas)."""
import math, sys
from reframe_ref import Settings, trajectory, metrics, crop_width

M64 = (1 << 64) - 1
class SplitMix64:
    def __init__(s, seed): s.state = seed & M64
    def next(s):
        s.state = (s.state + 0x9E3779B97F4A7C15) & M64
        z = s.state
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        z = z ^ (z >> 31)
        return (z >> 11) / 9007199254740992.0
    def nxt_in(s, lo, hi): return lo + (hi - lo) * s.next()

# vetor de referência público do SplitMix64 (seed 0 → 0xE220A8397B1DCDAF)
_chk = SplitMix64(0); _chk.state = 0
_s = (_chk.state + 0x9E3779B97F4A7C15) & M64; _z = _s
_z = ((_z ^ (_z >> 30)) * 0xBF58476D1CE4E5B9) & M64; _z = ((_z ^ (_z >> 27)) * 0x94D049BB133111EB) & M64; _z ^= _z >> 31
assert _z == 0xE220A8397B1DCDAF, hex(_z)

SA, OA = 16/9, 9/16
CW = crop_width(SA, OA)

def pt(t, cx, w=0.10, conf=1.0):
    minx = cx - w / 2           # igual ao CGRect(x: cx - w/2, width: w)
    return (t, minx, minx + w, conf)

def walk(x0, x1, start, end, duration, fps, bw=0.10, jitter=0.0, seed=1):
    rng = SplitMix64(seed); out = []
    for i in range(int(round(duration * fps)) + 1):
        t = i / fps
        a = 0.0
        if t >= end: a = 1.0
        elif t > start: a = (t - start) / (end - start)
        cx = x0 + (x1 - x0) * a
        if jitter > 0: cx += rng.nxt_in(-jitter, jitter)
        out.append(pt(t, cx, bw))
    return out

def sine(duration, fps):
    return [pt(i / fps, 0.5 + 0.28 * math.sin(2 * math.pi * (i / fps) / 8.0)) for i in range(int(round(duration * fps)) + 1)]

def jump():
    out = []
    for i in range(150):
        t = i / 30
        cx = 0.40 + 0.01 * min(i, 2) if t < 3.0 else 0.80
        out.append(pt(t, cx))
    return out

def loss():
    return [pt(i / 30, 0.50) for i in range(0, 61)] + [pt(i / 30, 0.70) for i in range(180, 241)]

D = Settings()
scenarios = [
 ("stationaryJitter", walk(0.5, 0.5, 0, 1, 4, 30, jitter=0.01), 30, D),
 ("walk",             walk(0.30, 0.70, 1, 9, 10, 30), 30, D),
 ("jump",             jump(), 30, D),
 ("loss",             loss(), 30, D),
 ("edgeLeft",         walk(0.05, 0.05, 0, 1, 3, 30), 30, D),
 ("edgeRight",        walk(0.95, 0.95, 0, 1, 3, 30), 30, D),
 ("sine30",           sine(12, 30), 30, D),
 ("sine60",           sine(12, 60), 60, D),
 ("lookAheadZero",    walk(0.35, 0.65, 2, 6, 8, 30), 30, Settings(lookAhead=0.0)),
 ("lookAheadOn",      walk(0.35, 0.65, 2, 6, 8, 30), 30, Settings(lookAhead=0.4)),
 ("zeroSmoothing",    walk(0.30, 0.70, 1, 3, 5, 30), 30, Settings(deadZoneWidth=0, lookAhead=0, smoothingTime=0, maxSpeed=math.inf)),
 ("lowMaxSpeed",      walk(0.30, 0.70, 1, 2, 5, 30), 30, Settings(maxSpeed=0.05)),
 ("wideStill",        walk(0.5, 0.5, 0, 1, 3, 30, bw=0.5, jitter=0.02), 30, D),
 ("wideMoving",       walk(0.4, 0.6, 1, 3, 5, 30, bw=0.5), 30, D),
]
STRIDE = 5
lines = ["// GERADO por Reference/make_golden.py a partir do espelho Python. Não editar à mão.",
         "// Amostras de centerX a cada STRIDE pontos de saída. Entradas: ver GoldenParityTests.swift.",
         "enum GoldenData {", f"    static let stride = {STRIDE}"]
metr = {}
for name, pts, fps, st in scenarios:
    tr = trajectory(pts, SA, OA, fps, st)
    samples = [tr[i][1] for i in range(0, len(tr), STRIDE)]
    lines.append(f"    static let {name}Count = {len(tr)}")
    lines.append(f"    static let {name}: [Double] = [")
    for k in range(0, len(samples), 4):
        lines.append("        " + ", ".join(repr(float(v)) for v in samples[k:k+4]) + ",")
    lines.append("    ]")
    if name in ("walk", "sine30"):
        metr[name] = metrics(tr, pts, CW, st)
for name, m in metr.items():
    lines.append(f"    static let {name}Metrics: [String: Double] = [")
    keymap = [("meanSubjectError","meanErr"),("meanSubjectErrorInCropWidths","meanErrCropW"),("insideCropRatio","inside"),
              ("maxSpeed","maxSpeed"),("maxAcceleration","maxAccel"),("jerkRMS","jerkRMS"),("directionChanges","dirChanges"),("apparentLag","lag")]
    for sk, pk in keymap:
        lines.append(f'        "{sk}": {repr(float(m[pk]))},')
    lines.append("    ]")
lines.append("}")
src = "\n".join(lines)
open(sys.argv[1], "w").write(src + "\n")
print("ok", len(src), "bytes;", {n: len(trajectory(p, SA, OA, f, s)) for n, p, f, s in scenarios})
print({k: {a: round(b, 6) for a, b in v.items()} for k, v in metr.items()})
