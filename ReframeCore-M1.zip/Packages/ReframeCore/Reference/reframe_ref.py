"""Espelho em Python do ReframeCore (mesma matemática do Swift) para validar numericamente."""
import math, random

class Settings:
    def __init__(s, **kw):
        s.horizontalMargin = 0.10   # fração da largura do crop, cada lado
        s.deadZoneWidth = 0.30      # fração da largura do crop
        s.lookAhead = 0.40
        s.smoothingTime = 0.45
        s.maxSpeed = 0.35
        s.minConfidence = 0.30
        s.maxInterpolationGap = 0.50
        s.releaseFraction = 0.35
        s.releaseSpeed = 0.02
        for k, v in kw.items():
            setattr(s, k, v)

def crop_width(src_aspect, out_aspect):
    return min(1.0, out_aspect / src_aspect)

def spring_step(x, v, target, dt, smoothing):
    if smoothing <= 0:
        return target, 0.0
    if dt <= 0:
        return x, v
    w = 2.0 / smoothing
    e0 = x - target
    b = v + w * e0
    ex = math.exp(-w * dt)
    e = (e0 + b * dt) * ex
    nv = (b - w * (e0 + b * dt)) * ex
    return target + e, nv

class Timeline:
    def __init__(s, pts, min_conf, max_gap):
        s.obs = sorted([p for p in pts if p[3] >= min_conf and all(map(math.isfinite, p[:3]))], key=lambda p: p[0])
        s.gap = max_gap
    # p = (time, minX, maxX, confidence)
    def box(s, t):
        o = s.obs
        if not o: return None
        if t <= o[0][0]: return (o[0][1], o[0][2])
        if t >= o[-1][0]: return (o[-1][1], o[-1][2])
        lo, hi = 0, len(o) - 1
        while hi - lo > 1:
            m = (lo + hi) // 2
            if o[m][0] <= t: lo = m
            else: hi = m
        a, b = o[lo], o[lo + 1]
        if b[0] - a[0] > s.gap: return (a[1], a[2])
        al = (t - a[0]) / (b[0] - a[0])
        return (a[1] + (b[1]-a[1])*al, a[2] + (b[2]-a[2])*al)

def composition(minx, maxx, cw, st):
    pmin, pmax = cw/2, 1 - cw/2
    center = (minx + maxx) / 2
    width = maxx - minx
    # margem efetiva: encolhe se não couber; vira 0 se o próprio box já for maior que o crop
    m = min(st.horizontalMargin * cw, max(0.0, (cw - width) / 2))
    el, er = max(0.0, minx - m), min(1.0, maxx + m)
    lo, hi = max(er - cw/2, pmin), min(el + cw/2, pmax)
    if lo > hi:            # impossível manter margem: só o limite físico vale
        lo, hi = pmin, pmax
    goal = min(max(center, lo), hi)
    return goal, lo, hi

def trajectory(points, src_aspect, out_aspect, fps, st, time_range=None):
    cw = crop_width(src_aspect, out_aspect)
    pmin, pmax = cw/2, 1 - cw/2
    tl = Timeline(points, st.minConfidence, st.maxInterpolationGap)
    if not tl.obs:
        if time_range is None: return []
        t0, t1 = time_range
    else:
        t0, t1 = time_range if time_range else (tl.obs[0][0], tl.obs[-1][0])
    n = int(math.floor((t1 - t0) * fps + 1e-9))
    def goal_at(t):
        b = tl.box(t)
        if b is None: return 0.5 if pmin <= 0.5 <= pmax else min(max(0.5,pmin),pmax), pmin, pmax
        return composition(b[0], b[1], cw, st)
    g0, _, _ = goal_at(t0)  # começa já enquadrando o sujeito em t0
    c, v, following = g0, 0.0, False
    out = [(t0, c)]
    tp = t0
    h = st.deadZoneWidth * cw / 2
    rel = st.releaseFraction * h
    for i in range(1, n + 1):
        t = t0 + i / fps
        dt = t - tp
        goal, lo, hi = goal_at(t + st.lookAhead)
        if not following and abs(goal - c) > h: following = True
        if following:
            desired = goal
            if abs(goal - c) <= rel and abs(v) <= st.releaseSpeed:
                following = False
                desired = min(max(c, lo), hi)
        else:
            desired = min(max(c, lo), hi)
        x, nv = spring_step(c, v, desired, dt, st.smoothingTime)
        dx = x - c
        mx = st.maxSpeed * dt
        if abs(dx) > mx:
            dx = math.copysign(mx, dx); x = c + dx; nv = dx / dt
        cl = min(max(x, pmin), pmax)
        if cl != x: x = cl; nv = 0.0
        c, v, tp = x, nv, t
        out.append((t, c))
    return out

def metrics(crop, points, cw, st):
    tl = Timeline(points, st.minConfidence, st.maxInterpolationGap)
    n = len(crop)
    s = []; inside = 0
    for (t, c) in crop:
        b = tl.box(t)
        s.append((b[0]+b[1])/2)
        if b[0] >= c - cw/2 - 1e-9 and b[1] <= c + cw/2 + 1e-9: inside += 1
    dt = (crop[-1][0] - crop[0][0]) / (n - 1)
    x = [c for _, c in crop]
    v = [(x[i+1]-x[i])/dt for i in range(n-1)]
    a = [(v[i+1]-v[i])/dt for i in range(len(v)-1)]
    j = [(a[i+1]-a[i])/dt for i in range(len(a)-1)]
    sign = 0; changes = 0
    for vi in v:
        if abs(vi) > 1e-3:
            sg = 1 if vi > 0 else -1
            if sign != 0 and sg != sign: changes += 1
            sign = sg
    err = sum(abs(s[i]-x[i]) for i in range(n)) / n
    K = min(int(2.0/dt), n//2)
    best, bk = None, 0
    for k in range(K+1):
        m = sum((x[i]-s[i-k])**2 for i in range(k, n)) / (n-k)
        if best is None or m < best - 1e-12: best, bk = m, k
    return dict(meanErr=err, meanErrCropW=err/cw, inside=inside/n,
                maxSpeed=max(abs(q) for q in v) if v else 0,
                maxAccel=max(abs(q) for q in a) if a else 0,
                jerkRMS=math.sqrt(sum(q*q for q in j)/len(j)) if j else 0,
                dirChanges=changes, lag=bk*dt)

def walk(x0, x1, ts, te, dur, fps, bw=0.10, jitter=0.0, seed=1):
    rnd = random.Random(seed); pts = []
    for i in range(int(dur*fps)+1):
        t = i/fps
        a = 0.0 if t <= ts else (1.0 if t >= te else (t-ts)/(te-ts))
        cx = x0 + (x1-x0)*a + (rnd.uniform(-jitter, jitter) if jitter else 0)
        pts.append((t, cx-bw/2, cx+bw/2, 1.0))
    return pts
