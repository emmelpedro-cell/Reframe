"""Espelho em Python do OneEuroFilter + ReframePipeline (Swift), mesma matemática e mesma
ordem de operações. Usa o espelho do M1 (reframe_ref.py) SEM modificá-lo."""
import math
from reframe_ref import Settings, trajectory, metrics, crop_width

# ---------- One Euro --------------------------------------------------------------------
MIN_DT = 1e-9

def smoothing_factor(cutoff, dt):
    r = 2 * math.pi * cutoff * dt
    if not math.isfinite(r):
        return 1.0
    return r / (1 + r)

class OneEuro:
    def __init__(self, min_cutoff=1.0, beta=0.0, d_cutoff=1.0):
        pos = lambda v: math.isfinite(v) and v > 0
        self.min_cutoff = min_cutoff if pos(min_cutoff) else 1.0
        self.beta = beta if (math.isfinite(beta) and beta >= 0) else 0.0
        self.d_cutoff = d_cutoff if pos(d_cutoff) else 1.0
        self.reset()

    def reset(self):
        self.initialized = False
        self.t = self.raw = self.filt = self.d = 0.0

    def _seed(self, v, t):
        self.initialized = True
        self.t, self.raw, self.filt, self.d = t, v, v, 0.0

    def reset_to(self, v, t):
        self.reset()
        if math.isfinite(v) and math.isfinite(t):
            self._seed(v, t)

    def filter(self, v, t):
        if not (math.isfinite(v) and math.isfinite(t)):
            return self.filt if self.initialized else v
        if not self.initialized:
            self._seed(v, t)
            return v
        dt = t - self.t
        if dt < MIN_DT:
            return self.filt
        raw_d = (v - self.raw) / dt
        a_d = smoothing_factor(self.d_cutoff, dt)
        d = a_d * raw_d + (1 - a_d) * self.d
        cutoff = self.min_cutoff + self.beta * abs(d)
        a = smoothing_factor(cutoff, dt)
        f = a * v + (1 - a) * self.filt
        self.t, self.raw, self.filt, self.d = t, v, f, d
        return f

# ---------- pré-filtro do pipeline -------------------------------------------------------
class OneEuroSettings:
    def __init__(self, min_cutoff=1.0, beta=5.0, d_cutoff=1.0):
        self.min_cutoff, self.beta, self.d_cutoff = min_cutoff, beta, d_cutoff

def prefilter(points, st, oe):
    """points: tuplas (t, minX, maxX, conf). Espelho de ReframePipeline.prefiltered."""
    valid = [i for i, p in enumerate(points)
             if p[3] >= st.minConfidence and all(map(math.isfinite, p[:3]))]
    valid.sort(key=lambda i: (points[i][0], i))
    cf = OneEuro(oe.min_cutoff, oe.beta, oe.d_cutoff)
    wf = OneEuro(oe.min_cutoff, oe.beta, oe.d_cutoff)
    prev = None
    out = list(points)
    for i in valid:
        t, mn, mx, conf = points[i]
        if prev is not None and t - prev > st.maxInterpolationGap:
            cf.reset(); wf.reset()
        center = (mn + mx) / 2
        width = max(0.0, mx - mn)
        fc = cf.filter(center, t)
        fw = max(0.0, wf.filter(width, t))
        x = fc - fw / 2
        out[i] = (t, x, x + fw, conf)     # CGRect.maxX = x + width
        prev = t
    return out

def pipeline_trajectory(points, sa, oa, fps, st, use_one_euro, oe=None, time_range=None):
    if use_one_euro:
        points = prefilter(points, st, oe or OneEuroSettings())
    return trajectory(points, sa, oa, fps, st, time_range)

# ---------- geradores determinísticos (idênticos aos de ABScenarios.swift) -----------------
M64 = (1 << 64) - 1
class SplitMix64:
    def __init__(self, seed): self.state = seed & M64
    def next(self):
        self.state = (self.state + 0x9E3779B97F4A7C15) & M64
        z = self.state
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        z = z ^ (z >> 31)
        return (z >> 11) / 9007199254740992.0
    def between(self, lo, hi): return lo + (hi - lo) * self.next()

def pt(t, cx, w=0.10, conf=1.0):
    minx = cx - w / 2
    return (t, minx, minx + w, conf)

def walk(x0, x1, start, end, duration, fps, bw=0.10, jitter=0.0, seed=1):
    rng = SplitMix64(seed); out = []
    for i in range(int(round(duration * fps)) + 1):
        t = i / fps
        a = 0.0
        if t >= end: a = 1.0
        elif t > start: a = (t - start) / (end - start)
        cx = x0 + (x1 - x0) * a
        if jitter > 0: cx += rng.between(-jitter, jitter)
        out.append(pt(t, cx, bw))
    return out

def sine(duration, fps, jitter=0.0, seed=1):
    rng = SplitMix64(seed); out = []
    for i in range(int(round(duration * fps)) + 1):
        t = i / fps
        cx = 0.5 + 0.28 * math.sin(2 * math.pi * t / 8.0)
        if jitter > 0: cx += rng.between(-jitter, jitter)
        out.append(pt(t, cx))
    return out

def zigzag(duration, fps, jitter=0.0, seed=1):
    rng = SplitMix64(seed); out = []
    for i in range(int(round(duration * fps)) + 1):
        t = i / fps
        phase = math.fmod(t / 6.0, 1.0)
        tri = 2 * phase if phase < 0.5 else 2 - 2 * phase
        cx = 0.30 + 0.40 * tri
        if jitter > 0: cx += rng.between(-jitter, jitter)
        out.append(pt(t, cx))
    return out

def jump():
    out = []
    for i in range(150):
        t = i / 30.0
        cx = 0.40 + 0.01 * min(i, 2) if t < 3.0 else 0.80
        out.append(pt(t, cx))
    return out

def loss():
    return [pt(i / 30.0, 0.50) for i in range(0, 61)] + [pt(i / 30.0, 0.70) for i in range(180, 241)]

def ab_cases():
    """(nome, fps, raw, truth). Para cenários sem ruído, truth = raw."""
    cases = []
    def add(name, raw, truth=None, fps=30):
        cases.append((name, fps, raw, raw if truth is None else truth))
    add("stationaryJitter", walk(0.5, 0.5, 0, 1, 4, 30, jitter=0.01, seed=1), walk(0.5, 0.5, 0, 1, 4, 30))
    c = walk(0.30, 0.70, 1, 9, 10, 30)
    add("walkClean", c)
    add("walkNoisy", walk(0.30, 0.70, 1, 9, 10, 30, jitter=0.01, seed=3), c)
    add("walkNoisyHeavy", walk(0.30, 0.70, 1, 9, 10, 30, jitter=0.03, seed=4), c)
    add("sineClean", sine(12, 30))
    add("sineNoisy", sine(12, 30, jitter=0.01, seed=5), sine(12, 30))
    add("zigzagNoisy", zigzag(12, 30, jitter=0.01, seed=6), zigzag(12, 30))
    add("jump", jump())
    add("loss", loss())
    return cases

SA, OA = 16 / 9, 9 / 16
CW = crop_width(SA, OA)
KEYS = [("meanSubjectError", "meanErr"), ("meanSubjectErrorInCropWidths", "meanErrCropW"),
        ("insideCropRatio", "inside"), ("maxSpeed", "maxSpeed"), ("maxAcceleration", "maxAccel"),
        ("jerkRMS", "jerkRMS"), ("directionChanges", "dirChanges"), ("apparentLag", "lag")]

def run_ab(oe=None):
    st = Settings()
    oe = oe or OneEuroSettings()
    res = {}
    for name, fps, raw, truth in ab_cases():
        base = pipeline_trajectory(raw, SA, OA, fps, st, False)
        exp = pipeline_trajectory(raw, SA, OA, fps, st, True, oe)
        res[name] = dict(
            fps=fps, base=base, exp=exp,
            m={("baseline", "raw"): metrics(base, raw, CW, st), ("oneEuro", "raw"): metrics(exp, raw, CW, st),
               ("baseline", "truth"): metrics(base, truth, CW, st), ("oneEuro", "truth"): metrics(exp, truth, CW, st)})
    return res
