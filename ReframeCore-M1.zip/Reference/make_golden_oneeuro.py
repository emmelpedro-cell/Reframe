"""Gera Tests/ReframeCoreTests/GoldenOneEuroData.swift e AB_REPORT.md a partir do espelho Python.
Uso: python3 make_golden_oneeuro.py <GoldenOneEuroData.swift> <AB_REPORT.md>"""
import sys, math
from oneeuro_ref import *

STRIDE = 5

# entradas dos vetores do filtro: tempos irregulares + valores (SplitMix64, seed 21)
rng = SplitMix64(21)
times, values, t = [], [], 0.0
for i in range(60):
    t += 0.005 + 0.2 * rng.next()
    times.append(t)
    values.append(0.5 + 0.3 * rng.next())
params = [(1.0, 5.0, 1.0), (0.5, 0.0, 2.0), (0.001, 100.0, 10.0)]
outs = []
for mc, b, dc in params:
    f = OneEuro(mc, b, dc)
    outs.append([f.filter(v, tt) for v, tt in zip(values, times)])

res = run_ab()
fl = lambda xs: "[\n" + "".join("        " + ", ".join(repr(float(v)) for v in xs[k:k+4]) + ",\n" for k in range(0, len(xs), 4)) + "    ]"

L = ["// GERADO por Reference/make_golden_oneeuro.py (espelho Python). Não editar à mão.",
     "// Vetores do One Euro e do pipeline A/B (amostras de centerX a cada STRIDE pontos) + métricas.",
     "enum GoldenOneEuroData {", f"    static let stride = {STRIDE}",
     "    static let filterTimes: [Double] = " + fl(times),
     "    static let filterValues: [Double] = " + fl(values),
     "    static let filterParams: [[Double]] = [" + ", ".join("[" + ", ".join(repr(float(p)) for p in ps) + "]" for ps in params) + "]",
     "    static let filterOutputs: [[Double]] = [" + ", ".join(fl(o) for o in outs) + "]",
     "    static let caseNames: [String] = [" + ", ".join(f'"{n}"' for n in res) + "]"]
for kind in ("base", "exp"):
    nm = "baseline" if kind == "base" else "oneEuro"
    L.append(f"    static let {nm}Count: [String: Int] = [" + ", ".join(f'"{n}": {len(r[kind])}' for n, r in res.items()) + "]")
    L.append(f"    static let {nm}: [String: [Double]] = [")
    for n, r in res.items():
        L.append(f'        "{n}": ' + fl([r[kind][i][1] for i in range(0, len(r[kind]), STRIDE)]) + ",")
    L.append("    ]")
L.append("    static let metrics: [String: [String: Double]] = [")
for n, r in res.items():
    for (pipe, ref), m in r["m"].items():
        L.append(f'        "{n}|{pipe}|{ref}": [' + ", ".join(f'"{sk}": {float(m[pk])!r}' for sk, pk in KEYS) + "],")
L.append("    ]")
L.append("}")
open(sys.argv[1], "w").write("\n".join(L) + "\n")

# ---------- relatório A/B (Markdown) ----------
fmt = lambda pk, v: f"{int(v)}" if pk == "dirChanges" else (f"{v*100:.1f}%" if pk == "inside" else f"{v:.4f}")
R = ["# A/B: baseline M1 × One Euro (valores do espelho Python)", "",
     "Baseline: `raw → composição → dead zone → spring`. Experimental: `raw → One Euro → composição → dead zone → spring`.",
     "Parâmetros do One Euro (documentados, NÃO ajustados): minCutoff 1,0 Hz · beta 5,0 · dCutoff 1,0 Hz. Demais parâmetros = `ReframeSettings()` padrão, iguais nos dois lados.", "",
     "Cada métrica é medida (a) contra o tracking BRUTO que o engine recebeu e (b) contra a trajetória REAL sem ruído (só para cenários com ruído).", ""]
for n, r in res.items():
    refs = ["raw"] + (["truth"] if r["m"][("baseline", "raw")] != r["m"][("baseline", "truth")] else [])
    R.append(f"## {n}  ({r['fps']:.0f} fps)"); R.append("")
    R.append("| métrica | baseline (bruto) | One Euro (bruto) |" + (" baseline (real) | One Euro (real) |" if len(refs) == 2 else ""))
    R.append("|---|---:|---:|" + ("---:|---:|" if len(refs) == 2 else ""))
    for sk, pk in KEYS:
        row = f"| {sk} | {fmt(pk, r['m'][('baseline','raw')][pk])} | {fmt(pk, r['m'][('oneEuro','raw')][pk])} |"
        if len(refs) == 2:
            row += f" {fmt(pk, r['m'][('baseline','truth')][pk])} | {fmt(pk, r['m'][('oneEuro','truth')][pk])} |"
        R.append(row)
    R.append("")
open(sys.argv[2], "w").write("\n".join(R) + "\n")
print("golden:", sum(len(l) for l in L), "bytes; relatório:", len(R), "linhas")
