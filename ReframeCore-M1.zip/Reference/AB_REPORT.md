# A/B: baseline M1 × One Euro (valores do espelho Python)

Baseline: `raw → composição → dead zone → spring`. Experimental: `raw → One Euro → composição → dead zone → spring`.
Parâmetros do One Euro (documentados, NÃO ajustados): minCutoff 1,0 Hz · beta 5,0 · dCutoff 1,0 Hz. Demais parâmetros = `ReframeSettings()` padrão, iguais nos dois lados.

Cada métrica é medida (a) contra o tracking BRUTO que o engine recebeu e (b) contra a trajetória REAL sem ruído (só para cenários com ruído).

## stationaryJitter  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) | baseline (real) | One Euro (real) |
|---|---:|---:|---:|---:|
| meanSubjectError | 0.0049 | 0.0049 | 0.0013 | 0.0013 |
| meanSubjectErrorInCropWidths | 0.0153 | 0.0153 | 0.0042 | 0.0042 |
| insideCropRatio | 100.0% | 100.0% | 100.0% | 100.0% |
| maxSpeed | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| maxAcceleration | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| jerkRMS | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| directionChanges | 0 | 0 | 0 | 0 |
| apparentLag | 2.0000 | 2.0000 | 0.0000 | 0.0000 |

## walkClean  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) |
|---|---:|---:|
| meanSubjectError | 0.0038 | 0.0089 |
| meanSubjectErrorInCropWidths | 0.0119 | 0.0282 |
| insideCropRatio | 100.0% | 100.0% |
| maxSpeed | 0.0933 | 0.0938 |
| maxAcceleration | 0.7205 | 0.7248 |
| jerkRMS | 1.0450 | 1.0513 |
| directionChanges | 0 | 0 |
| apparentLag | 0.1000 | 0.2000 |

## walkNoisy  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) | baseline (real) | One Euro (real) |
|---|---:|---:|---:|---:|
| meanSubjectError | 0.0070 | 0.0096 | 0.0049 | 0.0095 |
| meanSubjectErrorInCropWidths | 0.0222 | 0.0303 | 0.0153 | 0.0300 |
| insideCropRatio | 100.0% | 100.0% | 100.0% | 100.0% |
| maxSpeed | 0.0954 | 0.0933 | 0.0954 | 0.0933 |
| maxAcceleration | 0.6647 | 0.7140 | 0.6647 | 0.7140 |
| jerkRMS | 2.3441 | 1.1347 | 2.3441 | 1.1347 |
| directionChanges | 0 | 0 | 0 | 0 |
| apparentLag | 0.1000 | 0.2000 | 0.1000 | 0.2000 |

## walkNoisyHeavy  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) | baseline (real) | One Euro (real) |
|---|---:|---:|---:|---:|
| meanSubjectError | 0.0156 | 0.0165 | 0.0036 | 0.0070 |
| meanSubjectErrorInCropWidths | 0.0494 | 0.0523 | 0.0115 | 0.0221 |
| insideCropRatio | 100.0% | 100.0% | 100.0% | 100.0% |
| maxSpeed | 0.1009 | 0.0804 | 0.1009 | 0.0804 |
| maxAcceleration | 0.7553 | 0.7675 | 0.7553 | 0.7675 |
| jerkRMS | 6.6527 | 2.0386 | 6.6527 | 2.0386 |
| directionChanges | 0 | 0 | 0 | 0 |
| apparentLag | 0.0333 | 0.1333 | 0.0667 | 0.1667 |

## sineClean  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) |
|---|---:|---:|
| meanSubjectError | 0.0082 | 0.0193 |
| meanSubjectErrorInCropWidths | 0.0259 | 0.0610 |
| insideCropRatio | 100.0% | 100.0% |
| maxSpeed | 0.2239 | 0.2142 |
| maxAcceleration | 1.4261 | 1.1748 |
| jerkRMS | 1.8727 | 1.7849 |
| directionChanges | 3 | 3 |
| apparentLag | 0.0333 | 0.1333 |

## sineNoisy  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) | baseline (real) | One Euro (real) |
|---|---:|---:|---:|---:|
| meanSubjectError | 0.0089 | 0.0191 | 0.0078 | 0.0187 |
| meanSubjectErrorInCropWidths | 0.0281 | 0.0602 | 0.0247 | 0.0591 |
| insideCropRatio | 100.0% | 100.0% | 100.0% | 100.0% |
| maxSpeed | 0.2279 | 0.2163 | 0.2279 | 0.2163 |
| maxAcceleration | 1.5352 | 1.2476 | 1.5352 | 1.2476 |
| jerkRMS | 2.8439 | 1.8828 | 2.8439 | 1.8828 |
| directionChanges | 3 | 3 | 3 | 3 |
| apparentLag | 0.0333 | 0.1333 | 0.0333 | 0.1333 |

## zigzagNoisy  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) | baseline (real) | One Euro (real) |
|---|---:|---:|---:|---:|
| meanSubjectError | 0.0076 | 0.0173 | 0.0061 | 0.0170 |
| meanSubjectErrorInCropWidths | 0.0241 | 0.0548 | 0.0194 | 0.0536 |
| insideCropRatio | 100.0% | 100.0% | 100.0% | 100.0% |
| maxSpeed | 0.1483 | 0.1471 | 0.1483 | 0.1471 |
| maxAcceleration | 0.8408 | 0.8564 | 0.8408 | 0.8564 |
| jerkRMS | 2.7727 | 1.9594 | 2.7727 | 1.9594 |
| directionChanges | 3 | 3 | 3 | 3 |
| apparentLag | 0.0333 | 0.1333 | 0.0333 | 0.1333 |

## jump  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) |
|---|---:|---:|
| meanSubjectError | 0.0377 | 0.0381 |
| meanSubjectErrorInCropWidths | 0.1192 | 0.1203 |
| insideCropRatio | 90.0% | 90.7% |
| maxSpeed | 0.3500 | 0.3500 |
| maxAcceleration | 5.8395 | 4.8290 |
| jerkRMS | 16.0039 | 12.2353 |
| directionChanges | 0 | 0 |
| apparentLag | 0.2000 | 0.2000 |

## loss  (30 fps)

| métrica | baseline (bruto) | One Euro (bruto) |
|---|---:|---:|
| meanSubjectError | 0.0062 | 0.0062 |
| meanSubjectErrorInCropWidths | 0.0197 | 0.0197 |
| insideCropRatio | 100.0% | 100.0% |
| maxSpeed | 0.3265 | 0.3265 |
| maxAcceleration | 2.9197 | 2.9197 |
| jerkRMS | 4.8718 | 4.8718 |
| directionChanges | 0 | 0 |
| apparentLag | 0.0000 | 0.0000 |

