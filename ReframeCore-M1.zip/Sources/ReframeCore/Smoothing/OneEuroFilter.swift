import Foundation

/// Filtro One Euro (Casiez, Roussel, Vogel — CHI 2012) para um sinal escalar.
///
/// É um filtro passa-baixa de primeira ordem cuja frequência de corte se adapta à
/// velocidade do sinal: parado, o corte fica baixo (remove jitter); em movimento
/// rápido, o corte sobe (reduz o atraso).
///
///     dx̂ₙ   = α(dCutoff, dt) · (xₙ − xₙ₋₁)/dt + (1 − α(dCutoff, dt)) · dx̂ₙ₋₁
///     fcₙ   = minCutoff + beta · |dx̂ₙ|
///     x̂ₙ    = α(fcₙ, dt) · xₙ + (1 − α(fcₙ, dt)) · x̂ₙ₋₁
///     α(fc, dt) = r / (1 + r),   r = 2π · fc · dt      (equivale a 1 / (1 + τ/dt), τ = 1/(2π fc))
///
/// Propriedades de projeto:
/// - **Tempo real de cada amostra.** `dt` vem dos timestamps, nunca de um fps assumido.
/// - **Sem estado global.** Todo o estado vive na própria struct (tipo valor).
/// - **Determinístico.** Mesma sequência de (valor, tempo) → mesmas saídas, sempre.
/// - **Sem framework.** Só Foundation; não depende de câmera, Vision ou renderização.
///
/// Unidades: `time` em segundos; `minCutoff` e `dCutoff` em Hz; `beta` em Hz por
/// (unidade do sinal por segundo). Se o sinal está normalizado em 0...1 (como no
/// ReframeCore), `beta` é "Hz por largura-do-frame por segundo".
///
/// Comportamento nas bordas:
/// - **Primeira amostra** (filtro novo ou após `reset()`): é devolvida como está e a
///   derivada estimada começa em 0.
/// - **`dt` ≤ `minimumDeltaTime`** (timestamp repetido, ou que volta no tempo): a
///   amostra é ignorada — devolve a última saída e não altera o estado. Evita divisão
///   por zero e derivadas absurdas.
/// - **Valor ou tempo não finito:** ignorado do mesmo modo (se o filtro ainda não foi
///   inicializado, o valor é devolvido sem inicializar).
/// - **Parâmetros inválidos** (não finitos, cutoff ≤ 0, beta < 0) são substituídos
///   pelos padrões (`minCutoff` 1, `beta` 0, `dCutoff` 1).
public struct OneEuroFilter: Equatable, Sendable {
    /// Corte mínimo (Hz): quanto menor, mais suave com o sinal parado (e mais atraso).
    public let minCutoff: Double
    /// Coeficiente de velocidade: quanto maior, mais o corte sobe com a velocidade.
    public let beta: Double
    /// Corte (Hz) do filtro da derivada.
    public let dCutoff: Double

    /// Intervalo mínimo (s) entre amostras para atualizar o filtro.
    public static let minimumDeltaTime: Double = 1e-9

    /// `true` depois da primeira amostra (ou de `reset(value:time:)`).
    public private(set) var isInitialized: Bool = false

    private var lastTime: Double = 0
    private var lastRaw: Double = 0
    private var lastFiltered: Double = 0
    private var lastDerivative: Double = 0

    public init(minCutoff: Double = 1.0, beta: Double = 0.0, dCutoff: Double = 1.0) {
        self.minCutoff = (minCutoff.isFinite && minCutoff > 0) ? minCutoff : 1.0
        self.beta = (beta.isFinite && beta >= 0) ? beta : 0.0
        self.dCutoff = (dCutoff.isFinite && dCutoff > 0) ? dCutoff : 1.0
    }

    /// Esquece todo o estado. A próxima amostra volta a ser tratada como a primeira.
    public mutating func reset() {
        isInitialized = false
        lastTime = 0
        lastRaw = 0
        lastFiltered = 0
        lastDerivative = 0
    }

    /// Reinicia o filtro já "semeado" com `value` em `time` (derivada zero).
    /// Equivale a ter filtrado `value` como primeira amostra.
    public mutating func reset(value: Double, time: Double) {
        reset()
        guard value.isFinite, time.isFinite else { return }
        seed(value: value, time: time)
    }

    /// Filtra a amostra `value` observada no instante `time` (segundos) e devolve a saída.
    @discardableResult
    public mutating func filter(value: Double, time: Double) -> Double {
        guard value.isFinite, time.isFinite else {
            return isInitialized ? lastFiltered : value
        }
        guard isInitialized else {
            seed(value: value, time: time)
            return value
        }
        let dt = time - lastTime
        guard dt >= Self.minimumDeltaTime else {
            return lastFiltered
        }

        let rawDerivative = (value - lastRaw) / dt
        let derivativeAlpha = Self.smoothingFactor(cutoff: dCutoff, deltaTime: dt)
        let derivative = derivativeAlpha * rawDerivative + (1 - derivativeAlpha) * lastDerivative

        let cutoff = minCutoff + beta * abs(derivative)
        let alpha = Self.smoothingFactor(cutoff: cutoff, deltaTime: dt)
        let filtered = alpha * value + (1 - alpha) * lastFiltered

        lastTime = time
        lastRaw = value
        lastFiltered = filtered
        lastDerivative = derivative
        return filtered
    }

    private mutating func seed(value: Double, time: Double) {
        isInitialized = true
        lastTime = time
        lastRaw = value
        lastFiltered = value
        lastDerivative = 0
    }

    /// α = r / (1 + r), r = 2π · cutoff · dt. Sempre em [0, 1]; sem divisão por zero.
    static func smoothingFactor(cutoff: Double, deltaTime: Double) -> Double {
        let r = 2 * Double.pi * cutoff * deltaTime
        guard r.isFinite else { return 1 }
        return r / (1 + r)
    }
}
