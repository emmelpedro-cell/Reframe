import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif

/// Parâmetros do pré-filtro One Euro (experimental).
///
/// Os valores padrão são um PONTO DE PARTIDA documentado, não foram ajustados contra o
/// baseline:
/// - `minCutoff = 1,0 Hz` e `dCutoff = 1,0 Hz`: valores de partida usuais do filtro.
/// - `beta = 5,0`: o artigo original usa ≈ 0,007 para sinais em pixels (faixa da ordem
///   de 10³ px); em coordenadas normalizadas (faixa 0...1) o equivalente fica na ordem de
///   unidades (≈ 7), arredondado para baixo para 5. Com isso, andar a 0,1 largura/s sobe
///   o corte em ~0,5 Hz e uma corrida a 0,5 largura/s em ~2,5 Hz.
public struct OneEuroSettings: Equatable, Sendable {
    public var minCutoff: Double
    public var beta: Double
    public var dCutoff: Double

    public init(minCutoff: Double = 1.0, beta: Double = 5.0, dCutoff: Double = 1.0) {
        self.minCutoff = minCutoff
        self.beta = beta
        self.dCutoff = dCutoff
    }

    public static let `default` = OneEuroSettings()
}

/// Configuração do pipeline completo: parâmetros do engine (M1, inalterados) + a chave
/// experimental do One Euro.
public struct ReframePipelineSettings: Equatable, Sendable {
    /// Parâmetros do `ReframeEngine` (composição, dead zone, look-ahead, spring, velocidade).
    public var reframe: ReframeSettings
    /// `false` (padrão) = baseline M1. `true` = One Euro antes da composição.
    public var useOneEuro: Bool
    public var oneEuro: OneEuroSettings

    public init(
        reframe: ReframeSettings = ReframeSettings(),
        useOneEuro: Bool = false,
        oneEuro: OneEuroSettings = .default
    ) {
        self.reframe = reframe
        self.useOneEuro = useOneEuro
        self.oneEuro = oneEuro
    }
}

/// Pipeline de comparação A/B. NÃO reimplementa nenhuma lógica do engine:
///
///     useOneEuro = false:  TrackingPoint ─────────────────────────────┐
///                                                                      ▼
///     useOneEuro = true:   TrackingPoint ─► [One Euro] ─► TrackingPoint ─► ReframeEngine
///                                                         (composição → dead zone → spring
///                                                          → velocidade máx. → clamp)
///
/// Com `useOneEuro = false` a chamada ao engine é exatamente a do M1 (mesmos bytes de saída).
/// Com `true`, só os pontos de entrada mudam; o `ReframeEngine` continua sendo o mesmo.
///
/// O que o One Euro filtra: para cada observação VÁLIDA (confiança ≥ `minConfidence`,
/// valores finitos) filtra-se, com o tempo real da amostra, o CENTRO horizontal e a
/// LARGURA do box (dois filtros independentes, mesmos parâmetros). Filtrar largura (que
/// é ≥ 0) mantém o box válido por construção: a média ponderada de larguras não negativas
/// nunca fica negativa. `y` e altura não são usados pelo engine e passam inalterados.
///
/// Observações de baixa confiança, não finitas ou fora de ordem de tempo NÃO alimentam o
/// filtro: baixa confiança e não finitas passam inalteradas (o engine já as trata como
/// "sujeito perdido"). Se duas observações válidas consecutivas distam mais que
/// `maxInterpolationGap`, o filtro é reiniciado (é uma descontinuidade de trilha, não
/// movimento), do mesmo modo que o engine para de interpolar nesse intervalo.
public struct ReframePipeline: Sendable {
    public let engine: ReframeEngine
    public let useOneEuro: Bool
    public let oneEuro: OneEuroSettings

    public init(geometry: CropGeometry, settings: ReframePipelineSettings = ReframePipelineSettings()) {
        self.engine = ReframeEngine(geometry: geometry, settings: settings.reframe)
        self.useOneEuro = settings.useOneEuro
        self.oneEuro = settings.oneEuro
    }

    public init(sourceAspect: Double, outputAspect: Double, settings: ReframePipelineSettings = ReframePipelineSettings()) {
        self.init(
            geometry: CropGeometry(sourceAspect: sourceAspect, outputAspect: outputAspect),
            settings: settings
        )
    }

    public func trajectory(for track: SubjectTrack, fps: Double, timeRange: ClosedRange<Double>? = nil) -> [CropPoint] {
        return trajectory(points: track.points, fps: fps, timeRange: timeRange)
    }

    public func trajectory(points: [TrackingPoint], fps: Double, timeRange: ClosedRange<Double>? = nil) -> [CropPoint] {
        return engine.trajectory(points: prefiltered(points), fps: fps, timeRange: timeRange)
    }

    /// Pontos que entram no engine. Com `useOneEuro = false` devolve `points` sem tocar.
    public func prefiltered(_ points: [TrackingPoint]) -> [TrackingPoint] {
        guard useOneEuro else { return points }

        let minConfidence = engine.settings.minConfidence
        let maxGap = engine.settings.maxInterpolationGap

        var valid: [Int] = []
        valid.reserveCapacity(points.count)
        for index in points.indices {
            let point = points[index]
            let box = point.boundingBox
            guard point.confidence >= minConfidence,
                  point.time.isFinite,
                  Double(box.minX).isFinite,
                  Double(box.maxX).isFinite else { continue }
            valid.append(index)
        }
        // Ordem temporal; empate de tempo mantém a ordem original (ordenação estável).
        valid.sort { a, b in
            let ta = points[a].time
            let tb = points[b].time
            return ta != tb ? ta < tb : a < b
        }

        var centerFilter = OneEuroFilter(minCutoff: oneEuro.minCutoff, beta: oneEuro.beta, dCutoff: oneEuro.dCutoff)
        var widthFilter = centerFilter
        var previousTime: Double?

        var result = points
        for index in valid {
            let point = points[index]
            let time = point.time
            if let previous = previousTime, time - previous > maxGap {
                centerFilter.reset()
                widthFilter.reset()
            }
            let minX = Double(point.boundingBox.minX)
            let maxX = Double(point.boundingBox.maxX)
            let center = (minX + maxX) / 2
            let width = max(0, maxX - minX)

            let filteredCenter = centerFilter.filter(value: center, time: time)
            let filteredWidth = max(0, widthFilter.filter(value: width, time: time))

            let box = CGRect(
                x: CGFloat(filteredCenter - filteredWidth / 2),
                y: point.boundingBox.minY,
                width: CGFloat(filteredWidth),
                height: point.boundingBox.height
            )
            result[index] = TrackingPoint(time: time, boundingBox: box, confidence: point.confidence)
            previousTime = time
        }
        return result
    }
}
