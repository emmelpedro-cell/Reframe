import Foundation
import TrackingKit

/// Formato da saída. Todos saem em pé ou quadrados, a partir do vídeo horizontal.
enum OutputFormat: String, CaseIterable, Identifiable {
    case vertical, retrato, quadrado
    var id: String { rawValue }

    var title: String {
        switch self {
        case .vertical: return "9:16"
        case .retrato: return "4:5"
        case .quadrado: return "1:1"
        }
    }
    var hint: String {
        switch self {
        case .vertical: return "Reels, TikTok, Shorts"
        case .retrato: return "Feed do Instagram"
        case .quadrado: return "Quadrado"
        }
    }
    var aspect: Double {
        switch self {
        case .vertical: return 9.0 / 16.0
        case .retrato: return 4.0 / 5.0
        case .quadrado: return 1.0
        }
    }
}

extension RenderPreset {
    var title: String {
        switch self {
        case .suave: return "Suave"
        case .padrao: return "Padrão"
        case .oneeuro: return "One Euro"
        case .rapido: return "Rápido"
        }
    }
    var hint: String {
        switch self {
        case .suave: return "Movimento calmo, com um pouco de atraso"
        case .padrao: return "Equilíbrio entre calma e rapidez"
        case .oneeuro: return "Experimental: menos tremor"
        case .rapido: return "Acompanha depressa, mais nervoso"
        }
    }
}
