import Foundation
import AVFoundation
import UIKit

/// Grava vídeo na horizontal com a câmera traseira (1080p ou 4K, 30 fps).
final class CameraService: NSObject, ObservableObject, AVCaptureFileOutputRecordingDelegate {

    enum Quality: String, CaseIterable, Identifiable {
        case hd1080 = "1080p"
        case uhd4K = "4K"
        var id: String { rawValue }
        var preset: AVCaptureSession.Preset {
            switch self {
            case .hd1080: return .hd1920x1080
            case .uhd4K: return .hd4K3840x2160
            }
        }
    }

    enum State: Equatable {
        case preparing, ready, recording
        case denied
        case unavailable
    }

    @Published private(set) var state: State = .preparing
    @Published private(set) var elapsed: TimeInterval = 0
    @Published private(set) var finishedURL: URL?
    @Published private(set) var supports4K = false
    @Published var quality: Quality = .hd1080 {
        didSet { applyQuality() }
    }

    let session = AVCaptureSession()
    private let movieOutput = AVCaptureMovieFileOutput()
    private let queue = DispatchQueue(label: "app.autoreframe.camera")
    private var configured = false
    private var timer: Timer?
    private var startedAt: Date?

    // MARK: Ciclo de vida

    func prepare() {
        Task { @MainActor in
            let videoOK = await AVCaptureDevice.requestAccess(for: .video)
            guard videoOK else { self.state = .denied; return }
            _ = await AVCaptureDevice.requestAccess(for: .audio)   // sem microfone grava sem som
            self.queue.async { self.configureAndStart() }
        }
    }

    func stop() {
        timer?.invalidate(); timer = nil
        queue.async {
            if self.movieOutput.isRecording { self.movieOutput.stopRecording() }
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    private func configureAndStart() {
        if !configured {
            session.beginConfiguration()
            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let input = try? AVCaptureDeviceInput(device: device), session.canAddInput(input) else {
                session.commitConfiguration()
                DispatchQueue.main.async { self.state = .unavailable }
                return
            }
            session.addInput(input)
            Self.disableVideoHDR(device)
            if let mic = AVCaptureDevice.default(for: .audio),
               let micInput = try? AVCaptureDeviceInput(device: mic), session.canAddInput(micInput) {
                session.addInput(micInput)
            }
            if session.canAddOutput(movieOutput) { session.addOutput(movieOutput) }
            if session.canSetSessionPreset(quality.preset) { session.sessionPreset = quality.preset }
            session.commitConfiguration()
            configured = true
        }
        let can4K = session.canSetSessionPreset(.hd4K3840x2160)
        if !session.isRunning { session.startRunning() }
        DispatchQueue.main.async {
            self.supports4K = can4K
            self.state = .ready
        }
    }

    /// O pipeline trabalha em SDR: desliga o HDR de vídeo para evitar cores estranhas.
    private static func disableVideoHDR(_ device: AVCaptureDevice) {
        guard (try? device.lockForConfiguration()) != nil else { return }
        if device.activeFormat.isVideoHDRSupported {
            device.automaticallyAdjustsVideoHDREnabled = false
            device.isVideoHDREnabled = false
        }
        device.unlockForConfiguration()
    }

    private func applyQuality() {
        let preset = quality.preset
        queue.async {
            guard self.configured else { return }
            self.session.beginConfiguration()
            if self.session.canSetSessionPreset(preset) { self.session.sessionPreset = preset }
            self.session.commitConfiguration()
        }
    }

    // MARK: Gravação

    func toggleRecording() {
        if state == .recording {
            queue.async { self.movieOutput.stopRecording() }
            return
        }
        guard state == .ready else { return }
        let orientation = Self.currentVideoOrientation()
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("gravacao-\(UUID().uuidString).mov")
        queue.async {
            if let conn = self.movieOutput.connection(with: .video), conn.isVideoOrientationSupported {
                conn.videoOrientation = orientation
            }
            self.movieOutput.startRecording(to: url, recordingDelegate: self)
        }
        elapsed = 0
        startedAt = Date()
        state = .recording
        timer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
            guard let self, let t = self.startedAt else { return }
            self.elapsed = Date().timeIntervalSince(t)
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL,
                    from connections: [AVCaptureConnection], error: Error?) {
        let ok = (error as NSError?)?.userInfo[AVErrorRecordingSuccessfullyFinishedKey] as? Bool ?? (error == nil)
        DispatchQueue.main.async {
            self.timer?.invalidate(); self.timer = nil
            self.state = .ready
            if ok { self.finishedURL = outputFileURL }
        }
    }

    // MARK: Orientação

    /// A orientação do vídeo acompanha a da tela (a câmera trava em horizontal).
    static func currentVideoOrientation() -> AVCaptureVideoOrientation {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        switch scene?.interfaceOrientation {
        case .landscapeLeft: return .landscapeLeft
        case .landscapeRight: return .landscapeRight
        default: return .landscapeRight
        }
    }
}
