import SwiftUI

@main
struct AutoReframeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
