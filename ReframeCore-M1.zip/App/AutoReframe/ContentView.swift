import SwiftUI
import PhotosUI
import AVKit
import TrackingKit

struct ContentView: View {
    @StateObject private var model = ProcessingModel()
    @State private var pickerItem: PhotosPickerItem?
    @State private var chosenVideo: URL?
    @State private var loadError: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    content
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .navigationTitle("Auto Reframe")
            .onAppear(perform: runLaunchArguments)
            .onChange(of: pickerItem) { item in
                guard let item else { return }
                Task { await load(item) }
            }
        }
    }

    // MARK: Conteúdo por etapa

    @ViewBuilder private var content: some View {
        switch model.stage {
        case .idle, .failed:
            chooser
            if case .failed(let msg) = model.stage { errorBox(msg) }
        case .loading:
            ProgressRow(title: "Preparando o vídeo…", progress: nil)
        case .tracking(let p):
            ProgressRow(title: "Seguindo a pessoa", progress: p)
            cancelButton
        case .rendering(let p):
            ProgressRow(title: "Criando o vídeo vertical", progress: p)
            cancelButton
        case .done(let url):
            result(url)
        }
    }

    private var chooser: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Transforme um vídeo horizontal em vertical. O recorte acompanha a pessoa sozinho.")
                .foregroundStyle(.secondary)

            PhotosPicker(selection: $pickerItem, matching: .videos) {
                Label(chosenVideo == nil ? "Escolher vídeo" : "Trocar vídeo", systemImage: "film")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            if let loadError { errorBox(loadError) }

            if chosenVideo != nil {
                Label("Vídeo pronto para processar", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            }

            optionsSection

            Button {
                if let v = chosenVideo { model.process(video: v) }
            } label: {
                Text("Criar vídeo vertical").frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(chosenVideo == nil)
        }
    }

    private var optionsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Formato").font(.headline)
            Picker("Formato", selection: $model.format) {
                ForEach(OutputFormat.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Text(model.format.hint).font(.footnote).foregroundStyle(.secondary)

            Text("Estilo do movimento").font(.headline).padding(.top, 4)
            Picker("Estilo", selection: $model.preset) {
                ForEach(RenderPreset.allCases, id: \.self) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Text(model.preset.hint).font(.footnote).foregroundStyle(.secondary)
        }
    }

    private func result(_ url: URL) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            if let player = model.player {
                VideoPlayer(player: player)
                    .aspectRatio(model.format.aspect, contentMode: .fit)
                    .frame(maxWidth: .infinity)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            HStack(spacing: 12) {
                Button { model.saveToPhotos(url) } label: {
                    Label("Salvar", systemImage: "square.and.arrow.down").frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                ShareLink(item: url) {
                    Label("Compartilhar", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }
            .controlSize(.large)
            if let msg = model.saveMessage { Text(msg).font(.footnote).foregroundStyle(.secondary) }
            Button("Fazer outro vídeo") { model.reset(); pickerItem = nil; chosenVideo = nil }
                .frame(maxWidth: .infinity)
        }
    }

    private var cancelButton: some View {
        Button("Cancelar", role: .cancel) { model.cancel() }.frame(maxWidth: .infinity)
    }

    private func errorBox(_ text: String) -> some View {
        Label(text, systemImage: "exclamationmark.triangle.fill")
            .font(.footnote)
            .foregroundStyle(.red)
    }

    // MARK: Carregar a escolha da galeria

    private func load(_ item: PhotosPickerItem) async {
        loadError = nil
        model.stage = .loading
        do {
            if let video = try await item.loadTransferable(type: VideoFile.self) {
                chosenVideo = video.url
                model.stage = .idle
            } else {
                loadError = "Não consegui abrir esse vídeo."
                model.stage = .idle
            }
        } catch {
            loadError = "Não consegui abrir esse vídeo: \(error.localizedDescription)"
            model.stage = .idle
        }
    }

    // MARK: Teste automático no CI (simulador)

    /// `-autoprocess <caminho>` processa o vídeo direto, sem a galeria (usado só no CI).
    private func runLaunchArguments() {
        let args = ProcessInfo.processInfo.arguments
        guard let i = args.firstIndex(of: "-autoprocess"), i + 1 < args.count, !model.isBusy,
              chosenVideo == nil else { return }
        let url = URL(fileURLWithPath: args[i + 1])
        chosenVideo = url
        model.process(video: url)
    }
}

private struct ProgressRow: View {
    let title: String
    let progress: Double?
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.headline)
            if let progress {
                ProgressView(value: progress)
                Text("\(Int(progress * 100))%").font(.footnote).foregroundStyle(.secondary)
            } else {
                ProgressView()
            }
        }
    }
}
