import SwiftUI
import PhotosUI
import AVKit
import TrackingKit

struct ContentView: View {
    @StateObject private var model = ProcessingModel()
    @State private var pickerItem: PhotosPickerItem?
    @State private var chosenVideo: URL?
    @State private var loadError: String?
    @State private var showCamera = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    content
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
            }
            .navigationTitle("Auto Reframe")
            .onAppear(perform: runLaunchArguments)
            .fullScreenCover(isPresented: $showCamera) {
                CameraView { url in
                    loadError = nil
                    pickerItem = nil
                    chooseVideo(url)
                }
            }
            .onChange(of: pickerItem) { item in
                guard let item else { return }
                Task { await load(item) }
            }
        }
    }

    // MARK: Conteúdo por etapa

    @ViewBuilder private var content: some View {
        switch model.stage {
        case .idle, .failed:
            chooser
            if case .failed(let msg) = model.stage { errorBox(msg) }
        case .loading:
            ProgressRow(title: "Preparando o vídeo…", progress: nil)
        case .tracking(let p):
            ProgressRow(title: "Seguindo a pessoa", progress: p)
            cancelButton
        case .rendering(let p):
            ProgressRow(title: "Criando o vídeo vertical", progress: p)
            cancelButton
        case .done(let url):
            result(url)
        }
    }

    private var chooser: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Transforme um vídeo horizontal em vertical. O recorte acompanha a pessoa sozinho.")
                .foregroundStyle(.secondary)

            Button { showCamera = true } label: {
                Label("Gravar com a câmera", systemImage: "video.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            PhotosPicker(selection: $pickerItem, matching: .videos) {
                Label(chosenVideo == nil ? "Escolher da galeria" : "Trocar vídeo", systemImage: "film")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .controlSize(.large)

            if let loadError { errorBox(loadError) }

            if chosenVideo != nil {
                Label("Vídeo pronto para processar", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            }

            personSection

            optionsSection

            Button {
                if let v = chosenVideo { model.process(video: v) }
            } label: {
                Text("Criar vídeo vertical").frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(chosenVideo == nil)
        }
    }

    @ViewBuilder private var personSection: some View {
        if model.loadingPreview {
            HStack(spacing: 8) { ProgressView(); Text("Procurando pessoas…").font(.footnote).foregroundStyle(.secondary) }
        } else if let preview = model.preview, preview.people.count >= 2 {
            VStack(alignment: .leading, spacing: 10) {
                Text("Quem deve aparecer?").font(.headline)
                PersonPickerView(preview: preview, selected: $model.selectedPerson)
                HStack {
                    Text(model.selectedPerson == nil
                         ? "Toque na pessoa. Sem escolha, o app decide sozinho."
                         : "Vou seguir a pessoa marcada.")
                        .font(.footnote).foregroundStyle(.secondary)
                    Spacer()
                    if model.selectedPerson != nil {
                        Button("Automático") { model.selectedPerson = nil }.font(.footnote)
                    }
                }
            }
        }
    }

    private var optionsSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Formato").font(.headline)
            Picker("Formato", selection: $model.format) {
                ForEach(OutputFormat.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Text(model.format.hint).font(.footnote).foregroundStyle(.secondary)

            Text("Estilo do movimento").font(.headline).padding(.top, 4)
            Picker("Estilo", selection: $model.preset) {
                ForEach([RenderPreset.suave, .padrao, .rapido, .oneeuro], id: \.self) { Text($0.title).tag($0) }
            }
            .pickerStyle(.segmented)
            Text(model.preset.hint).font(.footnote).foregroundStyle(.secondary)
        }
    }

    private func result(_ url: URL) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            if let player = model.player {
                VideoPlayer(player: player)
                    .aspectRatio(model.format.aspect, contentMode: .fit)
                    .frame(maxWidth: .infinity, maxHeight: 440)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            HStack(spacing: 12) {
                Button { model.saveToPhotos(url) } label: {
                    Label("Salvar", systemImage: "square.and.arrow.down").frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                ShareLink(item: url) {
                    Label("Compartilhar", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }
            .controlSize(.large)
            if let msg = model.saveMessage { Text(msg).font(.footnote).foregroundStyle(.secondary) }
            Button("Fazer outro vídeo") {
                model.reset(); pickerItem = nil
                ProcessingModel.removeIfTemporary(chosenVideo); chosenVideo = nil
                model.clearPreview()
            }
                .frame(maxWidth: .infinity)
        }
    }

    private var cancelButton: some View {
        Button("Cancelar", role: .cancel) { model.cancel() }.frame(maxWidth: .infinity)
    }

    private func errorBox(_ text: String) -> some View {
        Label(text, systemImage: "exclamationmark.triangle.fill")
            .font(.footnote)
            .foregroundStyle(.red)
    }

    /// Define o vídeo escolhido (galeria, câmera ou teste) e procura as pessoas no primeiro quadro.
    private func chooseVideo(_ url: URL) {
        if chosenVideo != url { ProcessingModel.removeIfTemporary(chosenVideo) }
        chosenVideo = url
        model.loadPreview(for: url)
    }

    // MARK: Carregar a escolha da galeria

    private func load(_ item: PhotosPickerItem) async {
        loadError = nil
        model.stage = .loading
        do {
            if let video = try await item.loadTransferable(type: VideoFile.self) {
                chooseVideo(video.url)
                model.stage = .idle
            } else {
                loadError = "Não consegui abrir esse vídeo."
                model.stage = .idle
            }
        } catch {
            loadError = "Não consegui abrir esse vídeo: \(error.localizedDescription)"
            model.stage = .idle
        }
    }

    // MARK: Teste automático no CI (simulador)

    /// `-autoprocess <caminho>` processa o vídeo direto, sem a galeria (usado só no CI).
    private func runLaunchArguments() {
        let args = ProcessInfo.processInfo.arguments
        if args.contains("-showcamera") { showCamera = true; return }
        if let i = args.firstIndex(of: "-preview"), i + 1 < args.count, chosenVideo == nil {
            chooseVideo(URL(fileURLWithPath: args[i + 1]))
            return
        }
        guard let i = args.firstIndex(of: "-autoprocess"), i + 1 < args.count, !model.isBusy,
              chosenVideo == nil else { return }
        let url = URL(fileURLWithPath: args[i + 1])
        chosenVideo = url
        model.process(video: url)
    }
}

private struct ProgressRow: View {
    let title: String
    let progress: Double?
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.headline)
            if let progress {
                ProgressView(value: progress)
                Text("\(Int(progress * 100))%").font(.footnote).foregroundStyle(.secondary)
            } else {
                ProgressView()
            }
        }
    }
}

/// Primeiro quadro com as pessoas marcadas; tocar escolhe quem aparece.
private struct PersonPickerView: View {
    let preview: PersonPreviewResult
    @Binding var selected: Int?

    var body: some View {
        let size = CGSize(width: preview.image.width, height: preview.image.height)
        Image(decorative: preview.image, scale: 1)
            .resizable()
            .aspectRatio(size.width / size.height, contentMode: .fit)
            .frame(maxWidth: .infinity)
            .overlay(GeometryReader { geo in
                ZStack(alignment: .topLeading) {
                    ForEach(Array(preview.people.enumerated()), id: \.offset) { i, box in
                        let on = selected == i
                        RoundedRectangle(cornerRadius: 6)
                            .stroke(on ? Color.green : Color.white.opacity(0.9), lineWidth: on ? 4 : 2)
                            .background(RoundedRectangle(cornerRadius: 6)
                                .fill(on ? Color.green.opacity(0.18) : Color.clear))
                            .frame(width: box.width * geo.size.width, height: box.height * geo.size.height)
                            .offset(x: box.minX * geo.size.width, y: box.minY * geo.size.height)
                    }
                }
                .frame(width: geo.size.width, height: geo.size.height, alignment: .topLeading)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onEnded { v in
                    let p = CGPoint(x: v.location.x / geo.size.width, y: v.location.y / geo.size.height)
                    selected = Self.person(at: p, in: preview.people)
                })
            })
            .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    /// Menor caixa que contém o toque; senão a de centro mais próximo (até 0.15).
    static func person(at p: CGPoint, in boxes: [CGRect]) -> Int? {
        let inside = boxes.enumerated().filter { $0.element.contains(p) }
            .min { $0.element.width * $0.element.height < $1.element.width * $1.element.height }
        if let inside { return inside.offset }
        let near = boxes.enumerated().map { ($0.offset, hypot($0.element.midX - p.x, $0.element.midY - p.y)) }
            .min { $0.1 < $1.1 }
        if let near, near.1 <= 0.15 { return near.0 }
        return nil
    }
}
