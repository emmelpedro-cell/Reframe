import SwiftUI
import AVFoundation

/// Camada de prévia da câmera.
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession

    final class PreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }

        override func layoutSubviews() {
            super.layoutSubviews()
            if let conn = previewLayer.connection, conn.isVideoOrientationSupported {
                conn.videoOrientation = CameraService.currentVideoOrientation()
            }
        }
    }

    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.previewLayer.session = session
        v.previewLayer.videoGravity = .resizeAspect   // mostra exatamente o que será gravado
        return v
    }
    func updateUIView(_ uiView: PreviewView, context: Context) {}
}

struct CameraView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var camera = CameraService()
    let onFinish: (URL) -> Void

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            switch camera.state {
            case .denied:
                message("Sem permissão para a câmera.\nAtive em Ajustes > Auto Reframe.")
            case .unavailable:
                message("Câmera indisponível neste aparelho.\n(No simulador a câmera não funciona.)")
            default:
                CameraPreview(session: camera.session).ignoresSafeArea()
                controls
            }
            closeButton
        }
        .statusBarHidden(true)
        .onAppear {
            OrientationLock.set(.landscape)
            camera.prepare()
        }
        .onDisappear {
            camera.stop()
            OrientationLock.set(.portrait)
        }
        .onChange(of: camera.finishedURL) { url in
            if let url { onFinish(url); dismiss() }
        }
    }

    private var closeButton: some View {
        VStack {
            HStack {
                Button { dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.title3.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(12)
                        .background(.black.opacity(0.45), in: Circle())
                }
                .disabled(camera.state == .recording)
                .opacity(camera.state == .recording ? 0.3 : 1)
                Spacer()
                if camera.state == .recording {
                    Text(timeText(camera.elapsed))
                        .font(.headline.monospacedDigit())
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(.red, in: Capsule())
                }
                Spacer()
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, 20).padding(.top, 12)
            Spacer()
        }
    }

    private var controls: some View {
        HStack {
            Spacer()
            VStack(spacing: 22) {
                Spacer()
                if camera.state != .recording {
                    Picker("Qualidade", selection: $camera.quality) {
                        Text("1080p").tag(CameraService.Quality.hd1080)
                        if camera.supports4K { Text("4K").tag(CameraService.Quality.uhd4K) }
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 120)
                }
                Button { camera.toggleRecording() } label: {
                    ZStack {
                        Circle().strokeBorder(.white, lineWidth: 4).frame(width: 74, height: 74)
                        RoundedRectangle(cornerRadius: camera.state == .recording ? 6 : 32)
                            .fill(.red)
                            .frame(width: camera.state == .recording ? 30 : 60,
                                   height: camera.state == .recording ? 30 : 60)
                    }
                }
                .disabled(camera.state == .preparing)
                Spacer()
            }
            .padding(.trailing, 28)
        }
    }

    private func message(_ text: String) -> some View {
        Text(text)
            .multilineTextAlignment(.center)
            .foregroundStyle(.white)
            .padding(32)
    }

    private func timeText(_ t: TimeInterval) -> String {
        let s = Int(t)
        return String(format: "%d:%02d", s / 60, s % 60)
    }
}
