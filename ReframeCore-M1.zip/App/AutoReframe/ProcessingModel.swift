import Foundation
import AVFoundation
import Photos
import ReframeCore
import TrackingKit

@MainActor
final class ProcessingModel: ObservableObject {

    enum Stage: Equatable {
        case idle
        case loading
        case tracking(Double)
        case rendering(Double)
        case done(URL)
        case failed(String)
    }

    @Published var stage: Stage = .idle
    @Published var player: AVPlayer?
    @Published var saveMessage: String?
    @Published var format: OutputFormat = .vertical
    @Published var preset: RenderPreset = .suave

    private var task: Task<Void, Never>?

    var isBusy: Bool {
        switch stage {
        case .loading, .tracking, .rendering: return true
        default: return false
        }
    }

    func reset() {
        task?.cancel()
        player?.pause()
        player = nil
        saveMessage = nil
        stage = .idle
    }

    func cancel() { reset() }

    /// Segue o sujeito no vídeo e gera a versão vertical.
    func process(video: URL) {
        task?.cancel()
        saveMessage = nil
        player = nil
        stage = .tracking(0)
        let format = self.format
        let preset = self.preset

        task = Task { [weak self] in
            do {
                var settings = TrackingSettings()
                #if targetEnvironment(simulator)
                settings.visionCPUOnly = true   // o simulador não tem Neural Engine
                #endif
                let pipeline = TrackingPipeline(settings: settings)
                let result = try await pipeline.run(url: video) { p in
                    Task { @MainActor in self?.stage = .tracking(p) }
                }
                try Task.checkCancellation()

                var options = RenderOptions()
                options.aspect = format.aspect
                options.reframe = preset.reframeSettings
                options.useOneEuro = preset.useOneEuro

                let out = FileManager.default.temporaryDirectory
                    .appendingPathComponent("vertical-\(UUID().uuidString).mp4")
                await MainActor.run { self?.stage = .rendering(0) }
                _ = try await VerticalRenderer.render(input: video, report: result.report,
                                                      output: out, options: options) { p in
                    Task { @MainActor in self?.stage = .rendering(p) }
                }
                try Task.checkCancellation()
                await MainActor.run {
                    guard let self else { return }
                    self.player = AVPlayer(url: out)
                    self.stage = .done(out)
                }
            } catch is CancellationError {
                // cancelado pelo usuário
            } catch {
                await MainActor.run { self?.stage = .failed("\(error)") }
            }
        }
    }

    /// Salva o vídeo pronto na galeria (só permissão de adicionar).
    func saveToPhotos(_ url: URL) {
        Task {
            let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            guard status == .authorized || status == .limited else {
                saveMessage = "Sem permissão para salvar na galeria. Ative em Ajustes > Auto Reframe."
                return
            }
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
                }
                saveMessage = "Salvo na galeria."
            } catch {
                saveMessage = "Não consegui salvar: \(error.localizedDescription)"
            }
        }
    }
}
