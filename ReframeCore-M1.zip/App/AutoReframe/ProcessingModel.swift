import Foundation
import AVFoundation
import Photos
import UIKit
import ReframeCore
import TrackingKit

@MainActor
final class ProcessingModel: ObservableObject {

    enum Stage: Equatable {
        case idle
        case loading
        case tracking(Double)
        case rendering(Double)
        case done(URL)
        case failed(String)
    }

    @Published var stage: Stage = .idle
    @Published var player: AVPlayer?
    @Published var saveMessage: String?
    @Published var format: OutputFormat = .vertical
    @Published var preset: RenderPreset = .suave

    private var task: Task<Void, Never>?
    private var outputURL: URL?

    /// Apaga um arquivo temporário do app (nunca mexe em arquivos fora da pasta temporária).
    static func removeIfTemporary(_ url: URL?) {
        guard let url, url.path.hasPrefix(FileManager.default.temporaryDirectory.path) else { return }
        try? FileManager.default.removeItem(at: url)
    }

    var isBusy: Bool {
        switch stage {
        case .loading, .tracking, .rendering: return true
        default: return false
        }
    }

    func reset() {
        task?.cancel()
        player?.pause()
        player = nil
        saveMessage = nil
        stage = .idle
        UIApplication.shared.isIdleTimerDisabled = false
        Self.removeIfTemporary(outputURL)
        outputURL = nil
    }

    func cancel() { reset() }

    /// Segue o sujeito no vídeo e gera a versão vertical.
    func process(video: URL) {
        task?.cancel()
        saveMessage = nil
        player = nil
        Self.removeIfTemporary(outputURL)
        outputURL = nil
        stage = .tracking(0)
        UIApplication.shared.isIdleTimerDisabled = true   // a tela não apaga durante o processamento
        let format = self.format
        let preset = self.preset

        task = Task { [weak self] in
            do {
                var settings = TrackingSettings()
                #if targetEnvironment(simulator)
                settings.visionCPUOnly = true   // o simulador não tem Neural Engine
                #endif
                let pipeline = TrackingPipeline(settings: settings)
                var lastPercent = -1
                let result = try await pipeline.run(url: video) { p in
                    let percent = Int(p * 100)
                    guard percent != lastPercent else { return }
                    lastPercent = percent
                    Task { @MainActor in
                        if let self, case .tracking = self.stage { self.stage = .tracking(p) }
                    }
                }
                try Task.checkCancellation()

                var options = RenderOptions()
                options.aspect = format.aspect
                options.reframe = preset.reframeSettings
                options.useOneEuro = preset.useOneEuro

                let out = FileManager.default.temporaryDirectory
                    .appendingPathComponent("vertical-\(UUID().uuidString).mp4")
                await MainActor.run { self?.stage = .rendering(0) }
                var lastRenderPercent = -1
                _ = try await VerticalRenderer.render(input: video, report: result.report,
                                                      output: out, options: options) { p in
                    let percent = Int(p * 100)
                    guard percent != lastRenderPercent else { return }
                    lastRenderPercent = percent
                    Task { @MainActor in
                        if let self, case .rendering = self.stage { self.stage = .rendering(p) }
                    }
                }
                try Task.checkCancellation()
                await MainActor.run {
                    guard let self else { return }
                    self.outputURL = out
                    self.player = AVPlayer(url: out)
                    self.stage = .done(out)
                    UIApplication.shared.isIdleTimerDisabled = false
                }
            } catch is CancellationError {
                // cancelado pelo usuário
            } catch {
                await MainActor.run {
                    self?.stage = .failed("\(error)")
                    UIApplication.shared.isIdleTimerDisabled = false
                }
            }
        }
    }

    /// Salva o vídeo pronto na galeria (só permissão de adicionar).
    func saveToPhotos(_ url: URL) {
        Task {
            let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            guard status == .authorized || status == .limited else {
                saveMessage = "Sem permissão para salvar na galeria. Ative em Ajustes > Auto Reframe."
                return
            }
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
                }
                saveMessage = "Salvo na galeria."
            } catch {
                saveMessage = "Não consegui salvar: \(error.localizedDescription)"
            }
        }
    }
}
