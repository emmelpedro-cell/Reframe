#!/bin/bash
# Compila o app, roda no simulador, tira prints e gera um .ipa sem assinatura.
# Chamado pelo workflow na raiz do repositório. Resultados em out-app/.
set +e
ROOT="$PWD"
OUT="$ROOT/out-app"
mkdir -p "$OUT"
cd "$ROOT/App" || exit 0

echo "== xcodegen"
brew install xcodegen >/dev/null 2>&1
xcodegen generate 2>&1 | tee "$OUT/xcodegen.log"

echo "== build (simulador)"
xcodebuild -project AutoReframe.xcodeproj -scheme AutoReframe -configuration Debug \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath build CODE_SIGNING_ALLOWED=NO build > "$OUT/build-simulator.log" 2>&1
SIM_RC=$?
echo "build simulador: código $SIM_RC" | tee "$OUT/resultado.txt"
grep -E "error:|warning: .*Swift 6|BUILD (SUCCEEDED|FAILED)" "$OUT/build-simulator.log" | head -40 | tee -a "$OUT/resultado.txt"

APP="$ROOT/App/build/Build/Products/Debug-iphonesimulator/AutoReframe.app"
if [ "$SIM_RC" = "0" ] && [ -d "$APP" ]; then
  echo "== simulador"
  DEVICE_ID=$(xcrun simctl list devices available | grep -E "iPhone 1[4-6]( Pro)? \(" | head -1 | sed -E 's/.*\(([0-9A-F-]{36})\).*/\1/')
  [ -z "$DEVICE_ID" ] && DEVICE_ID=$(xcrun simctl list devices available | grep "iPhone" | head -1 | sed -E 's/.*\(([0-9A-F-]{36})\).*/\1/')
  echo "simulador: $DEVICE_ID" | tee -a "$OUT/resultado.txt"
  xcrun simctl boot "$DEVICE_ID" 2>&1
  xcrun simctl bootstatus "$DEVICE_ID" -b >/dev/null 2>&1
  xcrun simctl install "$DEVICE_ID" "$APP" 2>&1 | tee -a "$OUT/resultado.txt"
  xcrun simctl launch "$DEVICE_ID" app.autoreframe.AutoReframe 2>&1 | tee -a "$OUT/resultado.txt"
  sleep 6
  xcrun simctl io "$DEVICE_ID" screenshot "$OUT/tela-1-inicio.png" 2>&1
  xcrun simctl terminate "$DEVICE_ID" app.autoreframe.AutoReframe 2>&1

  # menor vídeo do repositório, processado direto no simulador
  VIDEO=$(ls -S "$ROOT"/*.mov "$ROOT"/*.MOV "$ROOT"/*.mp4 "$ROOT"/*.MP4 2>/dev/null | tail -1)
  if [ -n "$VIDEO" ]; then
    echo "video de teste: $VIDEO" | tee -a "$OUT/resultado.txt"
    xcrun simctl launch "$DEVICE_ID" app.autoreframe.AutoReframe -autoprocess "$VIDEO" 2>&1 | tee -a "$OUT/resultado.txt"
    sleep 12
    xcrun simctl io "$DEVICE_ID" screenshot "$OUT/tela-2-processando.png" 2>&1
    for i in 1 2 3 4 5 6; do
      sleep 20
      xcrun simctl io "$DEVICE_ID" screenshot "$OUT/tela-3-depois-$((i*20+12))s.png" 2>&1
    done
  fi
  xcrun simctl spawn "$DEVICE_ID" log show --last 3m --predicate 'process == "AutoReframe"' --style compact 2>/dev/null | tail -60 > "$OUT/app-log.txt"
  xcrun simctl shutdown "$DEVICE_ID" 2>&1
fi

echo "== build (aparelho, sem assinatura)"
xcodebuild -project AutoReframe.xcodeproj -scheme AutoReframe -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath build-device CODE_SIGNING_ALLOWED=NO build > "$OUT/build-device.log" 2>&1
DEV_RC=$?
echo "build aparelho: código $DEV_RC" | tee -a "$OUT/resultado.txt"
grep -E "error:|BUILD (SUCCEEDED|FAILED)" "$OUT/build-device.log" | head -20 | tee -a "$OUT/resultado.txt"
DAPP="$ROOT/App/build-device/Build/Products/Release-iphoneos/AutoReframe.app"
if [ "$DEV_RC" = "0" ] && [ -d "$DAPP" ]; then
  rm -rf Payload && mkdir Payload && cp -R "$DAPP" Payload/
  zip -qr "$OUT/AutoReframe.ipa" Payload
  ls -l "$OUT/AutoReframe.ipa" | tee -a "$OUT/resultado.txt"
fi
exit 0
