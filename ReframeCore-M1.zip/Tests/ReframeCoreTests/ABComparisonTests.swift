import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import ReframeCore

/// Executa o A/B (baseline M1 × One Euro) e IMPRIME as métricas lado a lado no log do teste.
///
/// Este teste NÃO decide qual pipeline é melhor: só verifica que ambos produzem trajetórias
/// válidas, que o baseline é idêntico ao engine do M1 e que as métricas são finitas.
/// Linhas impressas (para conferir com `Reference/AB_REPORT.md`):
///     AB|<cenário>|<baseline|oneEuro>|<raw|truth>|<métrica>=<valor>|...
final class ABComparisonTests: XCTestCase {
    func testSideBySideComparisonPrintsMetricsAndBothPipelinesStayValid() {
        for testCase in ABScenarios.cases() {
            let outcome = ABScenarios.run(testCase)

            XCTAssertEqual(outcome.baseline, Scenario.engine().trajectory(points: testCase.raw, fps: testCase.fps), testCase.name)
            XCTAssertEqual(outcome.baseline.count, outcome.oneEuro.count, testCase.name)
            Scenario.assertValid(outcome.baseline)
            Scenario.assertValid(outcome.oneEuro)

            let rows: [(String, String, ReframeMetrics)] = [
                ("baseline", "raw", outcome.baselineVsRaw), ("oneEuro", "raw", outcome.oneEuroVsRaw),
                ("baseline", "truth", outcome.baselineVsTruth), ("oneEuro", "truth", outcome.oneEuroVsTruth),
            ]
            for (pipeline, reference, metrics) in rows {
                let values = ABScenarios.dictionary(metrics)
                for name in ABScenarios.metricKeys { XCTAssertTrue((values[name] ?? .nan).isFinite, "\(testCase.name) \(name)") }
                let fields = ABScenarios.metricKeys.map { "\($0)=" + String(format: "%.6f", values[$0] ?? .nan) }
                print("AB|\(testCase.name)|\(pipeline)|\(reference)|" + fields.joined(separator: "|"))
            }
        }
    }
}
