import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import ReframeCore

/// Testes do OneEuroFilter isolado (sem pipeline, sem engine).
final class OneEuroFilterTests: XCTestCase {
    private let fps = 30.0
    private let tau1Hz = 1.0 / (2.0 * Double.pi)   // constante de tempo de um corte de 1 Hz

    /// Implementação de REFERÊNCIA escrita na forma do artigo original (α = 1 / (1 + τ/te)),
    /// independente da forma `r / (1 + r)` usada pelo filtro. Serve para checar a matemática.
    private func reference(
        times: [Double], values: [Double], minCutoff: Double, beta: Double, dCutoff: Double
    ) -> [Double] {
        func alpha(_ cutoff: Double, _ te: Double) -> Double {
            let tau = 1.0 / (2.0 * Double.pi * cutoff)
            return 1.0 / (1.0 + tau / te)
        }
        var output: [Double] = []
        var previousRaw = 0.0, previousFiltered = 0.0, previousDerivative = 0.0, previousTime = 0.0
        for (index, value) in values.enumerated() {
            let time = times[index]
            if index == 0 {
                previousRaw = value; previousFiltered = value; previousDerivative = 0; previousTime = time
                output.append(value)
                continue
            }
            let te = time - previousTime
            let derivative = (value - previousRaw) / te
            let derivativeAlpha = alpha(dCutoff, te)
            let smoothedDerivative = derivativeAlpha * derivative + (1 - derivativeAlpha) * previousDerivative
            let cutoff = minCutoff + beta * abs(smoothedDerivative)
            let a = alpha(cutoff, te)
            let filtered = a * value + (1 - a) * previousFiltered
            previousRaw = value; previousFiltered = filtered; previousDerivative = smoothedDerivative; previousTime = time
            output.append(filtered)
        }
        return output
    }

    private func run(_ filter: inout OneEuroFilter, times: [Double], values: [Double]) -> [Double] {
        return zip(times, values).map { filter.filter(value: $1, time: $0) }
    }

    private func uniformTimes(count: Int, fps: Double) -> [Double] {
        return (0..<count).map { Double($0) / fps }
    }

    // MARK: Primeira amostra

    func testFirstSampleIsReturnedUnchangedAndInitializesTheFilter() {
        var filter = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        XCTAssertFalse(filter.isInitialized)
        XCTAssertEqual(filter.filter(value: 0.37, time: 12.5), 0.37, accuracy: 0)
        XCTAssertTrue(filter.isInitialized)

        // A derivada começa em 0: a 2ª amostra já segue a fórmula (confere com a referência).
        let second = filter.filter(value: 0.52, time: 12.5 + 1.0 / 30.0)
        let expected = reference(times: [12.5, 12.5 + 1.0 / 30.0], values: [0.37, 0.52], minCutoff: 1, beta: 5, dCutoff: 1)
        XCTAssertEqual(second, expected[1], accuracy: 1e-12)
    }

    // MARK: Sinais

    func testConstantSignalStaysConstant() {
        var filter = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        for i in 0..<100 {
            XCTAssertEqual(filter.filter(value: 0.42, time: Double(i) / fps), 0.42, accuracy: 1e-12)
        }
    }

    /// Com beta = 0 o filtro é um passa-baixa fixo. Para ruído branco, a razão RMS saída/entrada
    /// teórica é √(α/(2−α)) ≈ 0,31 (corte 1 Hz a 30 fps). Aceita-se 0,20 ... 0,45.
    func testSmallJitterIsAttenuated() {
        var random = DeterministicRandom(seed: 11)
        var filter = OneEuroFilter(minCutoff: 1, beta: 0, dCutoff: 1)
        var inputSquares = 0.0, outputSquares = 0.0
        var count = 0
        for i in 0..<600 {
            let noise = random.next(in: -0.01...0.01)
            let output = filter.filter(value: 0.5 + noise, time: Double(i) / fps) - 0.5
            if i >= 30 {                       // descarta o transitório inicial
                inputSquares += noise * noise
                outputSquares += output * output
                count += 1
            }
        }
        let ratio = (outputSquares / Double(count)).squareRoot() / (inputSquares / Double(count)).squareRoot()
        XCTAssertGreaterThan(ratio, 0.20)
        XCTAssertLessThan(ratio, 0.45)
    }

    /// Rampa lenta: com beta = 0 o atraso em regime é exatamente 1/(2π·minCutoff); com beta > 0
    /// o corte só aumenta, então o atraso nunca passa desse limite.
    func testSlowRampLagIsBoundedByMinCutoffTimeConstant() {
        let speed = 0.05
        for beta in [0.0, 5.0] {
            var filter = OneEuroFilter(minCutoff: 1, beta: beta, dCutoff: 1)
            var maxLag = 0.0, lastLag = 0.0
            for i in 0...300 {
                let t = Double(i) / fps
                let x = 0.1 + speed * t
                let lag = (x - filter.filter(value: x, time: t)) / speed
                maxLag = max(maxLag, lag)
                lastLag = lag
                XCTAssertGreaterThanOrEqual(lag, -1e-12, "a saída nunca passa à frente da rampa")
            }
            XCTAssertLessThanOrEqual(maxLag, tau1Hz + 1e-9, "beta=\(beta)")
            if beta == 0 { XCTAssertEqual(lastLag, tau1Hz, accuracy: 1e-6) }
        }
    }

    /// Rampa rápida: o mesmo caminho de derivada alimenta os dois filtros, então com beta > 0 o
    /// corte é maior em todo instante e o atraso final é estritamente menor que com beta = 0.
    func testFastRampWithBetaLagsLessThanWithoutBeta() {
        let speed = 0.5
        func finalLag(beta: Double) -> Double {
            var filter = OneEuroFilter(minCutoff: 1, beta: beta, dCutoff: 1)
            var x = 0.0, y = 0.0
            for i in 0...90 {
                let t = Double(i) / fps
                x = 0.1 + speed * t
                y = filter.filter(value: x, time: t)
            }
            return (x - y) / speed
        }
        let withoutBeta = finalLag(beta: 0)
        let withBeta = finalLag(beta: 5)
        XCTAssertEqual(withoutBeta, tau1Hz, accuracy: 1e-6)
        XCTAssertLessThan(withBeta, withoutBeta)
    }

    /// Mudança brusca: o filtro sobe monotonicamente, nunca ultrapassa o novo valor, reage mais
    /// depressa com beta > 0 e converge em menos de meio segundo (15 amostras) a < 1e-3.
    func testStepChangeNeverOvershootsAndConverges() {
        func outputs(beta: Double) -> [Double] {
            var filter = OneEuroFilter(minCutoff: 1, beta: beta, dCutoff: 1)
            return (0..<120).map { i in
                let t = Double(i) / fps
                return filter.filter(value: t < 1.0 ? 0.4 : 0.8, time: t)
            }
        }
        let adaptive = outputs(beta: 5)
        let fixed = outputs(beta: 0)
        for i in 0..<(adaptive.count - 1) {
            XCTAssertGreaterThanOrEqual(adaptive[i + 1], adaptive[i] - 1e-15)
            XCTAssertLessThanOrEqual(adaptive[i], 0.8 + 1e-12)
        }
        XCTAssertGreaterThan(adaptive[30], fixed[30], "beta > 0 reage mais depressa ao salto")
        XCTAssertLessThan(abs(0.8 - adaptive[45]), 1e-3)
    }

    // MARK: Tempo

    func testIrregularTimestampsMatchIndependentReference() {
        let deltas = [0.033, 0.05, 0.02, 0.1, 0.0167, 0.2, 0.033, 0.033, 0.4, 0.01, 0.0005, 1.5, 0.033]
        var times = [0.0]
        for d in deltas { times.append(times[times.count - 1] + d) }
        var random = DeterministicRandom(seed: 7)
        let values = times.map { _ in 0.5 + 0.3 * random.next() }
        for (minCutoff, beta, dCutoff) in [(1.0, 5.0, 1.0), (0.5, 0.0, 2.0), (2.0, 20.0, 0.5)] {
            var filter = OneEuroFilter(minCutoff: minCutoff, beta: beta, dCutoff: dCutoff)
            let got = run(&filter, times: times, values: values)
            let expected = reference(times: times, values: values, minCutoff: minCutoff, beta: beta, dCutoff: dCutoff)
            for i in got.indices {
                XCTAssertEqual(got[i], expected[i], accuracy: 1e-12, "amostra \(i), params (\(minCutoff), \(beta), \(dCutoff))")
            }
        }
    }

    /// O mesmo sinal contínuo amostrado a 30 e a 60 fps dá saídas aproximadamente iguais nos
    /// instantes em comum (a diferença é de discretização, ~5e-4; limite de 5e-3).
    func testThirtyAndSixtyFpsAgreeOnASmoothSignal() {
        func outputs(fps: Double) -> [Double] {
            var filter = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
            return (0...Int(12 * fps)).map { i in
                let t = Double(i) / fps
                return filter.filter(value: 0.5 + 0.28 * sin(2 * Double.pi * t / 8.0), time: t)
            }
        }
        let at30 = outputs(fps: 30), at60 = outputs(fps: 60)
        var maxDifference = 0.0
        for i in at30.indices { maxDifference = max(maxDifference, abs(at30[i] - at60[2 * i])) }
        XCTAssertLessThan(maxDifference, 0.005)
    }

    func testZeroAndNegativeDeltaTimeAreIgnoredWithoutChangingState() {
        var filter = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        _ = filter.filter(value: 0.2, time: 1.0)
        let last = filter.filter(value: 0.4, time: 1.0 + 1.0 / 30.0)
        let snapshot = filter

        XCTAssertEqual(filter.filter(value: 0.9, time: 1.0 + 1.0 / 30.0), last)        // dt = 0
        XCTAssertEqual(filter, snapshot)
        XCTAssertEqual(filter.filter(value: 0.9, time: 1.0), last)                      // dt < 0
        XCTAssertEqual(filter, snapshot)
        XCTAssertEqual(filter.filter(value: 0.9, time: 1.0 + 1.0 / 30.0 + 5e-10), last) // dt < mínimo
        XCTAssertEqual(filter, snapshot)

        // dt acima do mínimo (2e-9 s) é aceito: continua finito e fica entre a última saída e a entrada.
        let accepted = filter.filter(value: 0.9, time: 1.0 + 1.0 / 30.0 + OneEuroFilter.minimumDeltaTime * 2)
        XCTAssertTrue(accepted.isFinite)
        XCTAssertGreaterThanOrEqual(accepted, last)
        XCTAssertLessThanOrEqual(accepted, 0.9)
    }

    func testNonFiniteInputsAreIgnored() {
        var fresh = OneEuroFilter()
        XCTAssertTrue(fresh.filter(value: .nan, time: 0).isNaN)
        XCTAssertFalse(fresh.isInitialized, "uma amostra inválida não inicializa o filtro")

        var filter = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        _ = filter.filter(value: 0.2, time: 0)
        let last = filter.filter(value: 0.4, time: 0.1)
        let snapshot = filter
        XCTAssertEqual(filter.filter(value: .nan, time: 0.2), last)
        XCTAssertEqual(filter.filter(value: .infinity, time: 0.2), last)
        XCTAssertEqual(filter.filter(value: 0.5, time: .nan), last)
        XCTAssertEqual(filter.filter(value: 0.5, time: .infinity), last)
        XCTAssertEqual(filter, snapshot)
    }

    // MARK: Reset

    func testResetClearsStateBetweenTrajectories() {
        let timesA = uniformTimes(count: 50, fps: fps)
        let valuesA = timesA.map { 0.2 + 0.5 * $0 }
        let timesB = uniformTimes(count: 50, fps: 60).map { $0 + 100 }
        let valuesB = timesB.map { _ in 0.9 }

        var reused = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        _ = run(&reused, times: timesA, values: valuesA)
        reused.reset()
        XCTAssertFalse(reused.isInitialized)
        XCTAssertEqual(reused, OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1), "reset() volta ao estado de um filtro novo")

        var fresh = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        XCTAssertEqual(run(&reused, times: timesB, values: valuesB), run(&fresh, times: timesB, values: valuesB))
    }

    func testResetWithValueSeedsLikeAFirstSample() {
        var seeded = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        _ = seeded.filter(value: 0.9, time: 0)               // sujar o estado antes
        _ = seeded.filter(value: 0.1, time: 0.5)
        seeded.reset(value: 0.3, time: 2.0)

        var first = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        XCTAssertEqual(first.filter(value: 0.3, time: 2.0), 0.3)
        XCTAssertEqual(seeded, first)

        let times = (1...20).map { 2.0 + Double($0) / 30.0 }
        let values = times.map { 0.3 + 0.2 * sin($0) }
        XCTAssertEqual(run(&seeded, times: times, values: values), run(&first, times: times, values: values))

        var invalid = OneEuroFilter()
        invalid.reset(value: .nan, time: 0)
        XCTAssertFalse(invalid.isInitialized)
    }

    // MARK: Parâmetros

    func testExtremeValidParametersStayFiniteAndInsideTheInputRange() {
        let times = uniformTimes(count: 300, fps: fps)
        let values = (0..<300).map { 0.5 + 0.3 * sin(Double($0) / 5) }
        let low = values.min()!, high = values.max()!
        let cases: [(Double, Double, Double)] = [
            (1e-9, 0, 1), (1e12, 0, 1), (1, 1e6, 1), (1, 5, 1e-9), (1, 5, 1e12), (1e-9, 1e9, 1e-9),
        ]
        for (minCutoff, beta, dCutoff) in cases {
            var filter = OneEuroFilter(minCutoff: minCutoff, beta: beta, dCutoff: dCutoff)
            let out = run(&filter, times: times, values: values)
            for (i, y) in out.enumerated() {
                XCTAssertTrue(y.isFinite, "(\(minCutoff), \(beta), \(dCutoff)) amostra \(i)")
                XCTAssertGreaterThanOrEqual(y, low - 1e-12)   // média ponderada com pesos em [0, 1]
                XCTAssertLessThanOrEqual(y, high + 1e-12)
            }
            if minCutoff == 1e-9 && beta == 0 {                 // corte ínfimo: praticamente não sai do 1º valor
                for y in out { XCTAssertEqual(y, values[0], accuracy: 1e-6) }
            }
            if minCutoff == 1e12 && beta == 0 {                 // corte enorme: praticamente a entrada
                for (i, y) in out.enumerated() { XCTAssertEqual(y, values[i], accuracy: 1e-9) }
            }
        }
    }

    func testInvalidParametersFallBackToDefaults() {
        let invalid = OneEuroFilter(minCutoff: -1, beta: -5, dCutoff: .nan)
        let defaults = OneEuroFilter(minCutoff: 1, beta: 0, dCutoff: 1)
        XCTAssertEqual(invalid, defaults)
        XCTAssertEqual(OneEuroFilter(minCutoff: 0, beta: .infinity, dCutoff: -3), defaults)
        XCTAssertEqual(OneEuroFilter(), defaults)
    }

    // MARK: Estado

    func testFiltersHaveNoSharedStateAndAreDeterministic() {
        let times = uniformTimes(count: 80, fps: fps)
        let a = times.map { 0.5 + 0.2 * sin($0 * 3) }
        let b = times.map { 0.3 + 0.1 * cos($0 * 5) }

        var soloA = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        var soloB = OneEuroFilter(minCutoff: 0.5, beta: 1, dCutoff: 2)
        let expectedA = run(&soloA, times: times, values: a)
        let expectedB = run(&soloB, times: times, values: b)

        var interleavedA = OneEuroFilter(minCutoff: 1, beta: 5, dCutoff: 1)
        var interleavedB = OneEuroFilter(minCutoff: 0.5, beta: 1, dCutoff: 2)
        var gotA: [Double] = [], gotB: [Double] = []
        for i in times.indices {
            gotA.append(interleavedA.filter(value: a[i], time: times[i]))
            gotB.append(interleavedB.filter(value: b[i], time: times[i]))
        }
        XCTAssertEqual(gotA, expectedA)
        XCTAssertEqual(gotB, expectedB)
    }
}
