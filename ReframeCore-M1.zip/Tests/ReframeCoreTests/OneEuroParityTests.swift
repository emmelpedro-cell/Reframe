import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import ReframeCore

/// Paridade Swift × espelho Python para o código NOVO (One Euro e pipeline A/B).
///
/// `GoldenOneEuroData.swift` é gerado por `Reference/make_golden_oneeuro.py` com as mesmas
/// entradas determinísticas. Tolerância: 1e-9 nas trajetórias e nos vetores do filtro; 1e-6 nas
/// métricas. Os dados golden do M1 (`GoldenData.swift`) não foram tocados.
final class OneEuroParityTests: XCTestCase {
    func testFilterOutputsMatchPython() {
        let times = GoldenOneEuroData.filterTimes
        let values = GoldenOneEuroData.filterValues
        XCTAssertEqual(times.count, values.count)
        for (index, params) in GoldenOneEuroData.filterParams.enumerated() {
            var filter = OneEuroFilter(minCutoff: params[0], beta: params[1], dCutoff: params[2])
            let expected = GoldenOneEuroData.filterOutputs[index]
            for i in times.indices {
                let got = filter.filter(value: values[i], time: times[i])
                let diff = abs(got - expected[i])
                if !(diff <= 1e-9) {
                    XCTFail("params \(params) amostra \(i): esperado \(expected[i]), obtido \(got), diferença \(diff)")
                    break
                }
            }
        }
    }

    func testABTrajectoriesMatchPython() {
        let cases = ABScenarios.cases()
        XCTAssertEqual(cases.map { $0.name }, GoldenOneEuroData.caseNames)
        for testCase in cases {
            let outcome = ABScenarios.run(testCase)
            check(testCase.name, "baseline", outcome.baseline,
                  count: GoldenOneEuroData.baselineCount[testCase.name], samples: GoldenOneEuroData.baseline[testCase.name])
            check(testCase.name, "oneEuro", outcome.oneEuro,
                  count: GoldenOneEuroData.oneEuroCount[testCase.name], samples: GoldenOneEuroData.oneEuro[testCase.name])
        }
    }

    func testABMetricsMatchPython() {
        for testCase in ABScenarios.cases() {
            let outcome = ABScenarios.run(testCase)
            let actual: [String: ReframeMetrics] = [
                "\(testCase.name)|baseline|raw": outcome.baselineVsRaw,
                "\(testCase.name)|oneEuro|raw": outcome.oneEuroVsRaw,
                "\(testCase.name)|baseline|truth": outcome.baselineVsTruth,
                "\(testCase.name)|oneEuro|truth": outcome.oneEuroVsTruth,
            ]
            for (key, metrics) in actual {
                guard let golden = GoldenOneEuroData.metrics[key] else { XCTFail("sem golden para \(key)"); continue }
                let values = ABScenarios.dictionary(metrics)
                for name in ABScenarios.metricKeys {
                    let got = values[name] ?? .nan
                    let expected = golden[name] ?? .nan
                    let diff = abs(got - expected)
                    if !(diff <= 1e-6) {
                        XCTFail("\(key).\(name): esperado \(expected), obtido \(got), diferença \(diff)")
                    }
                }
            }
        }
    }

    private func check(
        _ name: String, _ pipeline: String, _ trajectory: [CropPoint], count: Int?, samples: [Double]?,
        file: StaticString = #filePath, line: UInt = #line
    ) {
        guard let count = count, let samples = samples else {
            XCTFail("sem golden para \(name)/\(pipeline)", file: file, line: line); return
        }
        XCTAssertEqual(trajectory.count, count, "\(name)/\(pipeline): número de amostras", file: file, line: line)
        guard trajectory.count == count else { return }
        for (k, expected) in samples.enumerated() {
            let index = k * GoldenOneEuroData.stride
            let got = Double(trajectory[index].centerX)
            let diff = abs(got - expected)
            if !(diff <= 1e-9) {
                XCTFail("\(name)/\(pipeline)[\(index)] t=\(trajectory[index].time): esperado \(expected), obtido \(got), diferença \(diff)", file: file, line: line)
                return
            }
        }
    }
}
