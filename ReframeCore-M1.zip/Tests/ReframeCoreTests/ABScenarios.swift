import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import ReframeCore

/// Cenários e execução do A/B (baseline M1 × One Euro). Não contém testes.
///
/// Os geradores são determinísticos e idênticos aos de `Reference/oneeuro_ref.py`
/// (SplitMix64 com as mesmas sementes), para que o Swift e o espelho Python recebam
/// exatamente as mesmas entradas.
enum ABScenarios {
    struct Case {
        let name: String
        let fps: Double
        /// Tracking bruto (com ruído, se houver) — o que o engine recebe.
        let raw: [TrackingPoint]
        /// Trajetória real sem ruído; igual a `raw` nos cenários sem ruído.
        let truth: [TrackingPoint]
    }

    struct Outcome {
        let name: String
        let baseline: [CropPoint]
        let oneEuro: [CropPoint]
        let baselineVsRaw: ReframeMetrics
        let oneEuroVsRaw: ReframeMetrics
        let baselineVsTruth: ReframeMetrics
        let oneEuroVsTruth: ReframeMetrics
    }

    // MARK: Geradores

    static func sine(duration: Double, fps: Double, jitter: Double = 0, seed: UInt64 = 1) -> [TrackingPoint] {
        var random = DeterministicRandom(seed: seed)
        let count = Int((duration * fps).rounded())
        var points: [TrackingPoint] = []
        for i in 0...count {
            let t = Double(i) / fps
            var cx = 0.5 + 0.28 * sin(2 * Double.pi * t / 8.0)
            if jitter > 0 { cx += random.next(in: -jitter...jitter) }
            points.append(Scenario.point(t, centerX: cx))
        }
        return points
    }

    static func zigzag(duration: Double, fps: Double, jitter: Double = 0, seed: UInt64 = 1) -> [TrackingPoint] {
        var random = DeterministicRandom(seed: seed)
        let count = Int((duration * fps).rounded())
        var points: [TrackingPoint] = []
        for i in 0...count {
            let t = Double(i) / fps
            let phase = (t / 6.0).truncatingRemainder(dividingBy: 1.0)
            let triangle = phase < 0.5 ? 2 * phase : 2 - 2 * phase
            var cx = 0.30 + 0.40 * triangle
            if jitter > 0 { cx += random.next(in: -jitter...jitter) }
            points.append(Scenario.point(t, centerX: cx))
        }
        return points
    }

    static func jump() -> [TrackingPoint] {
        var points: [TrackingPoint] = []
        for i in 0..<150 {
            let t = Double(i) / 30.0
            let cx = t < 3.0 ? 0.40 + 0.01 * Double(min(i, 2)) : 0.80
            points.append(Scenario.point(t, centerX: cx))
        }
        return points
    }

    static func loss() -> [TrackingPoint] {
        var points: [TrackingPoint] = []
        for i in 0...60 { points.append(Scenario.point(Double(i) / 30.0, centerX: 0.50)) }
        for i in 180...240 { points.append(Scenario.point(Double(i) / 30.0, centerX: 0.70)) }
        return points
    }

    /// Ordem e nomes iguais aos de `ab_cases()` em oneeuro_ref.py.
    static func cases() -> [Case] {
        func walk(_ jitter: Double = 0, _ seed: UInt64 = 1) -> [TrackingPoint] {
            return Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 9, duration: 10, fps: 30, jitter: jitter, seed: seed)
        }
        let walkClean = walk()
        let still = Scenario.walk(from: 0.5, to: 0.5, start: 0, end: 1, duration: 4, fps: 30)
        let stillNoisy = Scenario.walk(from: 0.5, to: 0.5, start: 0, end: 1, duration: 4, fps: 30, jitter: 0.01, seed: 1)
        let sineClean = sine(duration: 12, fps: 30)
        let zigzagClean = zigzag(duration: 12, fps: 30)
        let jumpPoints = jump()
        let lossPoints = loss()
        return [
            Case(name: "stationaryJitter", fps: 30, raw: stillNoisy, truth: still),
            Case(name: "walkClean", fps: 30, raw: walkClean, truth: walkClean),
            Case(name: "walkNoisy", fps: 30, raw: walk(0.01, 3), truth: walkClean),
            Case(name: "walkNoisyHeavy", fps: 30, raw: walk(0.03, 4), truth: walkClean),
            Case(name: "sineClean", fps: 30, raw: sineClean, truth: sineClean),
            Case(name: "sineNoisy", fps: 30, raw: sine(duration: 12, fps: 30, jitter: 0.01, seed: 5), truth: sineClean),
            Case(name: "zigzagNoisy", fps: 30, raw: zigzag(duration: 12, fps: 30, jitter: 0.01, seed: 6), truth: zigzagClean),
            Case(name: "jump", fps: 30, raw: jumpPoints, truth: jumpPoints),
            Case(name: "loss", fps: 30, raw: lossPoints, truth: lossPoints),
        ]
    }

    // MARK: Execução

    static func pipeline(useOneEuro: Bool, oneEuro: OneEuroSettings = .default) -> ReframePipeline {
        return ReframePipeline(
            geometry: Scenario.geometry,
            settings: ReframePipelineSettings(useOneEuro: useOneEuro, oneEuro: oneEuro)
        )
    }

    static func run(_ testCase: Case, oneEuro: OneEuroSettings = .default) -> Outcome {
        let baseline = pipeline(useOneEuro: false).trajectory(points: testCase.raw, fps: testCase.fps)
        let experimental = pipeline(useOneEuro: true, oneEuro: oneEuro).trajectory(points: testCase.raw, fps: testCase.fps)
        let g = Scenario.geometry
        return Outcome(
            name: testCase.name,
            baseline: baseline,
            oneEuro: experimental,
            baselineVsRaw: ReframeMetrics.evaluate(crop: baseline, subject: testCase.raw, geometry: g),
            oneEuroVsRaw: ReframeMetrics.evaluate(crop: experimental, subject: testCase.raw, geometry: g),
            baselineVsTruth: ReframeMetrics.evaluate(crop: baseline, subject: testCase.truth, geometry: g),
            oneEuroVsTruth: ReframeMetrics.evaluate(crop: experimental, subject: testCase.truth, geometry: g)
        )
    }

    /// Mesmas chaves de `KEYS` em oneeuro_ref.py.
    static let metricKeys = [
        "meanSubjectError", "meanSubjectErrorInCropWidths", "insideCropRatio", "maxSpeed",
        "maxAcceleration", "jerkRMS", "directionChanges", "apparentLag",
    ]

    static func dictionary(_ m: ReframeMetrics) -> [String: Double] {
        return [
            "meanSubjectError": m.meanSubjectError,
            "meanSubjectErrorInCropWidths": m.meanSubjectErrorInCropWidths,
            "insideCropRatio": m.insideCropRatio,
            "maxSpeed": m.maxSpeed,
            "maxAcceleration": m.maxAcceleration,
            "jerkRMS": m.jerkRMS,
            "directionChanges": Double(m.directionChanges),
            "apparentLag": m.apparentLag,
        ]
    }
}
