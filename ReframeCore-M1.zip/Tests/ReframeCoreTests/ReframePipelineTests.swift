import XCTest
import Foundation
#if canImport(CoreGraphics)
import CoreGraphics
#endif
@testable import ReframeCore

/// Testes do pipeline A/B: `useOneEuro = false` é o baseline M1 (sem alteração) e
/// `useOneEuro = true` só acrescenta o pré-filtro antes do mesmo `ReframeEngine`.
final class ReframePipelineTests: XCTestCase {
    private let fps = 30.0

    private func pipeline(_ useOneEuro: Bool, oneEuro: OneEuroSettings = .default,
                          reframe: ReframeSettings = ReframeSettings()) -> ReframePipeline {
        return ReframePipeline(
            geometry: Scenario.geometry,
            settings: ReframePipelineSettings(reframe: reframe, useOneEuro: useOneEuro, oneEuro: oneEuro)
        )
    }

    private func center(_ point: TrackingPoint) -> Double {
        return (Double(point.boundingBox.minX) + Double(point.boundingBox.maxX)) / 2
    }

    // MARK: useOneEuro = false  (baseline)

    func testOneEuroIsDisabledByDefault() {
        let settings = ReframePipelineSettings()
        XCTAssertFalse(settings.useOneEuro)
        XCTAssertEqual(settings.reframe, ReframeSettings())
        XCTAssertEqual(settings.oneEuro, OneEuroSettings.default)
        XCTAssertEqual(OneEuroSettings.default.minCutoff, 1.0)
        XCTAssertEqual(OneEuroSettings.default.beta, 5.0)
        XCTAssertEqual(OneEuroSettings.default.dCutoff, 1.0)
    }

    /// Resultado idêntico, bit a bit, ao do ReframeEngine do M1 chamado diretamente.
    func testDisabledPipelineIsBitIdenticalToTheM1Engine() {
        for testCase in ABScenarios.cases() {
            let direct = Scenario.engine().trajectory(points: testCase.raw, fps: testCase.fps)
            let viaPipeline = pipeline(false).trajectory(points: testCase.raw, fps: testCase.fps)
            XCTAssertEqual(viaPipeline, direct, testCase.name)
            XCTAssertFalse(direct.isEmpty, testCase.name)
        }
        // também com parâmetros do engine diferentes do padrão e com timeRange explícito
        var custom = ReframeSettings()
        custom.lookAhead = 0; custom.smoothingTime = 0.3; custom.maxSpeed = 0.2
        let points = Scenario.walk(from: 0.3, to: 0.7, start: 1, end: 4, duration: 6, fps: fps, jitter: 0.01, seed: 9)
        let direct = ReframeEngine(geometry: Scenario.geometry, settings: custom).trajectory(points: points, fps: fps, timeRange: 0...5)
        XCTAssertEqual(pipeline(false, reframe: custom).trajectory(points: points, fps: fps, timeRange: 0...5), direct)
    }

    /// Âncora no golden do M1 (gerado pelo Python): o baseline continua reproduzindo-o.
    func testDisabledPipelineStillMatchesTheM1GoldenData() {
        let points = Scenario.walk(from: 0.30, to: 0.70, start: 1, end: 9, duration: 10, fps: 30)
        let trajectory = pipeline(false).trajectory(points: points, fps: 30)
        XCTAssertEqual(trajectory.count, GoldenData.walkCount)
        for (k, expected) in GoldenData.walk.enumerated() {
            XCTAssertEqual(Double(trajectory[k * GoldenData.stride].centerX), expected, accuracy: 1e-9, "amostra \(k)")
        }
    }

    func testDisabledPrefilterReturnsThePointsUntouched() {
        let points = ABScenarios.cases()[2].raw
        XCTAssertEqual(pipeline(false).prefiltered(points), points)
    }

    // MARK: useOneEuro = true

    /// O pipeline experimental é EXATAMENTE "pré-filtro + mesmo engine": nenhuma lógica duplicada.
    func testEnabledPipelineIsThePrefilterFollowedByTheSameEngine() {
        let points = ABScenarios.cases()[3].raw
        let p = pipeline(true)
        XCTAssertEqual(p.trajectory(points: points, fps: fps), Scenario.engine().trajectory(points: p.prefiltered(points), fps: fps))
    }

    func testEnabledPrefilterKeepsTimesConfidencesCountAndLeavesLowConfidencePointsAlone() {
        var points = Scenario.walk(from: 0.3, to: 0.7, start: 0, end: 3, duration: 4, fps: fps, jitter: 0.02, seed: 2)
        // pontos de baixa confiança e com valores não finitos no meio da trilha
        points[20] = TrackingPoint(time: points[20].time, boundingBox: CGRect(x: 0.9, y: 0.1, width: 0.05, height: 0.5), confidence: 0.05)
        points[40] = TrackingPoint(time: points[40].time, boundingBox: CGRect(x: 0.1, y: 0.1, width: 0.05, height: 0.5), confidence: 0.0)
        points[60] = TrackingPoint(time: .nan, boundingBox: points[60].boundingBox, confidence: 1)

        let filtered = pipeline(true).prefiltered(points)
        XCTAssertEqual(filtered.count, points.count)
        for i in points.indices {
            XCTAssertEqual(filtered[i].confidence, points[i].confidence)
            if points[i].time.isNaN { XCTAssertTrue(filtered[i].time.isNaN) } else { XCTAssertEqual(filtered[i].time, points[i].time) }
        }
        XCTAssertEqual(filtered[20], points[20])
        XCTAssertEqual(filtered[40], points[40])
        XCTAssertEqual(filtered[60].boundingBox, points[60].boundingBox)
        XCTAssertNotEqual(filtered[10].boundingBox, points[10].boundingBox, "pontos válidos são filtrados")
        // y e altura (não usados pelo engine) passam inalterados
        XCTAssertEqual(filtered[10].boundingBox.minY, points[10].boundingBox.minY)
        XCTAssertEqual(filtered[10].boundingBox.height, points[10].boundingBox.height)
    }

    func testConstantSubjectGivesTheSameCropWithAndWithoutOneEuro() {
        let points = Scenario.walk(from: 0.5, to: 0.5, start: 0, end: 1, duration: 4, fps: fps)
        let off = pipeline(false).trajectory(points: points, fps: fps)
        let on = pipeline(true).trajectory(points: points, fps: fps)
        XCTAssertEqual(on.count, off.count)
        for i in off.indices {
            XCTAssertEqual(Double(on[i].centerX), Double(off[i].centerX), accuracy: 1e-9)
        }
    }

    /// Entre duas observações válidas a mais de `maxInterpolationGap`, o filtro é reiniciado:
    /// a primeira observação depois do vazio passa sem suavização; com um vazio menor, é filtrada.
    func testGapLargerThanMaxInterpolationGapResetsTheFilter() {
        func track(gap: Double) -> [TrackingPoint] {
            var points: [TrackingPoint] = []
            for i in 0...30 { points.append(Scenario.point(Double(i) / 30.0, centerX: 0.30)) }
            for i in 0...30 { points.append(Scenario.point(1.0 + gap + Double(i) / 30.0, centerX: 0.70)) }
            return points
        }
        XCTAssertGreaterThan(2.0, ReframeSettings().maxInterpolationGap)
        let afterLongGap = pipeline(true).prefiltered(track(gap: 2.0))
        XCTAssertEqual(center(afterLongGap[31]), 0.70, accuracy: 1e-12)

        let afterShortGap = pipeline(true).prefiltered(track(gap: 0.4))
        XCTAssertGreaterThan(center(afterShortGap[31]), 0.30)
        XCTAssertLessThan(center(afterShortGap[31]), 0.699, "sem reset: a amostra é suavizada")
    }

    func testInputOrderDoesNotMatter() {
        let points = ABScenarios.cases()[2].raw
        let forward = pipeline(true).trajectory(points: points, fps: fps)
        let reversed = pipeline(true).trajectory(points: Array(points.reversed()), fps: fps)
        XCTAssertEqual(forward, reversed)
    }

    func testEnabledPipelineNeverLeavesTheFrameOnRandomInput() {
        var random = DeterministicRandom(seed: 99)
        for _ in 0..<100 {
            var points: [TrackingPoint] = []
            for i in 0..<150 {
                points.append(Scenario.point(
                    Double(i) / fps,
                    centerX: random.next(in: -0.2...1.2),
                    width: random.next(in: 0.01...0.9),
                    confidence: Float(random.next(in: 0...1))
                ))
            }
            Scenario.assertValid(pipeline(true).trajectory(points: points, fps: fps))
        }
    }

    func testExtremeOneEuroParametersKeepTheCropValid() {
        let points = ABScenarios.cases()[3].raw
        for oneEuro in [OneEuroSettings(minCutoff: 1e-9, beta: 1e9, dCutoff: 1e-9),
                        OneEuroSettings(minCutoff: 1e12, beta: 0, dCutoff: 1e12),
                        OneEuroSettings(minCutoff: 0.01, beta: 100, dCutoff: 50)] {
            let trajectory = pipeline(true, oneEuro: oneEuro).trajectory(points: points, fps: fps)
            XCTAssertFalse(trajectory.isEmpty)
            Scenario.assertValid(trajectory)
        }
    }
}
